<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
          integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <title>Hello, world!</title>

    <style>
        .base-bg, .btn-next {
            background-color: #FF5700;
            color: #fff;
        }

        .btn-next, .btn-next:hover {
            border-radius: 100px;
            padding: 3px 16px;
            color: #fff;
        }

        .base-font {
            color: #FF5700;
        }

        .btn-right-radius {
            border-bottom-right-radius: 20px;
            border-top-right-radius: 20px;
        }

        .form-control:active {
            box-shadow: none !important;
            outline: none !important;
        }

        .btn:active, .btn:focus {
            box-shadow: none !important;
            outline: none !important;
        }

        /*    Hero*/
        .hero-review {
            padding: 6px 20px;
            background-color: #fff;
            border-style: none;
            border-radius: 100px;
            box-shadow: 0px 0px 5px 2px rgba(148, 148, 255, .29);
            font-size: 16px;
        }

        .header {
            width: 100%;
            background-color: #FF5700;
            color: #fff;
        }

        .logo-img {
            width: 200px;
        }

        .navitem {
            font-width: 700;
            color: #000000;
        }

        .btn-first {
            background-color: #FF5700;
            color: #fff;
        }

        .btn-first:hover {
            background-color: black;
            color: #fff;
        }

        a {
            text-decoration: none;
        }

        /*.fixed-top {*/
        /*    margin-top: 0px !important;*/
        /*    background: #ffffff4a;*/
        /*    border-radius: 0 0 5px 5px;*/
        /*    box-shadow: 0px 2px 5px 2px #00000017;*/
        /*    backdrop-filter: blur(5px);*/
        /*}*/

        .headline {
            font-size: 70px;
            font-weight: 700;
        }

    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
    <link rel="stylesheet" href="{{ asset('assets/css/toastr.min.css') }}">
    <link rel="stylesheet" href="{{asset('assets/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/responsive.css')}}">
</head>
<body>
<div class="header p-2">
    <div class="container">
        <div class="d-flex justify-content-between align-item-center flex-wrap">
            <div class="email">
                <i class="fa-regular fa-envelope"></i> &nbsp; info@steadyformation.com
            </div>
            <div class="social_icons ">
                <a class="text-white" href=""><i class="fa-brands fa-facebook"></i></a> &nbsp;
                <a class="text-white" href=""><i class="fa-brands fa-instagram"></i></a>&nbsp;
                <a class="text-white" href=""><i class="fa-brands fa-x-twitter"></i></a>&nbsp;
                <a class="text-white" href=""><i class="fa-brands fa-linkedin"></i></a>
            </div>
        </div>
    </div>
</div>


<!-- Navbar -->
<nav class="navbar navbar-expand-lg  bg-white navbar-white mt-3 mb-5" id="navbar_sticky">
    <div class="container">
        <a class="navbar-brand" href="#"
        ><img src="{{asset('assets/images/logo.webp')}}" alt="Steady Formation Logo" class="logo-img">
        </a>
        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item">
                    <a class="nav-link mx-2 navitem" href="#!">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link mx-2 navitem" href="#!"></i>About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link mx-2 navitem" href="#!">Contact Us</a>
                </li>
                <li class="nav-item ms-3">
                    <a class="btn btn-first" href="#!">Login</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- Navbar -->
<div class="container">

    {{--    ============================= Step One: only Company Name =============   =========================--}}

    <div id="step1" class="step card mt-4" style="display: block">
        <div class="row">
            <div class="col-12 col-md-10 m-auto">
                <div class="heading text-center">
                    <div class="row">
                        <div class="col-12 col-md-5 m-auto">
                            <a class="d-inline-block my-4"
                               href="https://www.trustpilot.com/review/steadyformation.com"
                               target="_blank" aria-label="SVG link">
                                <div>
                                    <svg class=" hero-review" style="height: 40px;"
                                         xmlns="http://www.w3.org/2000/svg"
                                         viewBox="0 0 775.49 68.34">
                                        <rect x="432.07" y="11.33" width="51.3" height="51.3"
                                              style="fill:#d1d1d1"></rect>
                                        <polygon
                                            points="568.16 24.05 543.05 24.05 535.57 0 527.55 24.05 502.98 24.05 522.75 38.47 515.26 62.52 535.57 47.56 555.34 62.52 547.86 38.47 568.16 24.05"
                                            style="fill:#00b67a"></polygon>
                                        <polygon points="549.46 43.82 547.86 38.47 535.57 47.56 549.46 43.82"
                                                 style="fill:#005128"></polygon>
                                        <rect x="211.38" y="11.33" width="51.3" height="51.3"
                                              style="fill:#00b67a"></rect>
                                        <path
                                            d="M236.5,45.53l8.07-2.14,3.2,10.15ZM254.67,32.7h-13.9L236.5,19.88,232.22,32.7H218.86l11.23,8-4.28,12.82,11.22-8,7-4.8Z"
                                            style="fill:#fff"></path>
                                        <rect x="266.42" y="11.33" width="51.3" height="51.3"
                                              style="fill:#00b67a"></rect>
                                        <path
                                            d="M292.07,45.53l8-2.14,3.21,10.15ZM309.7,32.7H295.81l-4.27-12.82L287.31,32.7H273.42l11.22,8-4.27,12.82,11.22-8,6.94-4.81,11.23-8Z"
                                            style="fill:#fff"></path>
                                        <rect x="321.99" y="11.33" width="51.3" height="51.3"
                                              style="fill:#00b67a"></rect>
                                        <path
                                            d="M347.64,45.53l8-2.14,3.2,10.15ZM365.27,32.7H351.44l-4.28-12.82L342.89,32.7H329l11.22,8-3.74,12.82,11.22-8,6.95-4.81,10.69-8Z"
                                            style="fill:#fff"></path>
                                        <rect x="377.03" y="11.33" width="51.3" height="51.3"
                                              style="fill:#00b67a"></rect>
                                        <path
                                            d="M402.68,45.53l8-2.14,3.21,10.15ZM420.9,32.7H407l-4.28-12.82L398.46,32.7h-13.9l11.23,8-4.28,12.82,11.22-8,6.95-4.81Z"
                                            style="fill:#fff"></path>
                                        <rect x="432.07" y="11.33" width="25.65" height="51.3"
                                              style="fill:#00b67a"></rect>
                                        <path
                                            d="M457.72,45.53l8-2.14,3.21,10.15ZM475.88,32.7H462l-4.27-12.82L453.44,32.7H439.55l11.22,8-4.28,12.82,11.23-8,6.94-4.81Z"
                                            style="fill:#fff"></path>
                                        <path d="M585.42,28.69H574.74V24.37h26.71v4.32H590.77V58.78h-5.08Z"></path>
                                        <path
                                            d="M601.72,40.29V33.5h4.7v5a8.61,8.61,0,0,1,8.34-5.34v4.75c-5.08,0-8.34,2.52-8.34,8.93v12h-4.75Z"></path>
                                        <path
                                            d="M639.34,51.24v7.27h-4.7a26.73,26.73,0,0,1,0-3.58,7.31,7.31,0,0,1-7.38,4.17c-4.38,0-8.23-2.3-8.23-9.19V33.5h4.76V48.89c0,3.21,1,6.09,4.86,6.09s6-2.35,6-8.39V33.5h4.81Z"></path>
                                        <path
                                            d="M648.8,51.3a5.35,5.35,0,0,0,5.82,4.11c3.42,0,4.76-1.44,4.76-3.58s-1.12-3.2-5.67-4.33c-7.26-1.76-8.71-4-8.71-7.42s2.57-7.16,9.14-7.16,9.24,3.79,9.57,7.26h-4.6a4.59,4.59,0,0,0-5.34-3.63c-3.26,0-4.28,1.55-4.28,3.1s1,2.62,5.35,3.69c7.69,1.81,9.13,4.43,9.13,8.12s-3.42,7.64-9.83,7.64-9.83-3.31-10.69-7.8Z"></path>
                                        <path
                                            d="M666.38,33.5h4.22V26.24h4.75V33.5h5.35v3.9h-5.35V51.56c0,2.36.59,3.48,2.84,3.48a9.55,9.55,0,0,0,2,0v3.52a11.67,11.67,0,0,1-3.9.48c-4.07,0-5.72-2.13-5.72-6.35V37.4h-4.22Z"></path>
                                        <path
                                            d="M690,55.63V68.34h-4.81V33.5h4.7v3.8a8.31,8.31,0,0,1,7.91-4.38c5.71,0,9.94,4.8,9.94,12.45,0,8.92-4.81,13.73-10.69,13.73A7.37,7.37,0,0,1,690,55.63Zm12.93-10.05c0-5.34-2.3-8.6-6.36-8.6-4.92,0-6.79,3.1-6.79,9s1.55,9.08,6.47,9.08,6.52-3.58,6.52-9.51Z"></path>
                                        <path d="M713.24,22.5h4.81v5.34h-4.81Zm0,11h4.81V58.78h-4.81Z"></path>
                                        <path d="M725.16,58.78V22.5H730V58.78Z"></path>
                                        <path
                                            d="M758.77,46a11.87,11.87,0,0,1-10.52,13,11.15,11.15,0,0,1-1.29.07,11.66,11.66,0,0,1-11.68-11.62h0a11.27,11.27,0,0,1,.08-1.42,11.87,11.87,0,0,1,10.51-13q.68-.06,1.35-.06a11.59,11.59,0,0,1,11.64,11.54h0A12.75,12.75,0,0,1,758.77,46Zm-18.49,0c0,5.35,2.62,9.14,6.84,9.14s7-3.53,7-9S751.44,37,747,37s-6.73,3.53-6.73,9.14Z"></path>
                                        <path
                                            d="M761.12,33.5h4.16V26.24h4.87V33.5h5.34v3.9h-5.34V51.56c0,2.36.58,3.48,2.78,3.48A9,9,0,0,0,775,55v3.52a11.67,11.67,0,0,1-3.9.48c-4.06,0-5.77-2.13-5.77-6.35V37.4h-4.17Z"></path>
                                        <path d="M22,53.37H0V19.5H21.78v5H6.1v9.18H18.71v4.91H6.1v9.48H22Z"></path>
                                        <path
                                            d="M46,53.37H39.52l-5.31-9.13-5.8,9.13H23.54l8.34-12.9L24.66,28.31h6.48l4.11,7.37,4.69-7.37h4.74L37.61,39.18Z"></path>
                                        <path
                                            d="M63.27,44.16l4.86.5a11.73,11.73,0,0,1-3.65,7A9.79,9.79,0,0,1,58,53.89a9.31,9.31,0,0,1-8-3.78,15.14,15.14,0,0,1-2.79-9.27,14.18,14.18,0,0,1,3-9.35,10,10,0,0,1,8.14-3.7q8.19,0,9.75,8.63l-4.86.67c-.43-3.11-2-4.67-4.59-4.66A4.36,4.36,0,0,0,54.5,35a13.1,13.1,0,0,0-1.31,6,10.67,10.67,0,0,0,1.35,5.85A4.29,4.29,0,0,0,58.33,49C60.81,49,62.45,47.36,63.27,44.16Z"></path>
                                        <path
                                            d="M88.4,45.38l5.11.7a10.61,10.61,0,0,1-3.87,5.6,11.53,11.53,0,0,1-7.22,2.21A10.81,10.81,0,0,1,74,50.39q-3.16-3.49-3.17-9.48a13.87,13.87,0,0,1,3.2-9.4,10.85,10.85,0,0,1,8.68-3.72A10,10,0,0,1,91,31.46a14.69,14.69,0,0,1,3,9.43v.64H76.74a14.21,14.21,0,0,0,.48,4.1,5.5,5.5,0,0,0,1.92,2.68,6.07,6.07,0,0,0,8.46-1.38A6.16,6.16,0,0,0,88.4,45.38Zm-.35-7.49a6.31,6.31,0,0,0-1.62-4.42,5.5,5.5,0,0,0-7.78-.19l-.08.08a7.23,7.23,0,0,0-1.83,4.53Z"></path>
                                        <path d="M104.75,53.37H99.09V19.5h5.66Z"></path>
                                        <path d="M117.18,53.37h-5.66V19.5h5.66Z"></path>
                                        <path
                                            d="M139.9,45.38l5.11.7a10.61,10.61,0,0,1-3.87,5.6,11.47,11.47,0,0,1-7.22,2.21,10.81,10.81,0,0,1-8.38-3.5q-3.18-3.49-3.18-9.48a13.92,13.92,0,0,1,3.2-9.4,10.88,10.88,0,0,1,8.69-3.72,10,10,0,0,1,8.28,3.67,14.6,14.6,0,0,1,2.93,9.43v.64h-17.2a13.84,13.84,0,0,0,.49,4.1,5.5,5.5,0,0,0,1.92,2.68A6,6,0,0,0,139.06,47a6.24,6.24,0,0,0,.86-1.66Zm-.34-7.49a6.32,6.32,0,0,0-1.63-4.42,5.48,5.48,0,0,0-7.75-.21l-.1.1a7.24,7.24,0,0,0-1.84,4.53Z"></path>
                                        <path
                                            d="M171.36,53.37h-5.65V37.71A5.3,5.3,0,0,0,164.56,34a3.58,3.58,0,0,0-2.75-1.25,5,5,0,0,0-3.87,1.93c-1.11,1.29-1.66,3.24-1.66,5.83V53.37h-5.66V28.31h5.16v5.81c1.8-4.22,4.34-6.33,7.59-6.33A8.22,8.22,0,0,1,169,29.87q2.34,2.09,2.34,7.32Z"></path>
                                        <path
                                            d="M189.75,49v4.42a20.79,20.79,0,0,1-3.92.55,8,8,0,0,1-3.92-.91,5.59,5.59,0,0,1-2.4-2.48,11.81,11.81,0,0,1-.75-4.85v-13h-3.13V28.31h3.45l.52-6.52,4.64-.43v7h5V32.7h-5V44.93a4.52,4.52,0,0,0,.86,3.22,4.59,4.59,0,0,0,3.23.85Z"></path>
                                    </svg>
                                </div>
                            </a>
                        </div>
                    </div>
                    <h1 class="headline mb-1">US COMPANY FORMATION FOR</h1>
                    <h1 class="headline base-font">NON-RESIDENT AT "$0"</h1>

                    <div class="section-getting-start mt-5">
                        <div class="input-group mb-3 btn-right-radius">
                            <input type="text" name="company_name" class="form-control" placeholder="Company Name"
                                   id="company_name">
                            <span class="input-group-text base-bg btn-right-radius" id="basic-addon2"><button
                                    onclick="nextStep(event,1,'step_1')"
                                    class="btn base-bg ">Next <i
                                        class="fa-solid fa-chevron-right"></i></button></span>
                        </div>

                    </div>

                    <p style="color: #3d3d3d">
                        Elevate your business by establishing a US company from anywhere at <br>
                        <span style="color: #ff6600;">+ State Fee</span>
                    </p>
                </div>


            </div>
        </div>
    </div>


    {{--    ============================= Step Two: Primary Contact ============= Figma : Funnel =========================--}}
    <div id="step2" class="step mt-4" style="display: none">
        <div class="row mb-5">
            <div class="col-12">
                <h4 class="step_caption mb-4">Primary Contact</h4>
                <div class="row">
                    <div class="col-12 col-md-6 form-group step_group">
                        <label for="first_name" class="step_label">First Name *</label>
                        <input type="text" name="first_name" required id="first_name"
                               class="form-control step_form_control">
                    </div>
                    <div class="col-12 col-md-6 form-group step_group">
                        <label for="last_name" class="step_label">Last Name *</label>
                        <input type="text" name="last_name" required id="last_name"
                               class="form-control step_form_control">
                    </div>
                    <div class="col-12 col-md-6 form-group step_group">
                        <label for="email" class="step_label">Email *</label>
                        <input type="email" name="email" required id="email" class="form-control step_form_control">
                    </div>
                    <div class="col-12 col-md-6 form-group step_group">
                        <label for="email" class="step_label">Phone Number *</label>
                        <input type="tel" class="form-control form-control-lg input-field step_form_control"
                               name="phone_number"
                               style="width:100%!important;" id="phone_number">


                        <input type="hidden" name="calling_code" id="calling_code">
                        <input type="hidden" name="country" id="country">
                        <input type="hidden" name="number" id="mobile_number">
                    </div>

                </div>
            </div>

        </div>
        <div class="text-center">
            <button onclick="prevStep(event,2,'step_2')" class="btn btn-next "><i class="fa-solid fa-chevron-left"></i>
                Back
            </button>
            <button onclick="nextStep(event,2,'step_2')" class="btn btn-next ">Next <i
                    class="fa-solid fa-chevron-right"></i></button>
        </div>

    </div>

    {{--    ============================= Step Three: Business info ============= Figma : Funnel 02 =========================--}}
    <div id="step3" class="step mt-4" style="display: none">

        <div class="row mb-5">
            <div class="col-12 col-md-8">
                <h4 class="step_caption mb-4">Business Info</h4>
                <div class="row">
                    <div class="col-12 form-group step_group">
                        <label for="propose_business_name" class="step_label">Proposed Business Name *</label>
                        <div class="input-group mb-3" style="border-radius: 20px">
                            <input type="text" name="propose_business_name" readonly id="propose_business_name"
                                   class="form-control step_form_control" style="border-right: 1px solid #FF5700;">
                            <span class="input-group-text step_input_group_text" id="basic-addon2">
                                <select name="business_type" id="business_type">
                                    <option value="LLC">LLC</option>
                                    <option value="S Corp">S Corp</option>
                                    <option value="C Corp">C Corp</option>
                                </select>
                            </span>
                        </div>
                        <p style="font-size: 13px">*The entered name will be validated later. You Don’t have to add
                            “LLC,” “Inc.” “Corp” etc. in this box. If your chosen name is unavailable, together we'll
                            work on an alternative.</p>
                        <p style="font-size: 13px">The 3 entities we provide <a href="" style="color: #FF5700">see
                                more</a></p>
                    </div>

                    <div class="col-12 col-md-6 form-group step_group">
                        <label for="state_name" class="step_label">State Name *</label>
                        <select name="state_name" id="state_name" class="form-control step_form_control">
                            <option value="">Choose State Name</option>
                            <option value="Alabama" data-calculate="200">Alabama</option>
                            <option value="Alaska" data-calculate="250">Alaska</option>
                            <option value="Arizona" data-calculate="50">Arizona</option>
                            <option value="Arkansas" data-calculate="45">Arkansas</option>
                            <option value="California" data-calculate="70">California</option>
                            <option value="Colorado" data-calculate="50">Colorado</option>
                            <option value="Connecticut" data-calculate="50">Connecticut</option>
                            <option value="Delaware" data-calculate="90">Delaware</option>
                            <option value="Florida" selected data-calculate="100">Florida</option>
                            <option value="Georgia" data-calculate="100">Georgia</option>
                            <option value="Hawaii" data-calculate="50">Hawaii</option>
                            <option value="Idaho" data-calculate="100">Idaho</option>
                            <option value="Illinois" data-calculate="150">Illinois</option>
                            <option value="Indiana" data-calculate="100">Indiana</option>
                            <option value="Iowa" data-calculate="50">Iowa</option>
                            <option value="Kansas" data-calculate="160">Kansas</option>
                            <option value="Kentucky" data-calculate="40">Kentucky</option>
                            <option value="Louisiana" data-calculate="100">Louisiana</option>
                            <option value="Maine" data-calculate="175">Maine</option>
                            <option value="Maryland" data-calculate="100">Maryland</option>
                            <option value="Massachusetts" data-calculate="500">Massachusetts</option>
                            <option value="Michigan" data-calculate="50">Michigan</option>
                            <option value="Minnesota" data-calculate="155">Minnesota</option>
                            <option value="Mississippi" data-calculate="50">Mississippi</option>
                            <option value="Missouri" data-calculate="50">Missouri</option>
                            <option value="Montana" data-calculate="35">Montana</option>
                            <option value="Nebraska" data-calculate="100">Nebraska</option>
                            <option value="Nevada" data-calculate="75">Nevada</option>
                            <option value="New Hampshire" data-calculate="100">New Hampshire</option>
                            <option value="New Jersey" data-calculate="125">New Jersey</option>
                            <option value="New Mexico" data-calculate="50">New Mexico</option>
                            <option value="New York" data-calculate="200">New York</option>
                            <option value="North Carolina" data-calculate="125">North Carolina</option>
                            <option value="North Dakota" data-calculate="135">North Dakota</option>
                            <option value="Ohio" data-calculate="99">Ohio</option>
                            <option value="Oklahoma" data-calculate="100">Oklahoma</option>
                            <option value="Oregon" data-calculate="100">Oregon</option>
                            <option value="Pennsylvania" data-calculate="125">Pennsylvania</option>
                            <option value="Rhode Island" data-calculate="150">Rhode Island</option>
                            <option value="South Carolina" data-calculate="110">South Carolina</option>
                            <option value="South Dakota" data-calculate="150">South Dakota</option>
                            <option value="Tennessee" data-calculate="300">Tennessee</option>
                            <option value="Texas" data-calculate="300">Texas</option>
                            <option value="Utah" data-calculate="54">Utah</option>
                            <option value="Vermont" data-calculate="125">Vermont</option>
                            <option value="Virginia" data-calculate="100">Virginia</option>
                            <option value="Washington" data-calculate="180">Washington</option>
                            <option value="Washington DC" data-calculate="99">Washington DC</option>
                            <option value="Wisconsin" data-calculate="170">Wisconsin</option>
                            <option value="Wyoming" data-calculate="100">Wyoming</option>
                        </select>
{{--                        <input type="text" name="state_name" required id="state_name"--}}
{{--                               class="form-control step_form_control">--}}
                    </div>

                    <div class="col-12 col-md-6 form-group step_group">
                        <label for="type_of_industry" class="step_label">Type of Industry *</label>
                        <input type="text" name="type_of_industry" required id="type_of_industry"
                               class="form-control step_form_control">
                    </div>

                    <div class="col-12  form-group step_group">
                        <label for="number_of_ownership" class="step_label">No. of Ownership *</label>
                        <select name="number_of_ownership" onchange="onChangeNumberOfMembership(event)"
                                id="number_of_ownership" class="form_control step_form_control">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                        </select>
                    </div>

                </div>
                <div id="show_multi_member_info">
                    <div class="row mb-4 owners_info">
                        <p class="mb-5">Owners info *</p>
                        <div class="col-12 step_three_owners_info">
                            <div class="row">
                                <div class="col-12 col-md-6 form-group step_group">
                                    <label for="name" class="step_label"> Name *</label>
                                    <input type="text" name="name[1]" required id="name1"
                                           class="form-control step_form_control">
                                </div>

                                <div class="col-12 col-md-6 form-group step_group">
                                    <label for="email" class="step_label"> Email *</label>
                                    <input type="email" name="email[1]" required id="email1"
                                           class="form-control step_form_control">
                                </div>

                                <div class="col-12 col-md-6 form-group step_group">
                                    <label for="phone" class="step_label"> Phone *</label>
                                    <input type="text" name="phone[1]" required id="phone1"
                                           class="form-control step_form_control">
                                </div>

                                <div class="col-12 col-md-6 form-group step_group">
                                    <label for="ownership_percentage" class="step_label"> Ownership Percentage *</label>
                                    <select name="ownership_percentage[1]" required
                                            class="form-control step_form_control" id="ownership_percentage1">
                                        @for ($value = 100; $value >= 1; $value--)
                                            <option value="{{ $value }}">{{ $value }}%</option>
                                        @endfor
                                    </select>
                                </div>


                                <div class="col-12  form-group step_group">
                                    <label for="street_address" class="step_label">Street Address</label>
                                    <input type="text" name="street_address[1]" id="street_address1"
                                           class="form-control step_form_control">
                                </div>

                                <div class="col-12 col-md-6 form-group step_group">
                                    <label for="city" class="step_label">City</label>
                                    <input type="text" name="city[1]" id="city1"
                                           class="form-control step_form_control">
                                </div>

                                <div class="col-12 col-md-6 form-group step_group">
                                    <label for="state" class="step_label">State</label>
                                    <input type="text" name="state[1]" id="state1"
                                           class="form-control step_form_control">
                                </div>

                                <div class="col-12 col-md-6 form-group step_group">
                                    <label for="zip_code" class="step_label">Zip Code</label>
                                    <input type="text" name="zip_code[1]" id="zip_code1"
                                           class="form-control step_form_control">
                                </div>

                                <div class="col-12 col-md-6 form-group step_group">
                                    <label for="country" class="step_label">Country</label>
                                    <select name="country[1]" id="country1" required
                                            class="form-control country_list step_form_control">

                                    </select>
                                </div>

                                <div class="col-12  form-group step_group">
                                    <div class="row px-5">
                                        <div class="col-2"><i class="fa-regular fa-lightbulb"></i></div>
                                        <div class="col-10 ">
                                            This address is used for internal purposes only and will not be shared with
                                            any third parties or other outside agencies unless provided in any
                                            subsequent pages of the order process which require the intake of an
                                            address.
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-12 col-md-4">
                @include('web.part.sticky-sidebar')
            </div>
        </div>
        <div class="text-center">
            <button onclick="prevStep(event,3,'step_3')" class="btn btn-next "><i class="fa-solid fa-chevron-left"></i>
                Back
            </button>
            <button onclick="nextStep(event,3,'step_3')" class="btn btn-next ">Next <i
                    class="fa-solid fa-chevron-right"></i></button>
        </div>

        <div class="business_info text-center mt-4">
            <h5>Business Info</h5>
            <h4 style="color: #FF5700">Company Structure Wisely</h4>
            <p style="font-size: 16px">
                Decide which company structure is perfect for your business. Different entities are best for different
                business goals.
            </p>
        </div>
        <div class=" business_details_items mb-4">
            <div class="business_item">
                <h5>LLC</h5>
                <p>
                    Choose an LLC for the ultimate flexibility and protection of your personal assets—streamline your
                    business structure effortlessly.
                </p>
                <ul>
                    <li>Unlimited membership opportunities</li>
                    <li>Board of Directors not required</li>
                    <li>Personal asset protection from business liabilities</li>
                    <li>Pass-through taxation; profits taxed once at the owner level</li>
                    <li>Can elect (S Corp, Partnership, Disregarded entity, C Corp, etc.) how it wants to be taxed</li>
                    <li>Perpetual Existence</li>
                    <li>Can’t go Public</li>
                </ul>
            </div>
            <div class="business_item">
                <h5>S Corp</h5>
                <p>Well known for tax benefits and operational flexibility, maintaining your business’s growth momentum
                    while enjoying certain corporate structures without double taxation.</p>
                <ul>
                    <li>Limited to 100 Shareholders</li>
                    <li>Functions with LLC flexibility while offering corporate tax benefits.</li>
                    <li>Like LLCs, profits and losses pass directly to the owner’s personal taxes.</li>
                    <li>Profits are taxed only at the shareholder level, not at the corporate level.</li>
                    <li>personal tax reductions under S-corp filing status.</li>
                    <li>Capable of attracting investors through the issuance of stock.</li>
                    <li>Only for SSN holders</li>
                </ul>
            </div>
            <div class="business_item">
                <h5>C Corp</h5>
                <p>Offers advanced business growth and funding opportunities, ensures strong legal separation between
                    company and personal assets, and simplifies access to investment capital.</p>
                <ul>
                    <li>Unlimited Ownership</li>
                    <li>Ability to Issue Shares</li>
                    <li>Access to Preferred Stock</li>
                    <li>Ideal for Equity Financing</li>
                    <li>Limited Personal Liability</li>
                    <li>Double Taxation; Corporate and Shareholder Levels</li>
                </ul>
            </div>
        </div>
    </div>


    {{--    ============================= Step Four: Registered Agent & Business Address & Registered Agent and Business Address Package * ============= Figma : Funnel 3 =========================--}}
    <div id="step4" class="step mt-4" style="display: none">
        <div class="row mb-5">
            <div class="col-12 col-md-8">
                <div class="reg_agent_area">
                    <h5>Registered Agent & Business Address</h5>
                    <h6>Registered Agent</h6>
                    <p>A registered agent is a legal requirement and designated individual or entity responsible for
                        receiving legal and government documents on behalf of a business.</p>
                    <ul>
                        <li>Legal requirement</li>
                        <li>Protects your privacy, and acts as your business's public contact.</li>
                        <li>Receives legal documents for your business.</li>
                        <li>Handles state notices</li>
                        <li>Handles government correspondence confidentially.</li>
                    </ul>
                </div>
                <div class="business_address_area">
                    <h6>Business Address</h6>
                    <p>A business address provides a remote physical address for receiving mail and packages, enhancing
                        privacy and professionalism.</p>
                    <ul>
                        <li>Establishes Professional Appearance</li>
                        <li>Provides Privacy Protection</li>
                        <li>Mail Management</li>
                        <li>Handles state notices</li>
                        <li>Business Presence</li>
                    </ul>
                </div>
                <h6 class="p-3">
                    Registered Agent and Business Address Package *
                </h6>

                <div class="card-container">
                    <div class="card_item">
                        <input type="radio" id="free-plan" class="plan" onchange="planChange(event)" name="plan"
                               checked>
                        <label for="free-plan" class="card-content">
                            <div class="radio-circle"></div>
                            <h2>FREE</h2>
                            <p class="tagline">I'll appoint my Registered Agent</p>
                            <ul class="features">
                                <li>Use my address as the primary business address.</li>
                                <li>Provided Residential addresses will be publicly listed.</li>
                            </ul>
                            <div class="radio-button"></div>
                        </label>
                    </div>
                    <div class="card_item">
                        <input type="radio" id="monthly-plan" class="plan" onchange="planChange(event)" name="plan">
                        <label for="monthly-plan" class="card-content">
                            <div class="radio-circle"></div>
                            <h2>$25</h2>
                            <p class="tagline">Monthly</p>
                            <ul class="features">
                                <li>Registered Agent for One Month</li>
                                <li>Professional Business Address for One Month</li>
                                <li>Mail Forwarding for One Month</li>
                            </ul>
                            <div class="radio-button"></div>
                        </label>
                    </div>
                    <div class="card_item">
                        <input type="radio" id="yearly-plan" class="plan" onchange="planChange(event)" name="plan">
                        <label for="yearly-plan" class="card-content">
                            <div class="radio-circle"></div>
                            <h2>$259</h2>
                            <p class="tagline">Yearly</p>
                            <ul class="features">
                                <li>Registered Agent for One Year</li>
                                <li>Professional Business Address for One Year</li>
                                <li>Mail Forwarding for One Year</li>
                            </ul>
                            <div class="radio-button"></div>
                        </label>
                    </div>
                </div>

                <div id="free_plan_details">
                    <ul class="mb-3">
                        <li>Are you sure you can meet this state requirement?</li>
                        <li>You must provide a physical address for your Registered Agent in the state where your
                            business operates (no PO Boxes or PMBs allowed).
                        </li>
                        <li>In some states, this address (registered agent/business address) may appear on public
                            records along with your name, phone number, and email address.
                        </li>
                        <li>If You Don’t Have One, Choose a Monthly/Yearly Package for Registered Agent Address.</li>
                    </ul>
                    <div class="form_of_register_agenet" id="free_plan_form">
                        <h4>Your Registered Agent Address *</h4>
                        <div class="row">
                            <div class="col-12 form-group step_group">
                                <label for="step4_street_address" class="step_label">Street Address *</label>
                                <input type="text" name="street_address" required id="street_address"
                                       class="form-control step_form_control">
                            </div>
                            <div class="col-12 col-md-6 form-group step_group">
                                <label for="step4_city" class="step_label">City *</label>
                                <input type="text" name="step4_city" required id="step4_city"
                                       class="form-control step_form_control">
                            </div>
                            <div class="col-12 col-md-6 form-group step_group">
                                <label for="step4_state" class="step_label">State *</label>
                                <input type="text" name="step4_state" required id="step4_state"
                                       class="form-control step_form_control">
                            </div>
                            <div class="col-12 col-md-6 form-group step_group">
                                <label for="step4_zip_code" class="step_label">Zip Code *</label>
                                <input type="text" name="step4_zip_code" required id="step4_zip_code"
                                       class="form-control step_form_control">
                            </div>

                            <div class="col-12 col-md-6 form-group step_group">
                                <label for="step4_country" class="step_label">Country</label>
                                <select name="step4_country" required id="step4_country"
                                        class="form-control step_form_control country_list">
                                    <option value="Countries">Countries</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <p style="font-weight: bold">Note: Must be a valid and USA Registered Agent Address.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                @include('web.part.sticky-sidebar')
            </div>
        </div>
        <div class="text-center pb-4" style="text-align: center">
            <button onclick="prevStep(event,4,'step_4')" class="btn btn-next "><i class="fa-solid fa-chevron-left"></i>
                Back
            </button>
            <button onclick="nextStep(event,4,'step_4')" class="btn btn-next ">Next <i
                    class="fa-solid fa-chevron-right"></i></button>
        </div>
    </div>


    {{--    ============================= Step Five: EIN (Employer Identification Number) * ============= Figma : Funnel 4 =========================--}}
    <div id="step5" class="step mt-4" style="display: none">
        <div class="row mb-5">
            <div class="col-12 col-md-8">
                <h4>EIN (Employer Identification Number)</h4>
                <p>An EIN is a nine-digit number the IRS assigns to identify a business entity for tax purposes.</p>
                <ul class="px-5">
                    <li>Required for filing business taxes.</li>
                    <li>Essential for opening bank accounts.</li>
                    <li>Necessary to hire and pay employees.</li>
                    <li>Helps establish a business credit history.</li>
                    <li>Ensures compliance with IRS regulations.</li>
                </ul>
                <div class="step_5_note">
                    *Note 1: EIN delivery time is typically 10-25 days, but it can extend to 30-120 days during the
                    IRS's taxation season. Our Expedited service ensures EIN form submission within 1-3 days, with
                    issuance dependent on the IRS. We will provide continuous updates.
                </div>
                <div class="step_5_note">
                    *Note 2: Without an EIN, a company risks IRS penalties, banking and payroll issues, potentially
                    facing fines and operational disruptions.
                </div>

                <div class="py-4">
                    <div class="radio-option mb-4">
                        <input type="radio" onchange="enAmountChange(event)" id="add_en" name="en_amount"
                               class="radio-input" checked>
                        <label for="add_en" class="radio-label">Add an EIN to Only $69</label>
                    </div>

                    <div class="radio-option">
                        <input type="radio" id="no_skip" onchange="enAmountChange(event)" name="en_amount"
                               class="radio-input">
                        <label for="no_skip" class="radio-label">No, Skip</label>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                @include('web.part.sticky-sidebar')
            </div>
        </div>
        <div class="text-center pb-4" style="text-align: center">
            <button onclick="prevStep(event,5,'step_5')" class="btn btn-next "><i class="fa-solid fa-chevron-left"></i>
                Back
            </button>
            <button onclick="nextStep(event,5,'step_5')" class="btn btn-next ">Next <i
                    class="fa-solid fa-chevron-right"></i></button>
        </div>
    </div>


    {{--    ============================= Step Six:Operating Agreement / Corporate Bylaws * ============= Figma : Funnel 5 =========================--}}
    {{--    ============================= Step Seven:Expedited Filing * ============= Figma : Funnel 6 =========================--}}
    <div id="step6" class="step" style="display: none">
        <div class="row mb-5">
            <div class="col-12 col-md-8">
                <h4>Operating Agreement / Corporate Bylaws</h4>
                <p>An operating agreement (for LLC) or Corporate By-Laws (for Incorporation) is a legal document
                    outlining the ownership and operating procedures of a company among its members. </p>
                <ul class="px-5">
                    <li>Defines business structure and member roles.</li>
                    <li>Clarifies financial and management decisions.</li>
                    <li>Prevents misunderstandings among members.</li>
                    <li>Enhances business credibility and professionalism.</li>
                </ul>
                <div class="step_5_note">
                    *Note: If you choose our Expedited service, the agreement and company formation will be processed
                    within 1-3 days.
                </div>

                <p>Operating Agreement *</p>

                <div class="py-4">
                    <div class="radio-option mb-4">
                        <input type="radio" onchange="agreementChange(event)" id="add_agreement"
                               name="en_agreement_amount" class="radio-input" checked>
                        <label for="add_agreement" class="radio-label">Operating Agreement / Bylaws $99</label>
                    </div>

                    <div class="radio-option">
                        <input type="radio" id="no_skip_step_6" onchange="agreementChange(event)"
                               name="en_agreement_amount" class="radio-input">
                        <label for="no_skip_step_6" class="radio-label">No, Skip</label>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                @include('web.part.sticky-sidebar')
            </div>
        </div>
        <div class="text-right pb-4" style="text-align: center">
            <button onclick="prevStep(event,6,'step_6')" class="btn btn-next "><i class="fa-solid fa-chevron-left"></i>
                Back
            </button>
            <button onclick="nextStep(event,6,'step_6')" class="btn btn-next ">Next <i
                    class="fa-solid fa-chevron-right"></i></button>
        </div>
    </div>

    <div id="step7" class="step" style="display: none">
        <div class="row mb-5">
            <div class="col-12 col-md-8">
                <h4>Expedited Filing</h4>
                <p>Get the fastest filing with our Expedited Filing service when you need it urgently. Standard
                    processing may require more days or weeks. </p>
                <p>Jumpstart your business with our Expedited Filing! Get legal fast, skip the wait, and dive into the
                    market. Quick, easy, and ready for success. Let's go! </p>
                <div class="step_5_note">
                    *Note: Expedited filing service includes company formation, operating agreement, and registered
                    agent within 1-3 business days. EIN form submission will be done within this timeframe; processing
                    depends on the IRS. 
                </div>

                <p>Expedited Filing *</p>

                <div class="py-4">
                    <div class="processing_card-container">
                        <div class="processing_card_item active">
                            <input type="radio" id="add_expedited_processing" class="add_expedited_processing"
                                   onchange="expeditedChange(event)" name="expedited_processing" checked>
                            <label for="add_expedited_processing" class="card-content">
                                <div class="radio-circle"></div>
                                <span class="d-flex justify-content-between">
                                    <h3>Expedited Processing</h3>
                                    <h3>$25</h3>
                                </span>
                                <ul class="features">
                                    <li>1-3 business days</li>
                                    <li>Company formation only</li>
                                </ul>
                            </label>
                        </div>
                        <div class="processing_card_item">
                            <input type="radio" id="no_expedited_processing" class="no_expedited_processing"
                                   onchange="expeditedChange(event)" name="expedited_processing">
                            <label for="no_expedited_processing" class="card-content ">
                                <div class="radio-circle"></div>
                                <span class="d-flex justify-content-between">
                                    <h3>No, I'll wait for the standard Processing</h3>
                                </span>
                                <ul class="features">
                                    <li>1-15 business days</li>
                                </ul>
                            </label>
                        </div>

                    </div>

                    <p class="mt-3">
                        *The processing times will be determined based on the current state turnaround times and are
                        subject to change based on state processing.
                    </p>

                </div>
            </div>

            <div class="col-12 col-md-4">
                @include('web.part.sticky-sidebar')
            </div>
        </div>
        <div class="text-right pb-4" style="text-align: center">
            <button onclick="prevStep(event,7,'step_7')" class="btn btn-next "><i class="fa-solid fa-chevron-left"></i>
                Back
            </button>
            <button onclick="nextStep(event,7,'step_7')" class="btn btn-next ">Next <i
                    class="fa-solid fa-chevron-right"></i></button>
        </div>
    </div>

    <div id="step8" class="step" style="display: none">
        <div class="row mb-5">
            <div class="col-12 col-md-8">
                <h4 class="mb-3">Overview</h4>

                <div class="personal_info mt-3">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 style="font-weight: 400;">Personal Info.</h4>
                        <a href="" class="personal_info"> <i class="fa-regular fa-pen-to-square"></i> Edit</a>
                    </div>
                    <p><i class="fa-regular fa-user"></i> &nbsp; &nbsp; <span class="o_name">MD Najmul Hasan</span></p>
                    <p><i class="fa-regular fa-envelope"></i> &nbsp; &nbsp; <span
                            class="o_email">imonbg3@gmail.com</span></p>
                    <p><i class="fa-solid fa-phone"></i> &nbsp; &nbsp; <span class="o_phone">+8801775368537</span></p>
                </div>


                <div class="personal_info mt-5">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 style="font-weight: 400;">Business info</h4>
                        <a href="" class="business_info"> <i class="fa-regular fa-pen-to-square"></i> Edit</a>
                    </div>
                    <p><i class="fa-regular fa-address-card"></i> &nbsp; &nbsp; <span class="o_business_name">Business Globalizer LLC</span>
                    </p>
                    <p><i class="fa-solid fa-location-dot"></i> &nbsp; &nbsp; <span class="o_location">New york</span>
                    </p>
                    <p><i class="fa-solid fa-building"></i> &nbsp; &nbsp; <span class="o_business_type">eCommerce</span>
                    </p>
                    <p><i class="fa-solid fa-building-user"></i> &nbsp; &nbsp; <span class="o_number_of_person">1</span>
                    </p>
                </div>


                <div class="personal_info mt-5">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 style="font-weight: 400;">Owners info *</h4>
                        <a href="" class="owners_infoormation"> <i class="fa-regular fa-pen-to-square"></i> Edit</a>
                    </div>
                    <p><i class="fa-regular fa-user"></i> &nbsp; &nbsp; <span class="owner_name">MD Najmul Hasan</span>
                    </p>
                    <p><i class="fa-regular fa-envelope"></i> &nbsp; &nbsp; <span
                            class="owner_email">imonbg3@gmail.com</span></p>
                    <p><i class="fa-solid fa-phone"></i> &nbsp; &nbsp; <span class="owner_phone">+8801775368537</span>
                    </p>
                    <p><i class="fa-solid fa-percent"></i> &nbsp; &nbsp; <span class="owner_phone">100%</span></p>
                    <p><i class="fa-solid fa-location-dot"></i> &nbsp; &nbsp; <span class="owner_location">Demo, Mirpur-12, Ave-1, R#1,H#150</span>
                    </p>

                </div>

                <div class="service-list">
                    <div class="service-item">
                        <h3>State Fee</h3>
                        <div class="service-description">
                            <div class="item-content">
                                <svg class="service-item_icon" width="22" height="22" viewBox="0 0 22 22" fill="none"
                                     xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <rect width="22" height="22" fill="url(#pattern0_83_6)"/>
                                    <defs>
                                        <pattern id="pattern0_83_6" patternContentUnits="objectBoundingBox" width="1"
                                                 height="1">
                                            <use xlink:href="#image0_83_6" transform="scale(0.00195312)"/>
                                        </pattern>
                                        <image id="image0_83_6" width="512" height="512"
                                               xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAN1wAADdcBQiibeAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAACAASURBVHic7d17/GV1Xe/x12dmYGbAS1rWQxAiJUUfYNFvZsQLiCToEfWonexm4nCkTqesLD1dxGNlZudkF3tU51EqAyiZ1rGLUgJFeKmMYTAuiZgagkg3ryhzgZnP+eO7x9/vMAyzf7/f2vu71vq+no/H7yEP3Pu73nv99m+vN9+19ndFZiJJQxcRa4EXAM8ETge+dvJ//QtwFXAF8J7M3F0jn9Q3YQGQNHQR8Xzgl4ATDvHQzwNvB7Zl5jUzDyb1mAVA0mBFRACvB35qBU+/EbgAuCQz/63TYNIAWAAkDVZE/A7wQ6sc5m7gUmAb8OeZec+qg0kDYAGQNEiTaf93dTzsvwJvpZwi+EjHY0u9YgGQNDgRsR64DXjYDDdzNWVW4A8y8wsz3I5UhQVA0uBExHcBfzCnze2izDRsA67MzH1z2q40UxYASYMTEX8KPLfCpm8FLgIuzMxPVti+1BkLgKTBiYhPAt9UMUIC76PMCvxRZt5VMYu0IhYASYMyWfBnF7CudpaJO4F3Ui4c/JvaYaRpWQAkDUpEfA1lQZ8++hhlVuDizPxM7TDS/bEASBqUnheA/fYCl1PKwJ9m5p7KeaQDWAAkDcpACsBSnwMuoZwi+HDtMNJ+FgBJgzLAArDUdZRZgUsy8z9qh1HbLACSBmXgBWC/PcC7KWXgvZm5t3IeNcgCIGlQRlIAlrqDxeWHP1o7jNphAZA0KCMsAEv9HWVW4B2Z+aXaYTRuFgBJgzLyArDfXZTlhy8Arko/qDUDFgBJg9JIAVjqFuBC4KLMvKVqEo2KBUDSoDRYAPZL4K8pswLvysydlfNo4CwAkgal4QKw1Jcod0Pclpkfqh1Gw2QBkDQoFoAD3EQ5RXBxZv5L5SwaEAuApEGxABzUXuAvKN8ieHdm3l05j3rOAiBpUCwAU/kPyvLDF2Tm9bXDqJ8sAJIGZQYFYDdwJXAWsLbDcfviWsqswO9n5udqh1F/WAAkDcoMCsAXM/NrIuIo4BzgJcCjOxy/L3YDf0b5FsEVLj8sC4CkQZlVAbjXNp4MbAVeCDyww231xe3AxZRvEfxT7TCqwwIgaVDmUQCWbOtI4DuAc4HTgOhwu33xN5RZgXdm5pdrh9H8WAAkDco8C8C9tvtIyumBc4BjO9x+X3wF+CPK9QLvd/nh8bMASBqUWgVgyfbXAGdQZgWeD2zoMEtffILF5Ydvq5xFM2IBkDQotQvAfWT5bsr1Als6zNQX+4C/oswK/HFm7qqcRx2yAEgalD4VgKUi4nGUIvD9wDesOlX/fAF4O+XCwe21w2j1LACSBqWvBWC/iFgHPItSBs4GDutq7B75R8qswFsz899qh9HKWAAkDUrfC8BSEfEw4EWUMnDSLLZR2T3ApZQycGlm3lM5j5bBAiBpUIZUAJaKiE2UIvA9wENmvb0K/g14G+UUwY21w+jQLACSBmWoBWC/iFgPPI9SBs4E1sxr23O0nTIr8PbM/ELtMLpvFgBJgzL0ArBURDyCxeWHj6+RYcZ2AX9CKQN/mZn7KufREhYASYMypgKwVEScSpkV+E7gAZXjzMJtwEXAhZn5idphZAGQNDBjLQD7RcQDKCVgK3Bq5TizkMAHKLMCf5iZX6mcp1kWAEmDMvYCsFREHM/i8sOPqJtmJr4MvJNy4eAHa4dpjQVA0qC0VAD2myw/fCZlVuB5wPq6iWbinyizAhdn5u21w7TAAiBpUFosAEtFxEMoXyXcCmyqHGcW9gGXU8rAn2bm7sp5RssCIGlQWi8AS0XESZQi8CLgYZXjzMLngN+nnCK4tnaYsbEASBoUC8CBIuIwyrLDWynLEK+rm2gmrqfMCrwtM/+jdpgxsABIGhQLwP2LiG+g3JBoK/C4ynFm4W7g3ZQy8F6XH145C4CkQbEATC8itlCKwHcDY3yN/wK8lXKK4KbaYYbGAiBpUCwAyxcRG4DnA+cCZzDO5Yc/RJkVeEdmfrF2mCGwAEgaFAvA6kTEsSwuP/zIumlmYifwLkoZuDI9yB2UBUDSoFgAuhERAZxGmRX4DuDIuolm4lPAhcBFmfnPlbP0jgVA0qBYALoXEQ8EXki5XuDJlePMQgJXUWYF/m9m3lU3Tj9YACQNigVgtiLi0SwuP3xU3TQz8SXgHZQLB/+udpiaLACSBsUCMB8RsRY4izIr8FzGufzwRymnCC7OzDsqZ5k7C4CkQbEAzF9EPBT4Xsr1AidXjjMLe4H3Uk4RvDsz91TOMxcWAEmDYgGoKyK+hTIr8H3A11WOMwufBS6hnCL4h9phZskCIGlQLAD9EBGHA8+mlIH/BKytm2gmPkyZFfj9zPxs7TBdswBIGhQLQP9ExMNZXH74hMpxZmEP8GfABcDlmbm3cp5OWAAkDYoFoN8i4hQWlx9+UOU4s/AZ4GLKKYKP1Q6zGhYASYNiARiGiNhIWWBoK/A0IOommom/pcwKvDMz76wdZrksAJIGxQIwPBFxHIvLDx9XMcqs3AX8EeV6gfcNZflhC4CkQbEADNdk+eGnUWYFXgAcUTfRTHySxeWHb62c5X5ZACQNigVgHCLiQcB3UcrAEyvHmYV9wJWUWYF3ZeauynkOYAGQNCgWgPGJiBMoReD7gYdXjjMLXwT+ALggM6+uHWY/C4CkQbEAjNdk+eFnUsrAc4DD6yaaiY9QZgXempn/WjOIBUDSoFgA2hARX0dZbXAr8C2V48zCPcBfUL5FcGlm3j3vABYASYNiAWhPRJzM4vLDD60cZxb+HXgbZW2BG+a1UQuApEGxALRrsvzwf6aUgbMY5/LDOyizAm/PzC7f5wewAEgaFAuAACLiKODFlDLw6MpxZmE38CeU6wWuyMx9XW/AAiBpUCwAureIeBLlVsUvBB5YOc4sfBq4CLgwMz/e1aAWAEmDYgHQwUTEEcB/ocwKPJVxLj/8AcqswB9m5pdXM5AFQNKgWAA0jYh4JGXp4XOAY+ummYnPAb8A/M5Kv0FgAZA0KBYALUdErAHOoMwKPB/YWDdR5z4GfG9m7ljuEy0AkgbFAqCViogHU25TfC6wpXKcLn0WODUzb1rOkywAkgbFAqAuRMTjWFx++Bsqx+nCp4EnZOZnpn3CmhmGkSSplzLzI5n5SuARwHMpX7mb+2p8HXoEcP5ynuAMgKRBcQZAsxIRDwNeRJkZOKlynJXYAzwqMz89zYOdAZAkCcjMf8/MX8/MxwObgN+m27I5a4cD5037YAuAJEn3kpk7MvNHKLcn/m7gMqDz1fhm4MRpH2gBkCTpIDJzd2a+IzOfCXwj8Cqgs9X4ZuCEaR/oNQCSBsVrANQHEXEq5VqB7wQeUDnOUndl5pHTPNACIGlQLADqk4g4klICtgKnVY4DsDszN0zzQAuApEGxAKivIuJ4yvLDLwaOqRTDAiBpnCwA6rvJ8sNPp8wKPA+Y6oDcEQuApHGyAGhIIuIhwPdQysCmOWzSAiBpnCwAGqqIOJFSBF4EfP2MNmMBkDROFgANXUQcBpxNKQPPAtZ1OLwFQNI4WQA0JhFxDHBrh0NOXQBcCEiSpHr+vdaGLQCSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKD1tUOoJWLiPVA1M4hzdn6rgeMiA0reV5m7uo6izQvFoCBiIi1wDOBLcDmyc/XVQ0ljcODgZ0reWJEfBbYDlw9+XlvZu7tMNvcTD5jngZsmvwsAHuBHZOfa4CrMnNftZCrEBFrgDNZfG3fxuLru5bye7wyM7NayDmLhl7rYEXECcCFwBMqR5F0/64GtmbmR2oHWY7JZ8w24JRDPPSDlNf38dmn6k5EPAa4AHjSIR76V8BLM/OWmYeamMw+raiAHsTuzJxqRstrAHosip8EPowHf2kItgDXRsRPTf6Ls9ciYk1EvJLyGXOogz/AU4DrIuLHIqL3px8nr+8VwD9w6IM/wLcDN0TEf59tsn7wFEC/vQx4Q+0QkpZlPfDLwD7gVypnOZT/Abx+mc85AviNyT+/sds4nXsl5XexHA8Afjsi9mbm784gU294CqCnIuKbgeuAjbWzSFqRXcDJmfnR2kHuS0Q8jnLue6UXVd4FfEtfTwdExGMpMxsrfX13Aidm5q3dpTqQpwD0/5lMHV6EB39pyDYA2yYX1/XKJNM2VveNiiMor693x5GOXt8DgTd3k6ifeveLEwBnAE+sHULSqp1C+Xvum/3fKFqtpwCndzBO186mm+umzoyI0zoYp5csAP20qXYASZ3p4kDbtS4z9fHzqsvX18ffXycsAP3Uxz8oSSvTxwPI5g7HWuhwrK50+Rk62s9jC0A/9fEPStLKdHmw7crYC0CXmSwAmquH1w4gqTO9+nueLCHe5SqiR3c4Vle6vPCydxdxdsUCIElt6XoBnz4uCHRNh2Nt73CsXrEASJLGpssC0OVYvWIBkCSNzdU9HatXLACSpLF5D+Uuf6t1FfC+DsbpJQuAJGlUMvMe4CXAnlUM8xXgv4759sAWAEnS6GTmjcBrVzHET2fmJ7vK00cWAEnSWL0eeDXLmwnYCfwk8NszSdQjFgBJ0ihl5t7M/EXKwkDTXBPwQcodDn9tzFP/+62rHUBzsbt2AGlgVnMXOfVMZt4YEacAz6Yszbxp8rOX8jW/a4APAX+RmfuqBZ2zaKDkDE5E7KLbD6CNmbmrw/GkUYuITj8YM7M3i+XUvP+8DlTz9+EpAEmSGmQBkCSpQRYASZIaZAGQJKlBFgBJkhpkAZAkqUEWAEmSGmQBkCSpQRYASZIaZAGQJKlBFgBJkhpkAZAkqUEWAEmSGmQBkCSpQRYASZIaZAGQJKlBFgBJkhpkAZAkqUEWAEmSGmQBkCSpQRYASZIaZAGQJKlBFgBJkhq0rnYASZJmLSLWAk8DNk1+FoC9wI7JzzXAVZm5r1rIObMASJJGLSJOALYBp9zH//0o4IWTf/5ARGzNzE/MLVxFngKQJI1SRKyJiFcCH+a+D/73dipwXUT88GyT9YMFQJI0Vj8F/G9gwzKecyTwWxHxQ7OJ1B+RmbUz6F4iYhewvsMhN2bmrg7Hk0YtIjr9YMzM6HK81YiIDcDODofcnZnLOcDORUScRDmvf/gKh/gK8PjM/GR3qQ5U8/fhDIAkaVQi4jDgIlZ+8IcyE7AtIkZ7nBztC5MkNes5wMkdjHMacHoH4/SSBUCSNDabejpWr1gAJEljYwGYggVAkjQ2Cx2OZQGQJKnvJlfVP7TDIY/qcKxesQBIktQgC4AkSQ2yAEiS1CBvBqSZmSygcRawmcU7cEFZnWs7cDVwRc5xOcpJpqcBW5b8jPYcnyQdjEsB99AYlgKOiMcAFwBPOsRD3w+cO4+7b0XE8ZQ7gj1l1tuSlnIp4PkZ2utzKWCNxuTuW68A/oFDH/yhrLR1fUT8WETM5EMyih8HrsODvyQBngJQ914J/PIyn3ME8BuTf35jt3EA+FHg12cwriQNlqcAemiopwAi4rGU+26vNPtdlLtvdXY6YDLtfx2lZEhVeApgfob2+jwFoMGLiLWU8+urKS5HABd0dSpgcsHfNjz4S9IBLADqyrOAJ3QwzmnAmR2MA+Vqf8/5S9J9sACoK5s7HGtLz8aRpNGxAKgr39bhWF2VCQuAJB2EBUBd6bIAdHX3LQuAJB2EBUBd6c1VzpKkQ7MAqCvXdjjWNR2Ns72jcSRpdCwA6kofC8DVHY0jSaNjAVBXujpoQ3f/5e4MgCQdhAVAXbkU2NHBOH8LXN7BOABXAh/qaCxJGhULgDqRmfcALwH2rGKYXZQ7A+7rKNNeYOtkXEnSEhYAdSYzbwReu4ohXp2ZN3eVByAzPwr8zy7HlKQxsACoa68HXs3yZgJ2Az8N/NpMEsGvAj8z2Y4kCQuAOpaZezPzF4EFprsm4O+BkzPzf3U19X8fmfZl5i9TFivymwGShLcD7qWh3g743iJiHXA2ZWW/b5v8JOUrg9dSrtL/88m5+nllWgs8Y5Jp/8/D57V9tcnbAc/P0F5fzbwWgB4aSwGQhioiOv1gtADMz9BeX828ngKQJKlBFgBJkhpkAZAkqUEWAEmSGmQBkCSpQRYASZIaZAGQJKlBFgBJkhpkAZAkqUEWAEmSGmQBkCSpQRYASZIaZAGQJKlBFgBJkhpkAZAkqUEWAEmSGmQBkCSpQRYASZIaZAGQJKlBFgBJkhpkAZAkqUEWAEmSGmQBkCSpQRYASZIaZAGQJKlBFgBJkhpkAZAkqUEWAEmSGmQBkCSpQRYASZIaZAGQJKlBFgBJkhpkAZAkqUEWAEmSGmQBkCSpQetW8+SIWAOcBWwGFoBNwNEd5FK3dkZE7Qyaj9uBHZOfa4DLMnPvrDYW5Y31dGAL5e9/AThmVtuT1J3IzJU9MeJ4YBvwlE4TSerS3wPnZObNXQ8cEcdRPgNO73rsscnM3jTwiNgA7OxwyN2ZuaHD8VZlaK+vZt4VnQKIiB8GrsODv9R3TwA+HBEvjw6ngSLiB4Ab8OAvDdayTwFExA8BvzWDLJJmYyPwa0ACv7HawSLiJcDvrnYcSXUt6xRARDwSuB44cmaJJM3KTuBbM/NjKx0gIh4B3Ag8uLNUDfAUwPwM7fUN4hTA5IK/bXjwl4ZqI3Dh5G95pd6MB39pFJbzQXA6cNqMckiajycCZ6zkiRGxGXhGt3Ek1bKcArBpZikkzdPCCp+3udMUkqqyAEjtWenf8pZOU0iqygIgtccZAEnLKgBHzSyFpHnyb1mS9wKQNLXttQNI6o4FQNK0rq4dQFJ3LACSpuUMgDQiFgBJU8nM7cBltXNI6oYFQNJyvBT4Yu0QklbPAiBpapn5aeDHa+eQtHoWAEnLkpkXAj8IfLlyFEmrYAGQtGyZ+XvAScBVlaNIWqF1tQNIGqbMvCUizgCeTlkmeBNllcFjqgaTNJWaBWBjZu6quH1pEGZwv/DOZGYCV0x+RiMisnYGadY8BSBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1aF3tAPMQEWuAxwALwNFA1E20KncAO4CbMnNv7TDTiIi1wAmU/X9U5TirkcDtlP1/c2buq5xHklZs1AUgIs4EXg2cDDygcpyu3RURHwZ+KTP/vHaY+xIRzwJ+FvhW4MjKcbr25cn+/8XMvLx2GElarlGeAoiIB0TE/wEuB05lfAd/gCOAJwOXRsSFEfE1tQPtFxEPioi3AJdSMo7t4A/lPXUqcFlE/F5EPKh2IElajtEVgIj4RuAG4L/VzjJH5wD/GBGPrR0kIo4HbgTOrZ1ljs4Dbpi8dkkahFEVgIgIYBtwXOUoNRwFXBwR1U7rTK61uAg4plaGio4Ftk32gST13tg+rH4EeFrtEBVtAn6m4vZ/EnhSxe3X9hTgR2uHkKRpRGZO98CIXcD6Dre9MTN3dTVYRDwCuJlybrxldwMnZebN89xoRHwTcBPdvkeG6C7gMZn56a4GjIgNwM6uxgN2Z+aGDscbnYiY7oNxSpnZm28ejf39NLTXVzPvmL4FcDoe/AEOA86klKF5+nY8+EN5D54OvK1yjrmYnHY7E9hMmYFaoM1TQNLgjKkALNQO0CObGtlmXy3QQAGIiEcBbwGeWjuLpOUb0zUAHoAW1ShDFrBFo38vRsTLgOvw4C8N1phmAE6qHaBHHhsR6zLznjlu0/2/aNT7IiLOA36zdg5JqzOmGYDeXITSA2uZf7nz/P+i0b4XI+JY4A21c0havTEVAEmz9ybAVQ+lEbAASJpKRGwGzqqdQ1I3LACSprW5dgBJ3bEASJrWltoBJHXHAiBpWs4ASCNiAZAkqUEWAEnTurp2AEndsQBImpYFQBqRMa0E2LXXAfNcSe98ygI+Kn5+ztt7zZy3N0QWAGlExnQ74F7nO5QR5B/07VM7zt/p7UP7dHvTiHgPcHaHWZrg7YDnZ2ivr2ZeTwFIWo4fBL5QO4Sk1bMASJpaZt4OvLx2DkmrZwGQtCyZeSFlJuDLlaNIWgULgKRly8zfo9z2+KrKUSStkN8CkLQimXlLRJwBPJ2yTPAmYAE4pmowSVOxAEhasSxfI7pi8jMaXX+rReojTwFIktQgC4AkSQ2yAEiS1CALgCRJDbIASJLUIAuAJEkNsgBIktQgC4AkSQ2yAEiS1CALgCRJDbIASJLUIAuAJEkNsgBIktQgC4AkSQ2yAEiS1CALgCRJDbIASJLUIAuAJEkNsgBIktQgC4AkSQ1aVztAj50fEffMcXv+LpaIiJ+rnUGSxsyDzsG9qnaAxr2mdgBJGjNPAUiS1CALgCRJDbIASJLUIAuAJEkNsgBIktQgC4AkSQ2yAEiS1CALgCRJDRpTAdhdO0CP7AXmuYohwJ45b6/PfC9K6r0xFYAbagfokY9m5rwLgPt/kftCUu+NqQDsqB2gR2rsC/f/IveFpN6zAIyTBaAu94Wk3hvTzYCuAnYBGyrnqO0e4IoK2/0rynUAh1fYdp/sorwXmxUR64GonUPS/RtNAcjMWyPiZ4Bfr52lstdl5k3z3mhmfiIiXgO8ft7b7pnzM/PW2iHmJSICOBM4BdgCbAa+vmooSVOJzJzugRG7gPUdbntjZu7qcLz9H0ZXAqd3Oe6A7ABOqXABIAARsRb4APDEGtvvgb8BTsvMfV0OGhEbgJ0dDrk7M1c9UxYRjwLeAjx19ZHGLTN7MyPS1/dTV4b2+mrmHdM1AGRpM1uBWypHqeEzwPfXOvgDZOZe4BzgtloZKroNeEnXB/++ioiXAdfhwV8arFEVAIDMvAV4PPDmylHm6RLgxBpT//eWmf8EnARcXDvLHG2j7P+P1w4yDxFxHvCbwJG1s0haudEVAIDMvDMzzwOeDWxnnAuz7KFM+b8gM1+UmZ+vHWi/zPxiZp4DPJ+ScYyLBO2mvLeek5nnZuaXageah4g4FnhD7RySVm9U1wAcTEQcBpwILABHM+wrlO+gHFSvz8xBHFgj4nDKrMACcFTlOKuRwO2U/X9jZt49j4326ZxmRFwGnNVhliZ4DcD8DO311czbRAGQhqwvH2gRsRm4usMczbAAzM/QXp8XAUoagi21A0jqjgVA0rQsANKIWAAkTWtz7QCSumMBkDStvbUDSOqOBUDStLbXDiCpOxYASdOyAEgjYgGQNC2/AiiNiAVA0lQycwdwae0ckrphAZC0HD8IfKF2CEmrZwGQNLXMvB14ee0cklbPAiBpWTLzQuAHgCZugCSNlQVA0rJl5psoN3i6vHYWSSuzrnYAScOUmbcCz4iI0yirBG6i3PHxGIZ9x03o9sZnUi9ZACStSma+H3h/7RxdiojpbpMqDZinACRJapAFQJKkBlkAJElqkAVAkqQGWQAkSWqQBUCSpAZZACRJapAFQJKkBlkAJElqkAVAkqQGWQAkSWqQBUCSpAY1cTOgiDgMOJFyp7KjGfadyu4AdgDXZ+ae2mGmERGHU24duwAcVTnOaiRwO2X/35iZd1fOI0krNuoCEBFnA68BHs/4bu+5JyJuAF6XmX9cO8x9iYjnAedTDv6HV47Ttd0RcT3wC5n5ntphJGm5RnkKICIeGBFvAt5DuU/52A7+UA6oC8C7IuJtEfGQ2oH2i4gHR8RFwB9TMo7t4A/lPbUZeHdEXBARD6odSJKWY3QFICKOA64HXlo3yVx9H3BjRDy2dpCI+GbgBuDFtbPM0VbK/j++dhBJmtaoCkBEBLANOK5ylBqOAt4aEdVO60TEWuAi4JhaGSo6BrgwIkb1NyVpvMb2YfVjwOm1Q1S0QDnnXssrgSdW3H5tTwZeXjuEJE0jMnO6B0bsottz6Rszc1dXg0XEscDNwIauxhyoe4DHZ+ZN89xoRDwK+AjjPN+/HLuAx2TmrV0NGBEbgJ1djQfszszW/07uV0RM98E4pczszTePxv5+Gtrrq5l3TDMAp+PBH8o3O86ssN1vx4M/lPfg6bVDSNKhjKkALNQO0CM19oX7f5H7QlLvWQDGyQJQl/tCUu+NqQCcVDtAj5xQ4dsA7v9F7gtJvTemAjDGxX5Wai3zX+XR8/+LfC9K6r0xFQBJkjQlC4AkSQ2yAEiS1CALgCRJDbIASJLUIAuAJEkNsgBIktQgC4AkSQ2qdu/4AXgd5c5683I+ZQEfFT8/5+29Zs7bk6SqxnQ74F7nO5QR5B/07VM7zt/p7UOHdnvTMRj6+/n+jP39NLTXVzOvMwCSOhUR64HeHPAk3TcLgKQVi4g1wNnAFmAT5U6ID6saStJULACSViQivhm4CHhi7SySls9vAUhatoj4UeA6PPhLg+UMgKRliYjzgDfWziFpdZwBkDS1iDgWeEPtHJJWzwIgaTneBDyodghJq2cBkDSViNgMnFU7h6RuWAAkTWtL7QCSumMBkDQtC4A0IhYASdPaXDuApO5YACRNa2/tAJK6YwGQNK3ttQNI6o4FQNK0LADSiFgAJE3r6toBJHXHAiBpKpm5A3hP7RySumEBkLQcPwB8vnYISatnAZA0tcy8A3hZ7RySVs8CIGlZMvMS4BzgC7WzSFo5C4CkZcvMi4ETgctqZ5G0MutqB5A0TJl5O/DMiDiVskzwJmABOAaImtk6sL52AGnWLACSViUzPwB8oHaOLkVE1s4gzZqnACRJapAFQJKkBlkAJElqkAVAkqQGGb1B8wAABKlJREFUeRHgwZ0fEffMcXv+LpaIiJ+rnUGSxsyDzsG9qnaAxr2mdgBJGjNPAUiS1CALgCRJDbIASJLUIAuAJEkNsgBIktQgC4AkSQ2yAEiS1CALgCRJDRpTAdhdO0CP7AXmuYohwJ45b6/PfC9K6r0xFYAbagfokY9m5rwLgPt/kftCUu+NqQBcUztAj9TYF+7/Re4LSb03pgKwo3aAHqmxL9z/i9wXknpvTAXgr4G7aofogbuByyts9y/x3DeU9+Bf1w4hSYcymgKQmZ8Gfrp2jh54bWbePO+NZuY/A6+e93Z76FWT96Ik9dpoCsDEb9H2f31dA7y+4vZ/Ffjbituv7YPAb9YOIUnTGFUByMwEtgK3VI5Sw2eAF1e4+v+rMnMfcA5wW60MFd0GbJ3sA0nqvVEVAIDM/BTweODNtbPM0SXAiZl5U+0gmflx4CTg4tpZ5mgbZf9/vHYQSZrW6AoAQGbemZnnAc8GtjPOi9P2UK42f0FmvigzP1870H6Z+cXMPAd4PiXjGBcJ2k15bz0nM8/NzC/VDiRJyxFl1nyKB0bsAtZ3uO2Nmbmrw/EOKiIOA04EFoCjgZjHdmfkDspB9frMHMSBNSIOp8wKLABHVY6zGgncTtn/N2bm3fPYaERsAHZ2OOTuzNzQ4XijExHTfTBOKTN785kz9vfT0F5fzbxNFABpyIb2gTYGFoBl6dX7aWivr2beUZ4CkCRJ988CIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSgywAkiQ1yAIgSVKDLACSJDXIAiBJUoMsAJIkNcgCIElSg9ZV3Pb6iKi4eWkw1nc9YERs6HpMHVzP9vfY309De32d551WZOaB/zJiHfBsYDOwAGwCvna+0SRJ0gp8FrgG2AFsB96dmXvv/aADCkBEnAhsoxz0JUnSsG0HzsnMm5b+y69eAxARayLiZymNwYO/JEnjsBm4NiJeEUvOvX91BiAiXgH8SqVwkiRp9n48M98IkwIQEY8FrgX6dCGHJEnq1k7g5My8eU1ErAUuwoO/JEljtxG4OCLWBnAWcFnlQJIkaX6esYbyNT9JktSOBQuAJEntWQjgn4HjKgeRJEnzc8sa4IDVgSRJ0qjtXUNZLlCSJLXjmjWUlf8kSVI7dqyhrBEsSZLasX0N8D7gytpJJEnSXFwJvG//UsDfCNwAPLByKEmSNDt3Aidl5qfWAGTmp4CfqJtJkiTN2E9MjvmLtwPOzDcDL6W0A0mSNB53Ai+dHOuBJbcD/uq/KKcDLgDOmG82SZI0A1cC5+7/L//9DigAABERwFOBzZSlgjcBRwMx+5ySJOle1k7+91CL9yVwO2WNnx2Ub/q9L+/jYP//AK5WrwYif3oBAAAAAElFTkSuQmCC"/>
                                    </defs>
                                </svg>
                                I’ll appoint my Registered Agent
                            </div>
                            <h4 class="item_price">$100</h4>
                        </div>
                    </div>
                    <div class="service-item">
                        <h3>Registered Agent and Business Address Package</h3>
                        <div class="service-description">
                            <div class="item-content">
                                <svg class="service-item_icon" width="26" height="26" viewBox="0 0 26 26" fill="none"
                                     xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <rect width="26" height="26" fill="url(#pattern0_78_220)"/>
                                    <defs>
                                        <pattern id="pattern0_78_220" patternContentUnits="objectBoundingBox" width="1"
                                                 height="1">
                                            <use xlink:href="#image0_78_220" transform="scale(0.00195312)"/>
                                        </pattern>
                                        <image id="image0_78_220" width="512" height="512"
                                               xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAACAASURBVHic7d13uF9VmfD970lCCCUkSCf0KkRAxAICEoqCKLZREH1VrIyigzo6oqggPozOY2csgziCylhA4VEUBhAEKTaKKCogYCSEiCSEEgKp5/1jnSOHcE5O2/dau3w/13VfOIyuvdY+u9y/tVfpQWqOjYCZwHYDYhtgGjAFWB9YE1gbeBB4DHgEeAi4H7gTuKPvn3cCvweW5GyAJNVFT+kKSKuxG7AfsDewD7BjxeUvBa4HfglcC1wF3FvxMSRJ0jAmkF74nwRuA3ozxwrgOuBkYOfYpkqSpB2Bz5B+fed+6a8urgfeDkyNa7okSd0yATgEOAdYTvmX/eriIeB00icJSZI0Bj3AEcBNlH+xjyUuBfao/KxIktRih5C61Uu/xMcbK0g9F1UPSpQkqVV2BC6j/Iu76lgK/DuwVnWnSpKk5psEHA8sovzLOjLuAJ5f0TmTJKnR9gB+R/mXc65YCXwdWLeKkydJUhO9nrQCX+mXcom4BWcLSJI6ZgrwVcq/hEvHo8BbxnkuJUlqhM2B31L+5VunOI203oEkSa20CzCb8i/cOsb5OEtAktRCzwHuo/yLts7xM9KOhZIktcIsujvYb7RxPTB9TGdZkqQaeRZpjfzSL9YmxS9wmqAkqcGeBsyn/Au1ifFT0mwJSZIaZSvgHsq/SJsc55A2RZKkYiaWroAaZQpwEbBz6Yo03ExgGXBV6YpIkjQS/035X89tiRXA4aM7/ZJUHbshNVLHAV8sXYlV3AXcBtwKzAEeBhaTZiZMB9YBpgI7AE8FdqJeI/EXkgZT3lG6IpIkDeZpwBLK/2qeDXwFOBLYaIxtmQm8CziPekxh/CV+ipMk1dAk4DeUe0EuAs4krTlQ9bK6U4E3AlcUbF8v8IGK2yVJ0ridSJmX4kPAF4BN45sIpO2LvwksD2zTUPEYqWdCkqRa2JX0csr5MlwGfBpYL0P7BrM7cOUwdYyIX+LGQZKkmriIvC/Ba4DdsrRs9XqAN5B/j4NjMrRNkqTVOpB8L76VpO7+NbK0bOQ2AS4l33m4G1g7S8skSRrEBOBG8rz05gOH5GnWmEwCPkG+JOCDeZolSdKTvY48L7u7gF0ytWm8jiXPAMEHgA0ytUmSpH/oAW4m/kX3J2DLTG2qyivIsx7Ch3M1SJKkfocR/4K7G9g6V4Mq9mrSMr6R5+de3DFQkpTZxcS+3ObTnG7/obyD+CTpmFyNkSRpJmlEftRLbQX1HvA3GmcQmwDclK8pkqSu+zSxL7VT8jUl3BTiZ0rsla01kqTOmkAalR/1MruG9m16swuxKyV+Ol9TJEld9TziXmTLSGvtt9EpxJ23Obg8sCQp2JeJe5F9KmM7clsLuIO4c7d/vqZIkrrobmJeYAspt7FPLq8mLgH4TMZ2SJI6ZifiXmBtGvg3lInALcScv+sztkOS1DFvJebltQjYMGM7SnojMedwBbB+xnZIkjrkbGJeXl/P2YjCppA+d0Scx5dkbIekjphUugIdtQ6wHbAFsG7hugAcFFTut4LKraPHgHOAtwWU/QZgzYByR+teYB5wOykxkSSN0EuBHwGLifvmXpeYTfemsO1P+fOeI+aSZo3sWM1pk6T22hG4mvIP7pzxlUrOXLNMBO6n/LnPFUuBzwGTqzh5ktQ2BwILKP+wzh1HVnHyGug8yp/73HEV3RnsKUkjsjvwMOUf0LljJbBxBeevid5J+fNfKgmwJ0CSSCvE3Un5B3OJuKuC89dU+1L+/JeKz1Vw/iRl0rVBWjkdD2xbuhKF3FK6AgV1ue3H4cBAqTFMAGJMBN5buhIF3Vq6AgUtAOaXrkQhawDvLl0JSSNjAhBjX2Cj0pUoaG7pChR2d+kKFPRSoKd0JSQNzwQgRtd3cFtUugKFPVy6AgXNIC1yJanmTABizChdgcK6/AIEE6AtSldA0vBMAGJsULoChT1QugKFLSxdgcJcE0BqABOAGF3/BnpP6QoUNq90BQrzuSI1gDeqqtZL2gegy2aXroAkDccEQFX7DXBf6UoU9uPSFZCk4ZgAqGrnlK5ADcwGritdCUlaHRMAVekeurkL4GA+XLoCkrQ6JgCqSi/wLmBx6YrUxMXYGyKpxkwAVJWPk7bC1ePeBNxQuhKSNBgTAI3XCuAE4KTSFamhR4BZwAWF6yFJT2ICoPH4JXAA8B+lK1JjDwMvB/4FZ0dIqpFJpSugRrmXNNDv58D5ff/sLVqjZlgB/CdwFmmznJcCM4EtgXXLVUtSlzVtxbppwE7AU/tiJ2ATYB1gOulhuk5ftM25wJGlK6HWaWsCt5D0CeYR0t4MC4G7gNtI21X/CbgTWFaqglJpde8B2Bo4EDiI9C11y6K1kdQU6/fF6iwHfgf8DLgcuAo3spKK6QGeB/wXcAfp14mRwillilD6uq5TLAOuBU4k/fiQlMGOwMdIXXKlHwJ1DRMARSh9Xdc1VpB6Bt4IrDfmsytpSIcBV1D+Zm9CmAAoQunrugmxmNQrue0Yz7GkPj3AEcCvKH9jNylMABSh9HXdpFhBug93GdOZljruCOBmyt/ITQwTAEUofV03MVYA3wO2Gf3plrpnBvBNyt+4TY6fjPqsS8MrfV03ORYDJwNrjvakS10wGfgQaS5u6Zu16XH9KM+9NBKlr+s2xC3AIaM98VKb7UKaY1v65mxL3Dq60y+NSOnruk3xVWCt0Z1+qX1eT1p9q/QN2aaYPZo/gDRCpa/rtsVNpFVKpdqrejOgKcAXgG/QzuV4S3LJUqn+didtAf2W0hWRctoc+C3lM/C2xu9G/qeQRqz0dd3m+DzuuKoaq+ri3A64EtijovL0ZG4lKzXL8aRNvKaUrog0mCoSgL2AXwA7VFCWhnZ/6QpIGrVXAD/CbZ9VQ+NNAGaR1sveePxV0TB6S1dA0pg8n/ScfErpikgDjScB2IuU2U6tqC6S1FbPBC4A1i5dEanfWBOA7Ukr0/nyl6SReS5pSe9JpSsiwdgSgM2BS4FNKq6LJLXdi4CvkTZFk4oabQKwNnAhbospSWP1BuCU0pWQRpsAfBGn+knSeH0IOKx0JdRto/kW9TrgjVEVGaO7gNtI6+TPAR4m7dD1SMlKAe8B9ilcB6mUz5GmBpc0nbQa6VTSFOWnAjv1/fs6mEDaIXVPYG7hukirtQvp5Vp6Za3ZwFeAI4GNIhs8TudQfdvPydoCdUXEffqqrC0YnZnAu4DzqMcupVfioEDV2GTK7uq3CDiTtOZAU5bVNAFQU3QtARhoKqlX8wrKJgEfC26nNGYfpMxN8RBpY6FN45tYORMANUWXE4CB9iB1yS8n/7NuCamXVaqVrcnfTbYM+DSwXob2RTEBUFOYADzR7qRu+dxJwE9zNE4aaLgu9S+Qd+Wqa4FnAO8j9QBIUk6/I31uPAaYn/G4BwNHZzyetFovJl/2u4I0L3ZilpbFswdATWEPwNBmkLc34B6a3fOphhmqB6AH+ESmOiwADgU+SkoEJKkO5pJ+mX8y0/E2I20hLBX1cvJkvHOB3TK1KSd7ANQU9gCMzDGk8UnRz8QFuMeKMhmqB+BDGY59C7A38PsMx5Kk8TgLOApYGnycpwDHBh9DAgZPAA4lbV0ZaS5pGcw5wceRpKqcR1rHf2Xwcd4HrBV8DGnQBOCE4GMuAJ4P/DX4OCVF/EqwW1BVixpwtiSo3Dr4Lmmp70ibkD45SFntQMpuo75vrQBekK015fwX1Z+7m7K2QF2wCzH3+ayMbSjlDGLHAvwmX1PUVav2ALyO2H2qTwUuCSy/Lh4OKHMH7BZUtaIG4C4KKrdO3gX8NrD8ZwJPCyxfeoIe4E7iMtpraM88/+F8gJhz+JKcjVDr/Q8x1+nWORtR0C7AY8Q9M3NNP5R4HnEX8jLSWttdETWN8oKcjVCrbULMDp+Lac6mXVU4hbjn5t1050eTCvsKcRfypzO2ow52Je5cPi9jO9ReXyLm+uzaWJW1gDuIu99nZWuJOu12Yi7ghXRvecvJwKPEnM87gA3yNUUtdDhxu959O2M76uLVxCUAp2ZshzpqK+Iu4FMytqNOLifunF6B0wI1Ns8EHiDu2nxbvqbUxkTSwmYR5/PajO1QR72RmIt3EbBhxnbUyUeIe8j2klZQ3CFba9QGryF9o4+8Lrt6TUY9Q5fRvR5UZfYtYi7er+dsRM3sTeyDtpf0meFTpAFd0lCeA1xK/PV4R64G1dAU0ufOiPP6ooztUIdM6vvnAUHlfyuo3Cb4FemBuH3gMaaQlg19D/AL4OfAPODewGOq/iYDm5KuvcOAbTMd9zuZjlNHj5E27Ir4BDIL+ElAuRLTiMlaZ9Ot6UCDOZn4X12GUZd4Kt22PzHn9aKcjVB3TAB2Dir7QuI3zai7s0ijraW2u4Y0EK7LriV9Bqha1DNaHTeBuKz9Z0HlNsls4HulKyFl8O+lK1ADK4ArA8rdGpcBV4AJwE4B5fYScyM00anYE6J2+y12U/e7LKDMCcCOAeWq46I+AdwN/D2g3Cb6E91cHEXd8SFS0i+4MahcPwOochNIo4Wr1vVvgat6H2nxFaltzsdf/wNFPfs2DipXHTYBWDeg3FsDymyye0kLA0lt8gjw7tKVqJkFfVE1V/5U5aISgLkBZTbdl4GLS1dCqtC7gLtKV6KG5gSU6WqAqtwEYi6shwPKbLqVwOswOVI7fAc4s3QlampRQJkRP9TUcVE9ABE3QBvcBxxJWsJXaqobgLeWrkSNRfwA8hOAKjeBmPmliwPKbItrgaNwgSA1052ktekfKV2RGos4N+sElKmOmwD0lK5EB10AHIvrA6hZ5gIvAP5WuiI155RINULX1+ov6evAK0mbiEh1dwdp07Au7/gntYoJQFnnAy8mZv1wqSrXkLYU9uUvtYgJQHmXAU8njQ2Q6qQXOA04iJi57ZIKMgGoh7uAA4H/i4MDVQ9zgZcAxwNLC9dFUgATgPpYCnwAeBrw08J1UXctJ/3q3xX4ceG6SApkAlA/t5JGWv8Tab61lMNy4FvAbqRf/Q+VrY6kaCYA9dQLnAfsRZpz/WNgWdEaqa3mA/8JPBV4PW7kJXXGpNIV0LAu7IuNgVeTEoL9gLVLVkqNNpc0+PQHpJ38TC6lDjIBaI6/k77NngZMJk3L2ou0T/jOwFak1cLWxXXDlaaWLuqL20iflm4hzTZxt05JJgANtRS4qi8kSRo1xwBIktRBJgCSJHWQCYAkSR1kAiBJUgeZAEiS1EEmAJIkdZAJgCRJHWQCIElSB5kASJLUQSYAkiR1kAmAJEkdZAIgSVIHmQBIktRBJgCSJHWQCYAkSR1kAiBJUgeZAEiS1EEmAJIkdZAJgCRJHWQCIElSB5kASJLUQSYAkiR1kAmAJEkdZAIgSVIHmQBIktRBJgCSJHWQCYAkSR1kAiBJUgeZAEiS1EEmAJIkdZAJgCRJHWQCIElSB5kASJLUQSYAkiR1kAmAJEkdZAIgSVIHmQBIktRBJgCSJHWQCYAkSR1kAiBJUgeZAEiS1EGTSlegATYGtgM2ASYXrovUNouAu4E7gMWF6yJ1ignA4NYBjgOOAvYEespWR2q9R4FLga8BFxSui9QJfgJ4sqOA24H/AJ6BL38ph7WAlwA/An4ObF+2OlL7mQA80anAd4BNS1dE6rD9gV8DswrXQ2o1E4DHnQB8CH/xS3XwFNKngN1LV0RqKxOA5ADSr39J9bEucB4wpXRFpDYyAUi/+D+J50Kqo+2Bd5WuhNRGvvTgIGDv0pWQNKR/BSaWroTUNiYA8LLSFZC0WpsA+5SuhNQ2JgCwX+kKSBrW/qUrILWNCQBsUboCkoY1o3QFpLYxAYCppSsgaVjTSldgFJYFlLk0oEx1nAkA3Fu6ApKGNa90BUYhoq73BJSpjjMBgL+UroCkYc0uXYFRmN2QMtVxJgBwUekKSBpWk+7THweU2aT2qyFMAOAHwIrSlZA0pF/TrJ662cB1FZbXtParIUwA0s5/Z5WuhKQhfbh0Bcagyjo3sf1qABOA5CM0a5CR1BXfBS4tXYkxuBg4p4Jymtp+NYAJQDIPeDnwaOmKSPqH64E3l67EOLwJuGEc//umt181ZwLwuF8B+wJzSldEEhcDhwCLS1dkHB4BZpG2NR6tNrRfDdAbEK/K2oJqbQqcASwn5twYhjF03AscR7s2/5lI2tHw73Sz/aqpHtJFV7UjgXMDys1pO+CVwGGkLUk3BSYXrZHUPotIvW43Az/si0VFaxRnKvDSvpgJbNn377vSftVQRBbf5B4ASZJazzEAkiR1kAmAJEkdZAIgSVIHmQBIktRBJgCSJHWQCYAkSR1kAiBJUgeZAEiS1EEmAJIkdZAJgCRJHWQCIElSB5kASJLUQSYAkiR1kAmAJEkdZAIgSVIHmQBIktRBJgCSJHWQCYAkSR1kAiBJUgeZAEiS1EEmAJIkdZAJgCRJHWQCIElSB5kASJLUQSYAkiR1kAmAJEkdZAIgSVIHmQBIktRBJgCSJHWQCYAkSR1kAiBJUgeZAEiS1EEmAJIkdZAJgCRJHWQCIElSB5kASJLUQSYAkiR1kAmAJEkdZAIgSVIHmQBIktRBJgCSJHXQpNIVaICNge2ATYDJheui9lkE3A3cASwuXBfV35rABsB6wDp9/24dHn82TQd6gKXAI33/7pG+/xtgIfAQsADozVBf1ZgJwODWAY4DjgL2JN1QUqRHgUuBrwEXFK6L8lsT2GZAbAvMADYkvfA36vvP61Z0vF5gPikR6I/7gL8CfwFm9/3zHkwUWquHmD/ukcC5AeXmcBTweWDT0hVRZ10FvJHUK6B2WR/YvS92A3Ylvew3o54/NJYAdwF3Ar8Dft8Xf+TxXgU1lAnAE50KfJB63ojqlvuBfwKuKFwPjd2GwD59sQfphb9l0RpVZxlwKykpuAG4Frgek4JGMQF43AnAJ0pXQhpgEbAv6SGr+tuc9Pfar++fe9KtgdbLSNfqNcDVwM9InxlUUyYAyQHA5XTrZlUz3AE8DXisdEX0JOsCBwIvBg4HtihbnVr6I2lMy0+Bn2MPQe30BsSrsrZgfHqAXxBzHgyjing/qoMe4BnAiaRfuMspf200KRYC5wBvIo15UA1E/KGblAAcTPkbwzBWF38DJqJSZgInA7dR/lpoS6wgJVHHYzJQVMQft0kJwH9S/mYwjOFiP5RT/0v/Vsr/7dseA5MBZ19l5DdvH6xqhv1LV6ADNgDeA/wBuBk4CdipaI26YQJp0OTngTnAj4AjsNcrnAsBOXBHzTCjdAVabC/gbcD/B6xduC5dN4n08j8CmAd8E/gqaR0CVcweAJhaugLSCEwrXYGWmQ68j9TFfx0pAfDlXy+bAR8A/gxcBLwE31mV8mTCvaUrII3AvNIVaIltgE+Slrn9FHbxN8EE4DDgh6SBmMdjslYJE4D0IJDqbnbpCjTcnqTu5D+TflVOL1sdjdH2pLECs0mJ3OZFa9NwJgCpa0mqO6/TsTkIuJK0XO3rcNxTW2xESuRuB76EY7nGxAQAfkCahiLV1a+xp2q09iGtPncZ8LzCdVGctYB3kFbMPB3XFBgVE4CUQZ5VuhLSany4dAUaZHfSanPXkhb5UjdMJg3kvB34ArBJ2eo0R8TCDk1aCAhS1ti/77Vh1Cm+g0ZiJ+B8YCXl/2ZG+XiItI6DgwWHEXHym5YAADwHWEz5C9cw+uM6fIANZzppMNhjlP97GfWLu4HX4xbvg/ITwON+RVqNak7pikjAxcAhpKRUTzaB9GC/hTQYbM2y1VFNzQC+QXq+P7dwXWrHBOCJbgSeDXwNBwaqjL8D7wReBDxQuC51NYs0qv8b+K1XI/Ms4CrgTNxv4Akiul2a+AlgVdsB/wZcDvwVWEL57iyjffEwac/0c4DXkvaY1+Cmk0Z6+53fGE8sJA0Y7PxngR7SCanakcC5AeVK6qZXknbu7Mqvt0dJUz9nA3cB8/tiwSrRCywClvX97xb2/XMNHk8m1yZ9IlmTtOFRf2xImk+/MbA1sC2py7wrm/BcDhxLmjnQSS6KIanONict9PKy0hUJchfwe+B3ff/sf+n/bZzlLuPxZGDh6v6Lq1gD2Iq0ZPIOwB6kqZW7AeuNs051cxDpvJ8MfBZYXrQ2hUR0sbThE4Ckso4hjYMo3WVcVcwlfeo5HjgAWL+yM5XHtqQNeT4O/IzU81D6nFYV1wO7VneqmsMEQFKdrE96UZZ+KYw3bgG+TNpmeJsqT1BNTCINrns38H3gfsqf8/HEYuA4OjY2wARAUl0cSJqKW/plMNYXyKWkaYm7VH1iGmAisBep/VeTZlKV/puMJS6mQ0sKmwBIKm0yaUGfpr00FpCmDR8KTKn8rDTbJsBbgEtIYxJK/61GE38DXlj9KakfEwBJJW1F2vCo9EN/pLGQtH/IC0mD5jS8jUgj7i8nDbYr/TccSawEPk3LB8ubAEgq5RDgPso/7IeLFaRfsq/CVQfHazPgBODPlP+7jiR+Rpoq2UomAJJy6yGNhq971/A80qeJ7WNOQ+ftRVrcqe77sNxN2mK6dUwAJOU0lTRqvPRDfXVxLfBPtLz7t0Y2BD5ESrhK/+2HisdInzFaxQRAUi7bkZY+Lv0wHyxWAD/ATWNKWhN4E3Az5a+HoeIMWjT2wwRAUg57kzY7Kv0AXzWWkObr281fHz3A4aQNfEpfH4PFJcC0sNZnZAIgKdrLgUco/+AeGEuBb+KLv+72A66k/PWyatxM2kOh0UwAJEU6nnrN719BWmlwx8hGq3KHANdR/voZGPeQBjI2lgmApAgTSV3rpR/SA+MiOrrme0v0AEeTNlEqfS31x8PAiyIbHckEQFLVJgLfoPzDuT9uw+dSm6xFWnL4IcpfW72kxY1eH9riICYAkqo0mTSavvRDuZe0at8HcPGetppBGsexkvLX2nLgzbHNrZ4JgKSqrE3aTKX0w7gXuID0glD77Q/8ifLX3ErS7oiNYQIgqQrrApdR/iF8D2kRH3XLFOBk0rTO0tfgSbFNrY4JgKTxWg/4JWUfuitJgw7XC26r6m1P4HpMAkbEBEDSeKwN/JyyD9s5wEHRDVVjTCL1BpTea+L9we0cNxMASWM1GfgJZR+yPwA2iG6oGunZlN11cCXwjvBWjoMJgKSxmEhaUKfUw/UR0iJD0upMJe04WDIJeEt4K8fIBEDSaE0EvkO5h+pvgR3CW6k2eS2wiDLX63LglfFNHD0TAEmjVXKFv2+Rxh1Io7Ub5T4JLAEOjm/i6JgASBqN91HmAbqMtKiPNB7rAedR5hp+ENg9vokjZwIgaaT+iTIb+8wjLfYiVWEC8FHKrCA4G9g0vIUjZAIgaSSeRZktfVux7apq6RXAYvJf09eTFs4qzgRA0nC2Bf5G/gflT4HpGdqn7noOcC/5r+2fkAbTFmUCIGl1pgJ/JP8D8uvAGhnaJ+0A3Er+a/xTORq3OiYAkobSA3yf/A/Gk3I0ThpgA+Ba8l7nKyn8vjQBkDSUE8j/QHxvlpZJT7YOcAl5r/mHgZk5GjcYEwBJgzmYtIBJzpf/O7O0TBramsD55E0CbgOm5WjcqkwAJK1qK+Dv5HsALgeOydEwaQTWIP8y1z8kfXLLygRA0kCTgV+T78G3jJouk6pOmwicTd4k4N+ytGwAEwBJA32SfA+8lcCb8zRLGrWJwPfImww/J0vL+pgASOq3P/m++68E/jlPs6Qxmwz8mHxJwO2kqbdZmABIgrTgzl/J96B7f55mSeO2FvAz8t0bX83TLBMASUnOQU8n52mSVJmpwHXku0dekaNRJgCSjiHfg+3MPE2SKrcZaTOfHPfJfGBGdINMAKRu2wxYSJ6H2hWkedZSU+1KvvvlJ9GNMQGQui3X3uh/ANbP1CYp0ixgCXnum6OiGtHTd4CqHQmcG1BuCRsD2wGbkEaDqv6Wknb3upO0mI2G9kry3Kt/A/YmDTKU2uCNpA2rot1L6nW4P6JwewCebB3SggzXk6Yq5cjyjOpjJWnQzvv7/qZ6omnA3cT/HZYCz8vUJimn08jzLAtLNCIq2+QE4ChgHuVfXka1cQ/Nvi4j/Dd5zv27cjVIymwN4Ery3EfPj2hAREWb+qA9FX/xtzlWAh9HkL5h5rjWz87UHqmUzUg/MKLvpduBKVVXPqKiTUwAcm97apSLri9AMxG4ifjzfBOwdqY2SSXtQ55BgR+quuIRlWxaAnAAsILyLyYjTywnLXnbVccSf44fBnbM1SCpBv6VPPfV5lVWOqKSTUoAeoBfUP6lZOSNX1Ng680amE6ebX7flKtBUk30ABcSf2+dVWWlIyrYpATgYMq/jIwycSDd81niz+t52Voj1cvmwH3E3l8rgWdXUdkJVRTScC8rXQEV89LSFchsB+AdwceYC7w1+BhSXd1D/PXfA3yBCnowTQBgv9IVUDFdm5v+KWKX4e0F3gAsCDyGVHf/j/jd/PYmLbg3bhFdFE36BBDdXWPUN+6lO/YiftrfV7K1Rqq3qcBdxN5vtwKTxlNJewDSH0rdNK10BTI6ldhBj/OADwaWLzXJw8A/Bx9jJ+A14ynABKBbvwL1RPNKVyCTfYFDg4/xDuCB4GNITXIh8L3gY3yMcexRYwIAfyldARXTlb999OqH55C+e0p6oneSPjNH2QZ4/Vj/xyYAcFHpCqiYC0tXIIODiJ3u+ABwfGD5UpPNBz4QfIyPMI7BvRGDE5o0CHAH0spwpQekGXljGWmb57aL3qjkvfmaIjXSBOBXxN6Hx461chGVaVICAPA1yr+QjLzxX7TfM4k9h39mHN8fpQ7Zm9hZOLcxxh79iMo0LQHItZuTUY+YC2xC+32P2PN4eL6mSI13NrH345gWtYuoSNMSAIDnAIsp/3IyYmMx8CzabxvSZ46o83hptpZI7TADWETcPXnVWCoVUZEmJgAAexK/eINRLuZS0RraDfB54s7jcmBmvqZIrXEysc+4vUdboYhKNDUBANgUOAMHqwYZRgAAGrVJREFUBrYplgGn041uf4D1SQuRRJ3Pb+ZritQq6xK7G+e5o61QRCWanAD02w74N+By4K/AEsq/yIyRxZK+v9nlfX/DLoz2H+h9xJ3bZaSZM5LG5gTi7s/lpM9/IxZRiTYkAFIT9ZDWCI96wJyRrynqsO1J3eU/I/1ifhS4H7gR+CJwQLGajd86wN+Iu0dHtfCXCYDUHgcS92BZAmybrynqoE2AbzGyKXPXkQZvN9F7ibtP72EUmwSZAEjt8W3iHixfztgOdc8+pK2kR3NNLiN+pb0Ia5H2Iom6V48YaUVMAKR22IDUVRpxT6/Ab/+KM4vxDVz9cPYaj9+JxCUAPxppJUwApHZ4D3EPlO9nbIe6ZTfSnhLjvUZfkbvi4xQ5W2c5sOVIKmECILXDH4hLAJ6bsR3qjs1JM3aquEbvAablrf64nUbcPTuiXhETAKn59iTuQXJNxnaoO6aSRvVXea02bWfKbYhbsfNPwx3c7YCldohMuj8bWLa6aQ3SZ6WnV1zuGyouL9ps4Pygsp9K+ryyWvYASM33Z2Lu5Xmkh7VUpa8Q12O1fsZ2VOEg4s7FsGsCmABIzRa57e//ydgOdcNHibtee2neeJUe0na+Eefi9tUd2E8AUvMdFVRuL3BmUNnqpqNJK/xFWi+4/Kr1Al8PKnt70vigQZkASM3WA7wyqOxLgTuCylb3zCIllD3Bx3ksuPwIZ5IGA0Y4cnX/Tz8BSM31DOK6UqMSC3XPTGAhsV3//bF1pjZV7TxizsctQx3QHgCp2Q4PKvcBRrGamLQamwMXAtMzHOse0roCTfSNoHJ3Jn0KeBITAKnZXhhU7vnA0qCy1R1TgZ8AW2U63jmZjhPhf4EHg8o+dKj/h58ApGZan7hFRA7L2A610xrAxeTp9u8lLX+7XZaWxfkGMefmgqEOaAIgNdNRxNy/9wOTM7ZD7RQ513+wODVPs0IdTsy5WQRMGeyAJgBSM51FzP371YxtUDtFz/VfNX5FOxasWgOYT8w5ev5gBzQBkJqnhzTgKeL+HfJ7oTQCRwMryffynwNskaVleXydmPP0mcEOZgIgNc/OxNy7i4A1M7ZD7TKLNA8/18v/QUaw3n3DvIqYc3XdYAczAZCa503E3LtO/dNY5Zzr30uapXJwlpblNY3UtqrP13LSrIx/cBqg1Ez7BpV7UVC5arecc/0hvdDeDFyW6Xg5PUga01C1icBzBv4LEwCpmaISgIuDylV75Z7rD3Ai8K2Mx8stKhF/0nPDTwBSs2xIzCCrP+VshFphDdICNrm6/XuBM7K0rKw9iTl3l6x6IBMAqVmOIOa+/VLORqgVcs/1vxCYlKVlZfUAC6j+/D1E+hQA+AlAaqJ9gsq9JqhctdNJwD9nPN4NpJ3tlmc8Zim9xNyPU4Gn9f8fJgBS8zw9qNyrg8pV+xxNSgByuRt4KWmaaldcG1TuHv3/wQRAap7dA8qcC9wVUK7aZxZp//qeTMd7iLRE7t2ZjlcXUQn5P9ZNMAGQmuUpwIyAcv31r5GYSdopMtdiUcuAVwC/z3S8OvkNaVGlqv3jB4QJgNQsUaue/SKoXLWHc/3zWgLcGFCuCYDUUHsM/18ZkxuCylU7ONe/jIj7clNgYzABkJomogegl252sWpk1gDOJW7w6WC+Bnwi4/HqKuq+3A1MAKSm2SWgzDnAAwHlqh1OI+8OkRcBb894vDr7XVC5u4IJgNQ02wWUeVNAmWoH5/qXdTOph65q24AJgNQkU0jf76oW9StDzeZc//IeBv4SUO62YAIgNcnWxMy9/mNAmWq2WTjXvy5uDihzGzABkJpk26By7wgqV83kXP96iegB2A5MAKQm2Sao3NlB5ap5nOtfPxEJwDRgugmA1BzbBJT5KPD3gHLVPM71r6eIBABgGxMAqTm2CCjzL8SMMlazONe/vqISgC1NAKTm2DCgzKiHi5rFuf71NTuo3A1NAKTm2CCgzDkBZapZnOtfbw8DCwPK3WBSQKGSYmwUUOZ9AWWW0EMa2bw56Vv2fcCdwIKSlWqAN5B3rv9fgRfjXP/Rmg+sX3GZG5oASM0R0QPQ9Bfk9sC/Akfw5DESK4HrgG8DXyUNeNTjDgbOIN9c/4Wkuf7zMh2vTeYDO1Zc5gaQBgBVHa+quKJS161JzL362pyNqNBk4PPAUkbWzjmkVeaU7Eba/yHimhosHiMtLqSxuYDq/ybnOwZAaoaIAYDQzB6ADUnzxo8njV4fiS1Ii9t8JKpSDTKDNN1vWqbj9QJvAq7IdLw2mh9Q5gYmAFIzrBdUbtMSgDWA7wP7jeF/2wOcAnyOfN3edTMV+DGwZcZjnkj6DKOxi7hPpzsGQGqGqGVZm7YN8GeAA8ZZxrv7/vmecZbTNP3JU865/qfjXP8qRNyna9oDIDVDVAKwJKjcCDtS3dzxd9O9noDTgBdkPN5FwDszHq/NIu7TyfYASM0wOajcJiUA7weqfGZ1qSfgo+Sd6389zvWv0tKAMu0BkBoiKgGIeLBEmECa6le1LvQEHA2cnPF4dwMvw7n+VbIHQOqwqE8ATUkAdgI2DSq7zT0BBwPfIO9c/0NJSYCqE5EA2AMgNUTXewAiNkIaqI09ATNJg/5GOlVyvJaR1oD5Y6bjdUnEfWoPgNQQE4PKXRFUbtXWzXCMNvUEzCANwpue6Xi9wDGk9RlUvYixFJPsAZCaYVlQubl+HY5Xrj0L2tAT4Fz/9onoAVxqAiA1Q1RXfdSnhardSfqVmcO7gc9mOlbVSsz1/yrO9Y8WMQZoiQmA1AxR0/WakgDMA36X8XhN7QkoMdf/uIzH6yp7AKQOi+oBiJpdEOG7mY/XtJ4A5/q3lz0AUod1/RMAwBeBezMfsyk9Ac71b7eIBMAeAKkhoj4BrB1UboRFpBdyrrEA/ereE+Bc//abElCmPQBSQzwWVO5TgsqN8l3g/xY4bn9PQN3sBvyAfLM5lgCvwLn+uW0QUOZjJgBSM0Rt27thULmRPgh8ucBx6/Y5YHPSdL9pmY7XC7wVuCLT8fS4iPt0gQmA1AwLiVm0J+KXRbRe0i5zpZKAz1I+CZgK/ATYKuMxTwS+lfF4elxEAjDfBEBqhpWkJKBqTewBgHokAaWsAZxL3rn+X8O5/iVFJOomAFKDRHwGaGIPQL/SSUCpMQGnkQbh5XIR8PaMx9OThXwCgHQTVR2vCqis1HVXU/29elbOBgTpAb5EzLNsuMidBJxUYd1HEteTZx8GDa0HWEz1f9t3EVCoCYAU4/9R/b16Rc4GBOpCEnA06VNQrnbNIX4XRg1vU2L+vkcTVLAJgFS9M6j+Xv1r1hbEanMSMIs0FTRXex4kTTFUefsQ8zd+PkEFmwBI1fsI1d+ry2nOjoAj0cYkYCZpAGiudiwlLS6kengNMX/nHQkq2ARAqt7riLlft8vZiAzalARsTuqlyVX/laTrTPVxItX/nVfQt7ywCYDUDPsRc7+28ddeG5KAqcCNmev+wYrqrupEfPqb01+4CYDUDDOIuV9z7iCXU5OTgDWA/81c5zPGWWfFuILq/9ZX9RduAiA1wwRiBoKVmEefS1OTgK9kruuFwKRx1Fdx5lP93/ub/YWbAEjNcRvV369X0W5NSwJOylxH5/rX15bE/M0/1n+AiHmlJgBSjIuo/n59gPJr20drShLgXH8N9EJi/u7H9B/gkYDC31D1WZAEpK1wIx4I22RsQyl1TwJm4Vx/PdEJxPztn9F/gHsDCj+u8tMgCeKmAr4kZyMKqmsS4Fx/DeZsqv/bLwfW6j/AnwMOcELlp0ESwB7EvBA+nrMRhdUtCXCuv4YS8X7+48ADRMwz/c9qz4GkPpOBJVR/z16esxE1UJckwLn+GsomxPz9vzvwIFcFHODSSk+DpIF+T/X37CLatSTwSJROApzrr9V5BTHXwIkDD3JuwAHuqvQ0SBrof4h5MDwzZyNqogc4nTJJwC2Zj/cTnOvfJJ8h5jo4ov8AE4BbAyq+BbBxQLmS4IagcvcNKrfOekkrIZZYDGnnjMe6ATiKNABMzfDcoHJvHPh/RI0qPjKo8lLXRW0Pem7ORtRMD/BFyvQERIdz/ZtnbWLG+jxp++9nBxykl7SUpaTqTQYWU/09ez/d7iJuYxLgXP9mehEx18PZqx5oWtCB/kr6xCCpej8n5r6N6nZsijYlAc71b66oa/Dtgx0sag7qQVWcCUlP8gli7tkurQcwlDYkAc71b7bbibkudh/sYN8MOtiZVZwJSU/yYmLu2etyNqLGmp4EONe/uXYk5pp4EJg42AGPCTrgImDDcZ8OSavagJhNY1aSFiBRc5MA5/o3278Qc11cNNQBtwo6YC/wf8Z5MiQN7gZi7tk352xEzTUtCbiQbg/kbINLibk23re6g0asOdxL2mp02jhOhqTB/Tsx9+zFORvRAE1JAq4H1g06B8pjI2AZMdfHzNUd+MtBB+0FPjv28yFpCPsTc78uw4W8VlX3JMC5/u3wDuKuj9WKepj0P1CePrbzIWkIE4EFxNyzx2ZsR1PUNQlwrn97XEnMNXL6cAfuIW7qQS9wLX6bkqoWsZdHL3BZzkY0SN2SAOf6t8dmpKWaI66Tl4+kAicHHbw/HBAoVeuNxNyry0kPJD1ZXZIA5/q3y/HEJYnrjaQC2xIztag/VgCHjvasSBrSZqT7KuJ+PSFjO5qmDkmAc/3b5SZirpNR9eZdHlSJ/ljAMKMRJY1K1LLAd+By3qtTMglwrn+7RO3J00va7XLEXhBYkf64G9h6NJWSNKTjiLtXXc579UokAc71b58ziLlWljOGGT2/CqrMwLiFtACRpPHZhLjBQ9/J2I6mypkEONe/fdYFHiLmerlkLBV6aVBlVo17GGJzAkmjEvXp7jFcznskciQBzvVvp7cQd828ZSwV6iFuQMKqsQAHBkrjdSxx9+iJGdvRZJFJgHP92+tGYq6ZpaQ9Q8bk8KBKDRYrgFPxu5Y0VpFLiM4D1szXlEaLSAKc699ekWPuLhxv5c4LrNxg8QtcMVAaqx8Rd2++KWM7mq7KJMC5/u0WtfFPL/Dq8VZuK9KWvjmTgGXAF4D1x1t5qWOOIO6+/BNOCRyNqpIA5/q31+7ErbszH5hSRSU/EFTB4eJhUiLgamTSyEwE7iLunjw8X1NaoQc4jbGf75Oz11g5nU3cvVrZBnxrAL8NrOhw8QjwDeAQ/AUiDecU4u7FqzK2o02OJc2mGM2Pn7cVqaly2Y40tiPqXt21ysruTLooSyUB/TGHtGDC0aS5z5KeaEvi1gToJQ1a0uhtA5wFLGH1P3bOwql+XXAWcffo1SOtRM8oKvxaUpdFncwlLSh0G6nrc1FfPFKyUmqte0kj4vt3zayr/yVuau11PL5sqUZvPdLfZjdSsjaJtOTyH4CLSM8vtduOwB+Jm/X2RlKCUbmo5QoNo0kxF/gy6Uauo5cQ2/4j8jVFap1vE3dvzgfWjqr4WsANgZU3jCbFUuBzwGTqpYf0CyOq3b/D8TjSWMwkbvfOXtIYoFCbkbqsSj98DaMucRX1Wy43cmXAXtI4HEmj80Pi7slHyTQ2bnvSt9DSD17DqEtcQ71Wy5sC/I249s4B1snWGqn5Dib2GXT6aCs0cYwNWQj8jPQroE4PPamULUm7el1cuiJ9lpPqMyuo/PVIn0CuDCpfapNJwPnE/ULvBV5PGgOQzSzitjE0jKbFUmAH6mMjYDFx7V0MbJ2tNVJzvYvYZ88P8zXliZ5BbFejYTQpvkS9fInY9n47X1OkRnoKadfbyPtwv2ytGcS2pLn4pR++hlE65jK69TWibUEaHBTV3pXAgdlaIzXPV4l95tTis+OmOEXQMHpJg2Tr5PPEtvc20hRhSU/0POI2/OmPvbO1ZhhTSBv4lH4AG0bJOIB62Yj4pbw/ka01UjOsSex6HL2kLcBr57XUY+8AwygRdVwp7z+IbfMyYK9srZHq71Ri77mVwJ7ZWjNKOwM3Uf5hbBi549nUzwbAg8S2+3ri1jeXmmR3Ynf76wW+P95KjnUdgJFYAPw3aWOefajfcqlShF7gRNIUuTp5lNQlOSvwGJuR2n9F4DGkuluTtLHT5oHHWA4cBdwXeIzKbA58k/K/zAwjOn5Ffa0FzCa2/Suo3xgIKafoQbe9wGnZWlOhF+JnAaPd8a/U29HEn4M7SSsFSl3zAuJH/d9P+qTXWIcAv6D8w9owqoy5BG7FWZEe4OfEn4tv5GqQVBMbAfcQf2+9M1eDor0AuJz4jMkwomMl8Aqa4VnEbknaH6/N1SCpsAnAj4m/p/5ACwfabg+cBNxO+Qe5YYwlPkaznEn8OVlMjacpSRX6KHmeM4fmalAJPcC+pPXLXVrYaEIsp/7f/QezKelbYvT5+TMwPVObpBJeSJ4etXFP+2uaLUhbHJ4F/IXyD3vDGBi/ICWsTfVm8pynC0hdpFLbbE2aihd9Dz0AzKi68nXatGQkppIWGNoJ2KXvnxv3/fvppP3P1wXWKVVBtdq9pEE+Pyft7d0/mK6peoCfAgdlONZJwCkZjiPlshZwLfD0DMd6G3BGhuNI6pBtgUXE/4JZCbwmU5ukaD3A/5CnB+0KmvdjXVJDfIA8D7JHgedmapMU6VPkuWceI/V2S1KISaR1/HM80O4DdsjTLCnE28lzr/QCH8zUJkkdtitp2l6Oh9rtpEVTpKZ5IWnnyxz3ydW0cM6/pHo6jny/bK4lDdiVmmJv8m1z/yBpfI4kZdED/Ih8ScBlpJHUUt3tTtrhNte94SqakrLbCJhHvgfdxaTtU6W62pG898Q5eZolSU92KHn35zgPv3WqnrYifgvtgXEXsH6OhknSUD5NvodeL3A2JgGql21JW1vnugeWAPtkaZkkrcZE4BLyJgE/AqbkaJw0jJ2BOeS9/t+epWWSNAIbk/8heBEODFRZM0lLfue87s/O0jJJGoXnkFYjy/kw/DmwXo7GSat4JjCfvNf7b4G1czROkkbrWPI+EHuB35C2LJZyOZx88/z7YwHO95dUc2eQPwn4C2mFQinaP5Nvhb/+WEaacSNJtbYGac5+7iTgIeCwDO1TN/UAJ5P/uu4lrbwpSY0wDfg9+R+US4Bj4punjlkLOJcyL///yNA+SarUDPLPDOiP04HJ8U1UB2wJ/Joy1/E5wIT4JkpS9Z5B/sFS/XEVsFl8E9Vih5F3Xf+B8Ssc8S+p4V4ELKXMQ3Qu8Nz4JqpleoCPACsoc93eAmwY3kpJyuAoYDllHqZLgPeSHurScDYCfkyZa7WXNKNli/BWSlJGb6DcL6pe4KekcQnSUA4h9RqVukb/RlpaWJJa5zjKPVx7gfuAl4a3Uk2zJvBJyiao9+FaFpJa7gTKJgG9wH8BU6MbqkbYHbiJstfjQmDP6IZKUh2cRPkk4C7SAEV10xTgVMoNUB348t87uK2SVCvvBFZSPhE4h7SbobpjP+CPlL/2FgDPDm6rJNXS2yn73bU/5pNWEHSmQLs9hbRIVB0Sz7n4zV9Sx72G/JurDBXXkX4dql0mAW8D/k75a6wXmA3sENlgSWqKV5Hm65d+MPeSfh1+C6cMtsXzgZspf131xy04z1+SnuBg0oCo0g/o/lhEGqy4XmSjFWYm8EPKX0cD4xpc4U+SBjWTtBJa6Qf1wFhA2gbWRKAZtiV95y+18uRQ8X3SroKSpCFsCvyG8g/sVeM+4AP4EK+rrUkv/rqMJxkYX8Bd/SRpRNahft23/TEP+BBpRLnK24M0ZqP0fP7BYhlwbFzTJamdJgKfoh5TtgaLRcBppC5n5dUDvAC4hPLXwVCxADg06gRIUhe8CniY8g/0oWI5aTGhg3AdgWhTgbdSfune4eIGTAwlqRI7A3+g/IN9uLiLtKnMVjGnobP2In3ff4jyf+Ph4mxg7ZjTIEndtB5wPuUf8COJpcB5wMtIa85r9DYHjqf+v/b7YwnwjpAzIUmiB/g36jnga6h4EPgmaeOhydWfklbZmPQSvYJ6LBE90vgLsE/1p0OStKpnArdS/sE/2rgfOJM0rmF65WelmXYE/gW4lPrN3R9J/A8wrfKzIkka0jrAGZR/AYw1lgFXkaYUPoPuDCBcm9Qb8kXgdsr/HcYaDwKvrfjcSJJG4eWk3fxKvxDGGw+RfgWfDBxCexYc2gQ4gjQ48mrgMcqf6/HGL+nYZj5dyU4lNc8M4CukF01bLAWuB35LGgj3e9KmNg+VrNQwtgR264vdgWeRuvjb4jHgFNL6FMsL1yUrEwBJdXcUadnVTUpXJEgvaSvZm4E7SYPP+mM2ab2EaJuS5rj3xzakl/zuwPoZjl/KlaQthW8rXZESTAAkNcFTgM8Ab6B7z60HSHveL1gl5pNWVFxMmq4GaedFSDMT1un7z1OBSaSpixuQdq7bANhowD/b8mlipB4gzTz5GikBkyTV3CE0e5CZUT6+D2yGJKlxJpMWk3mQ8i8TozlxC3A4kqTG24y0lGyTFpcx8sf9pC2fXbBJklpmL9Lc+9IvGqNesYyUIG6EJKm1ekizBf5E+RePUTZWkr7z74okqTMmkJbkvY3yLyIjf1xK6hGSJHXUGsDrccZAV+Jq4HlIktRnMnAszdxkyFh9rAB+BOyHJElDmEBaUvhSyr+4jPHFEtJWzH7jlySNyjNIL5BllH+ZGSOPB0hLQs948p9UkqSR2wb4OHA35V9uxtBxNXAMacthSZIqM4G0xPA5pN36Sr/wjLSnwenAHqv5u0mSVJkZwIeBP1D+Jdi1WApcCLwaWHO4P5QkSVFmAifj4kKRsYLUxX88sPGI/iqSJGW0J/AJnE5YRSwFLgPeji/9orq2r7Ykjde2wPNJ4wYOBdYrW51GuBe4BLiANBXzgbLVEZgASNJ4TAH2Bw4DDiANWptUtEb18BBwLemX/v8CN5etjgZjAiBJ1VmH9LlgX9IKdfsC6xetUR7zSN/yr+n7542kTXlUYyYAkhRnIvA0Us/AbgP+uWnJSo3DCuDPwO+Bm/r+eSMwp2SlNDYmAJKU30bA7sAuwHakRYm27fvn9GK1SnqBe4C/9MVs4A5SN/4fgMeK1UyVMgGQpHqZTkoGtgA26IuNgA37/vOGpE8N0/r++2uRxiL0/297SCPtH+n7dw8Dy/viYdIAvPuABQNiPvB34C7gr6T19tVy/z997IKIV6947gAAAABJRU5ErkJggg=="/>
                                    </defs>
                                </svg>

                                I’ll appoint my Registered Agent
                            </div>
                            <h4 class="item_price business_fee">FREE</h4>
                        </div>
                    </div>
                    <div class="service-item">
                        <h3>EIN</h3>
                        <div class="service-description">
                            <div class="item-content">
                                <svg class="service-item_icon" width="22" height="22" viewBox="0 0 22 22" fill="none"
                                     xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <rect width="22" height="22" fill="url(#pattern0_78_226)"/>
                                    <defs>
                                        <pattern id="pattern0_78_226" patternContentUnits="objectBoundingBox" width="1"
                                                 height="1">
                                            <use xlink:href="#image0_78_226" transform="scale(0.00195312)"/>
                                        </pattern>
                                        <image id="image0_78_226" width="512" height="512"
                                               xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAB1DSURBVHic7d17sO13Wd/xz0NOIBDuGItURLlKIQ25iSIgCgWqoChK0XbEaOVmFS9YQG07VoGgY8UqAopycYKjI44oqERrVWxUkhNuwUCLIAQEBQTDLSQnefrH2sEEkLPP2b+1vnvt7+s1s4bwz/N9zpmz9nrv9VuX6u4wXlXdPMm3Jjlz53b3JIeGLgUcj08k+askh5Ocn+Rl3X3N2JXg05UAGK+qHpTkl5PcfvQuwOJeneQx3f320YvAdd1g9AKzq6pnZvVbggd/OJjul+QNVfWo0YvAdXkGYKCqeniS3x69B7ARV2f1TMB5oxeBRAAMU1W3SXJJktuO3gXYGBHAvuESwDjfGw/+MJsTkry4qv796EVAAIxz9ugFgCFEAPuCSwCDVNX7knzO6D2AYVwOYCjPAAxQVbeNB3+YnWcCGEoAjHHS6AWAfUEEMIwAABhLBDCEAAAYTwSwcQIAYH8QAWyUAADYP0QAGyMAAPYXEcBGCACA/UcEsHYCAGB/EgGs1aHRC3DcLk9yh9FLwGROTfKnGzzv2giITwxkaQJge3V3f2j0EjCTqvrwgGNFAGvhEgDA/udyAIsTAADbQQSwKAEAsD1EAIsRAADbRQSwCAEAsH1EAHsmAAC2kwhgTwQAwPYSARw3AQCw3UQAx0UAAGw/EcAxEwAAB4MI4JgIAIDNek+SV61ptghg1wQAwGZdmeQREQEMJgAANqy7r4gIYDABADCACGA0AQAwiAhgpEOjF9iLqrpZkgclOXvnduckNXSp3dnqv3dgOd19RVU9IslvJXnIGo64NgLS3eetYT5bamsfiKrqwUl+MckXjN4FYC9EACNs3SWAWnleVk+ZefAHDgSXA9i0rQuAJP8pyeNGLwGwNBHAJm1VAFTVnZI8c/QeAOsiAtiUrQqAJM9IcvLoJQDWSQSwCdsWAPcdvQDAJogA1m1rAqCqbpfkdqP3ANgUEcA6bU0AJDlj9AIAmyYCWJdtCoCbjl4AYAQRwDpsUwAATOs6EXD+mo4QAZMRAABbYicCvi4igAUIAIAtIgJYigAA2DIigCUIAIAtJALYKwEAsKVEAHshAAC2mAjgeB0avcCGXZDku0YvkdUnGr5y9BLAwdDdV1TV1yV5eZIHr+GIayMg3X3eGuYzwGwB8OHuft3oJarqQ6N3AA4WEcCxcgkA4IBwOYBjIQAADhARwG4JAIADRgSwGwIA4AASARyNAAA4oEQAn40AADjARAD/HAEAcMBdJwL+YE1HiIAtJAAAJrATAV8bEcAOAQAwCRHAdQkAgImIAK4lAAAmIwJIBADAlEQAAgBgUiJgbgIAYGIiYF4CAGByImBOAgAAETAhAQBAEhEwGwEAwCeJgHkIAACuRwTMQQAA8GlEwMEnAAD4jHyL4MEmAAD4Z3X3xyMCDiQBAMBndZ0I+MM1HSECBjg0egEOtqo6Icmdk9x49C4L6SRv7+7LRy8Cm9TdH6+qr03y20ketIYjro2AdPd5a5jPpxAALK6qTknytCT3TnKvJDcZu9HiuqremuRwkhd29/mjF4JNEAEHi0sALKqqviHJm5J8X5L75OA9+CdJJblLkkcneVVVPb+qbjp4J9iIncsBXxuXA7aeAGAxVfWMJC9LcsroXTbssUleV1W3Gr0IbIIIOBgEAIuoqvsneeroPQa6U5KfG70EbIoI2H4CgD2rqpOTvDCrp8Zn9i1V9fWjl4BNEQHbTQCwhK9LcsfRS+wT3zd6AdgkEbC9BABLOGv0AvvIGVXlfsVURMB28oOKJZw9eoF95OQkdx+9BGyaCNg+AoAleMC7Pn8fTEkEbBcBwBJ8oNT1+ftgWiJgewgAABYlAraDAABgcSJg/xMAAKyFCNjfBAAAa3OdCPhfazpCBBwnAQDAWu1EwMMjAvYVAQDA2omA/cfbldgv3p3kyOglkvyLJCeNXgIOou7+eFU9PMnvJHngGo64NgLS3eetYf6BIgDYL+7b3X8zeomq+v0kDxm9BxxUImD/cAkAgI1yOWB/EAAAbJwIGE8AADCECBhLAAAwjAgYRwAAMJQIGEMAADCcCNg8AQDAviACNksAALBviIDNEQAA7CsiYDMEAAD7jghYPwEAwL4kAtZLAACwb10nAv5oTUdMGwECAIB9bScCHhYRsCgBAMC+JwKWJwAA2AoiYFkCAICtIQKWIwAA2CoiYBkCAICtIwL2TgAAsJVEwN4IAAC2lgg4fgIAgK3mw4KOjwAAYOt198ciAo6JAADgQBABx0YAAHBgiIDdOzR6AYDJ3Kqqzh29xATelOT+Wc/j3LURkO4+bw3zN0IAAGzWzZM8ZfQS7NnWR4BLAABwfLb6coAAAIDjd0KSF1bV6aMXOVYCAAD25sSsngm44ehFjoUAAIC9OzXJD4xe4lgIAABYxqNHL3AsBAAALOMeVXXj0UvslgAAgGWckGRrXgzocwDYL95eVaN3gKP529ELsO99QZILRi+xG54BANil7v77JO8avQcsQQAAHJuLRy8ASxAAAMfmt0YvAEsQAADHoLtfmOT80XvAXgkAgGP3HUk+NHoJ2AsBAHCMuvtdSR6Q5A2DV4HjJgAAjkN3vz7J2UmeleRjg9eBY+ZzAFjClaMX2Gf8fUyiu69M8tSq+uEkX5zkjJ3/PWHoYhyvRyX5otFLbIoAYAlvSPLA0UvsI54Wnkx3X53kTTs3tlRV3SsTBYBLACzhwtEL7CMf7O63jl4C4GgEAEv4y9EL7COvGb0AwG4IAJbwiiQXjV5iH7gmyX8fvQTAbggA9qy7jyQ5J1789uzu3oovAQEQACyiuy9J8n1Jrh69yyAXJPmR0UsA7JYAYDHd/fNJ7pPkzaN32aArk/xQkvt398dHLwOwW94GyKK6+zVVdXqSxya5d5Izk9w1SQ1dbFkfyOob4Q4nOW/n2Q+ArSIAWFx3X5Hkf177/6vqxkluNG6jRXV3/+PoJQD2SgCwdjtPjXt6HGAf8RoAAJiQAACACQkAAJiQAACACQkAAJiQAACACQkAAJiQAACACQkAAJiQAACACQkAAJiQAACACQkAAJiQAACACQkAAJjQodELcDBV1ZckuU+Ss5OcnuQmexx5JMmlSS5MclGSP+zuK/c4c1eq6m5JviLJWTu3W2/iXDggrkpySVb33QuT/FF3Xz12JRIBwMKq6pQkz0nyTWsYf6ckD9v570uq6lu7+7VrOCdJUlU3SvKjSZ6c5IR1nQMTuHOSR+z8919U1Tnd/eaRC+ESAAuqqgcneVPW8+D/qe6Z5DVV9ZR1DK+quyQ5nOQp8eAPS/rSJK+tqieMXmR2AoBFVNVtk/xqklM2eOyhJOdW1UOXHFpVh5K8NMk9lpwLfNJJSX6uqu4zepGZCQCW8tyMuzb+gqq65YLznpbVtX5gfW6Q5MVVtdfXB3GcBAB7VlVfmX+6vjfCv0zy1CUGVdXnJvkvS8wCjurOSb5n9BKzEgAs4b6jF8jqHQdLOCvJiQvNAo7OZYBBBABLOHv0AklOr6ol/j2fucAMYPfc5wYRACzhtNELJLlpki9cYM6pC8wAdu92VeWzNQYQACzhnaMXSHJ1kvcsMOeyBWYAu/eRJB8avcSMBABLuHD0Akku7e6PLzDn4gVmALv3uu6+ZvQSMxIALOGi0QtkuQduAQCb5T43iABgCS9P8raB5x9J8rNLDOruS5P8/hKzgKO6IqvPEGEAAcCedfdHk5yTpAet8PTuXvJZiO9I8sEF5wGf2dN8J8A4AoBFdPefJjl3wNGvTvLjSw7s7r9N8tisnlkA1uN3k/zM6CVmJgBYTHf/UJJHJnnfBo47ktU39X1Vdy/+QN3dv5HVl5b81dKzYXJXZPUNmw/v7lHPGhJfB8zCuvs3q+rVWX2e/r2T3CvJUp/1fXWSS7N60dDPLvy0/6fp7sNVdWaSH0jygCRnZNz3HcA2uyqrbwo9nOSndl5rw2ACgMV19/uSfH+SVNUJWX3e9433OPbqJG9d6K1+u9bdVyR5+s4tVXWHJLfa5A6w5a7K6r77idGLcH0CgLXq7quTvGX0Hkvp7nckecfoPQD2ymsAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJiQAAGBCAgAAJnRo9AIcTFV1syT3SnJmktOS3HiPI69O8uYkFye5uLvfs8d5u1ZVN0pyz6z+LKcnudWmzoYD4KoklyY5nORwd79/8D7sEAAsqqpOSPKDSX40yQ3XeM6vJXlid//Dus7YOeebkjw3yW3WeQ7Moqqen+TJ3f2R0bvMziUAFlNVd07yZ0memTU++O/4d0kuqaqHrGN4Vd2iql6a5NfjwR+W9Lgkb6iq+41eZHYCgEVU1UlJXpHkSzd47OcleXlV3WMNs1+Q5JvXMBdIvijJK6vqCwfvMTUBwFKenuRuA869UZKXVNWJSw2sqm9J8o1LzQM+o5sleVFVeRwaxF88e1ZVpyX53oErnJHkSUsM2nnx4s8tMQs4qq9I8u2jl5iVAGAJD8z4f0sPWmjOmfEqf9ikpe67HKPRP7Q5GM4evUBWzwLspznA7rjPDSIAWMJZoxdIckpVff4Cc/wwgs26886lNzZMALCED49eYMdHF5jhvcmwWVcl+cToJWYkAFjChaMXSPK27v7gAnMOLzAD2L1LuvvK0UvMSACwhP0QAEs9cAsA2Cz3uUEEAEt4RZIPDd7hvIXmvCHJGxeaBXx2neSlo5eYlQBgz7r7vRn7OQDndffLlxjU3UeSPCar65LAev18d//x6CVmJQBYRHe/OMkrBxz97iTfveTA7n5tkh9bcibwaf5fkv88eomZCQCW9Mgkz8rqq3s34ZVJzl7oxX/X090/luQ7k1y+9Gwgv5bkPt39sdGLzEwAsJju/kR3PzXJfZL87yTruHNfndU1+m/v7od193vWcEaSpLtfkOTUJC9LstavHYYJXJXk4iSP7O5Hd/f7Ry80u0OjF+Dg6e7XJPmqqjohyb9KcnqSm+xx7JEklyZ57SZ/a+jud2bni4Gq6o5ZfejRrTd1PhwAVyW5JMnru/uK0cvwTwQAa9Pd1/62fiBeVd/db0vyttF7ACzBJQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJCQAAmJAAAIAJHRq9AAdXVZ2c5Iwkpye5yR7HHUlyaZKLuvvv9rrbsaqqE5OcmuSsJLfe9Pmwxa5KcklW990PjF6GfyIAWFxVPTDJTyY5LWt4lqmqLkvy00l+pruvWXr+p5x19yQ/m+S+SW60zrPgoKuqtyV5enf/8uhdcAmABVXVzarqeUn+IKvf+tf17+v2Sf5Hkj+uqjut44CqukFVPTnJxUkeGA/+sIQ7Jvmlqvq9qvr80cvMTgCwiKqqJC9P8rgktaFj75fkz6vqc9cw+5lZPYtx0hpmw+wemuSCqrrF6EVmJgBYyhOSfOWAc09J8rwlB1bVlyV58pIzgU9z+6wu5TGIAGDPqur2SX5i4ApfX1WPXmJQVd0wyYvjvgGbcE5V/dvRS8zKDzmW8NVJTh68w6MWmnOvJHdZaBZwdN80eoFZCQCWcPboBbJ6u+F+mgPsjvvcIAKAJXzJ6AWS3KGqbrPAnDMXmAHs3j2qyottBxAALOGGoxfYscQe++XPArO4QZITRi8xIwHAEi4cvUCS93b3exaYc/ECM4Dd+7/d/dHRS8xIALCE/RAAh/fZHGB33OcGEQAs4VVZfd73SK9caM7FSd670Czg6Ja673KMBAB71t1vSfL0gSu8OsnzlxjU3R9L8p1LzAKO6pXd/aujl5iVAGApz0jy+gHnfjTJty35pUDd/YokL1pqHvAZ/UPE9lACgEV091VJvibJ+Rs89q+TPLi737aG2d+V5LlrmAskb0ryoIVeuMtxEgAsprvf3d0Pyep7AT68xqOuyeop/9O6+4J1HNDdH+vuJyZ5SJLL1nEGTOhIkmclObO7Xzt6mdkdGr0AB093P6+qXpDk7ll9sM5pSW68x7FXJ3lzVi/Se92m3jbU3edX1R2y+hrTM7P6muNbbeJsOCCuSnJpVq/2f313XzF4H3YIANaiu48keePObat1d2d1ueGvk/z64HUAFuESAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQOjV6Ag62qbpHktCQ32eOoI0ku7e53732r41NVJyX510luPWoH2EJXJbmku/9u9CJcnwBgcVV1hyT/Lcl9ktw1SS04+z1JLkry7O7+o6Xmfpbzbp7kvyb5qiT3THLius+Eg6iqLktyYZJndfdrRu+DSwAsqFYen+SNSc5Jcrcs+OC/4/OSPDzJH1bVc6rq5IXnf1JV/ZsklyT5gSSnx4M/7MXtk3xDkguq6tyqutHohWYnAFjS85M8N8nNNnBWJXlikj/feWp+2eFV/zHJ+Vn90AKWc0KSpyT546ryLPRAAoBFVNXXJPnOAUefmuQZSw6sqjsmefaSM4FP86VJfmj0EjMTAOxZVd0yyS8MXOFJVXW/JQZVVSV5YZK1XVoAPulHqur00UvMSgCwhIcnud3A82+Q5HELzbpHkvsvNAv47E5M8h2jl5iVAGAJZ49eIMkZ+2wOsDvuc4MIAJZw1ugFktxtoXcE+GEEm3VaVZ0weokZCQCWMPLp/2vdIMkpC8y57QIzgN27SZKbj15iRgKAJbx29AJJ/jHJOxaY84YFZgC7d1l3f3D0EjMSACzhwtELJHltd/cCcw4vMAPYPfe5QQQAS/iT0QskefVCcy5KcsVCs4CjW+q+yzESAOxZd/+fJC8duMLbk/zEEoO6+wNJfniJWcBRXZLkOaOXmJUAYCnfneS9A87tJN/W3R9ZcOaz47cSWLerkjymuz8xepFZCQAW0d3/kOQbk7xzg8d+PMkTu/tPlxza3dck+Q9J/nLJucAnXZ7knO6+ePQiMxMALGbnUsCpSX5xA8f9eZJ7dffz1jG8u9+Z5MuTPC3Jles4AyZ1fpJTu/u80YvMzjcxsajuvjzJY6vqp5J8WVafEnh6Vu/13YsjSS7N6h0HFyX5i53f1Nemu69Ocm5V/UpWMXDWzu3W6zwXDpirsrrWf2GSC7t7P7xriAgA1qS735LkLUleNHiVPevudyf59Z0bwIHgEgAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMCEDo1egIOvqm6c5EZ7HHN1d394iX32oqpOTHLy6D1gixzp7o+MXoJPJwBYXFWdlOSxSe6d5Mwkd01SC8z92yQX79x+qbvfudeZuzizknxLkgdk9We5R5IbrvtcOEiq6rIkh3duv9Ddfz94JSIAWFhVfUmSFyf54jWMv93O7WFJvreqntTdL1rDOUmSqrp9khcmeeC6zoBJ3H7n9ogk31NVT+julw3eaXpeA8BiquqJSS7Ieh78P9XNk7ywql66juFV9RVJ3hgP/rC0U5L8RlU9d/QisxMALKKq7pnkp5OcsOGjv7mqHr/kwKq6eZKXJLnFknOB63l8VT169BIzEwDsWVUdyuqp8lHXxn+yqu644LxnJ/mCBecBn9lzquq2o5eYlQBgCQ9LctbA82+a5AeXGFRVX5jknCVmAUd16yRPGr3ErAQAS7j36AWSnL3QnJEhAzNa6r7LMRIALGE/3IFP3XmP/l6dscAMYPfc5wYRACzhrqMXyOr1B0tct7/LAjOA3btVVd1m9BIzEgAs4dLRCyS5Isk7Fpjz5gVmALv3/u7+wOglZiQAWMKFoxdI8vruPrLAnMMLzAB2z31uEAHAEv5i9AJZLkIuStILzQKObj/8AjElAcASfjfJnw08/0NJzl1iUHe/K8lzlpgFHNV7s/rcDQYQAOxZd1+T1XvnPzZohe/p7ncvOO8pSd664DzgM3us6//jCAAW0d1vTfL4JJ/Y8NHP6+5fWXJgd38sq28A9I1lsB6d5Nzu/p3Ri8xMALCYnQfiM7K6jr5u70vy9d39hHUM7+4Lk9wzyW+uYz5M7LIkD+7up41eZHa+DphFdfdfVdWXZfUb9L2TnJnktCQn7XH0NVm9Re/indt56/5O8e5+X5JHVtXXJHlAVn+W05Pccp3nwgFzJKu3Ch/eub2kuy8fuxKJAGANdt6O95Kd29br7lcmeeXoPQCW5BIAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhAQAAExIAADAhA6NXoDjdqiqHjp6CYAD5HNGL7BJAmB7nZzk90YvAcB2cgkAACYkAABgQgIAACYkAABgQgIAACYkAABgQgIAACYkAMb48OgFAFiLy0cvsFsCYIDu/kCSy0bvAcDiDo9eYLcEwDhb848EgF25rLv/bvQSuyUAxnn16AUAWNSfjF7gWAiAcZ6T5JLRSwCwiH9M8rTRSxwLATBId38iyWOSXDV6FwD27Pu7+12jlzgWAmCg7r44yTnZoleNAnA91yR5Vnf/8uhFjpUAGKy7z0tyapLzR+8CwDF5c5Iv7+6njl7keBwavQBJd78zyUOq6uwk197umeTEoYsBHN2p2fsvk5cmuXKBXdatk7w1yYU7twt2LuduJQGwj3T3tf+oALZCVX0oyS32OOaru/tvFliHY+ASAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQEAABMSAAAwIQOjV5gww5V1S1HLwFwgNToBTg+swXAA5N8cPQSADCaSwAAMCEBAAATEgAAMCEBAAATEgAAMCEBAAATEgAAMKFtCoArRi8AwFr4+T7ANgXA60cvAMDi3t/d7x29xIy2JgC6++1J3j96DwAWdXj0ArPamgDY8ZejFwBgUReOXmBW1d2jd9i1qjojqwiY7TsMAA6i9ya5Z3d/YPQiM9qqZwC6++Ikzxy9BwCLeKwH/3G2KgB2/HiSV41eAoDj1knO7e7fGb3IzLYuALr7yu5+aJInJvno6H0AOCaXJXlwdz9t9CKz26rXAHyqqvqiJI9KcubO7Y5jNwLgUxxJcmlWr/Y/nOQl3X352JVIkv8PZRApNwJUET0AAAAASUVORK5CYII="/>
                                    </defs>
                                </svg>

                                <span class="is_yen_active">Yes</span>
                            </div>
                            <h4 class="item_price ein_fee">$69</h4>
                        </div>
                    </div>
                    <div class="service-item">
                        <h3>Operating Agreement / Bylaws</h3>
                        <div class="service-description">
                            <div class="item-content">
                                <svg class="service-item_icon" width="26" height="26" viewBox="0 0 26 26" fill="none"
                                     xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <rect width="26" height="26" fill="url(#pattern0_78_243)"/>
                                    <defs>
                                        <pattern id="pattern0_78_243" patternContentUnits="objectBoundingBox" width="1"
                                                 height="1">
                                            <use xlink:href="#image0_78_243" transform="scale(0.00195312)"/>
                                        </pattern>
                                        <image id="image0_78_243" width="512" height="512"
                                               xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAACAASURBVHic7d13mCVVtffxb/ckJhCHHOWSkwgiIIhkQVAwIKKooJjAq5gw8gJiQkVUzEi4IAoCglwDUTKoiICCgOSc8zDDxO73jzV9aWY6nKq9dqhTv8/z7OcGnT6rzqmwqmrvtXpojwnAq4H1gHXmj1WBxYDFgcnAItmiE5EB/cCzwHTgaeAO4HbgZuBy4KF8oYl0j57cAUT2KuCNwPbA1sCkvOGIiIM7gPOBXwN/zRyLSGN1YwKwIvBu4H3ARpljEZG47gR+BvwceCFzLCKN0k0JwPrAF4F9gLGZYxGRtJ4GfggcjRIBkY50QwKwAXAk8BagN3MsIpLXg8BngDNyByJSuiYnAFOAw4GDgXGZYxGRsvwReD/wRO5ARErV1ARgd+CnwCq5AxGRYj0E7IutHBCRBYzJHUBFY4HDsEk/S2SORUTKthjwXuAR4PrMsYgUp0kJwKrAeVhG39QnFyKSVi/wJmAmcHXmWESK0pQEYEPgMqyIj4hIFT3ATthcoUsyxyJSjCYkAFsAFwHL5Q5ERBrt9VjFz4tyByJSgtITgO2AC7FSvSIiobZGTwJEgLITgI2AC4BFcwciIl1FTwJEKDcBWAO4FFg6dyAi0pW2RkmAtFyJCcBE7KBcI3cgItLVlARIq5VYM//HwCsj/v25wLXAlcCtWGexR4EZwKyInysinRkHTAW+gxX9iukQYDZwaOTPEZFRvA/rBe49+oCL5/99zSkQaYaTiXM+GGp8LdE2icgQVgCexfegngv8CqsjICLNkjIBUBIgktGv8D2Yr8dqCIhIM6VOAPqBbyfZMhH5Pzvge9d/GGVOcBSRzuVIAPQkQCShHuAGfA7cZ4Ed04YvIpHkSgCUBIgk8iZ8DthHgI0Txy4i8eRMAJQEiCRwNT53/rr4i3SX3AlAP5oTIBLNtoQfoDOBrVIHLiLRlZAA6EmASCT/Q/jB+fHUQYtIEqUkAHoSIOJsMjCNsIPyD8mjFpFUQhKA6QH/Vk8CRCJ7L2EH4wxg9eRRi0gqIQnA57Hqn3oSIDKM3oyfvWfgvz8auMcjEBHpOi8Ce2BdRT0dgp4EiATpBZ6gfhb+AmoVLNLtQp4AfGL+35iEngSIDCnXE4BXEnYBPxF40ikWEeleM9CTAJEh5UoAtgv89//jEIOItMMMrOCYdxLwZZQESIPlSgA2Cvi3t2GNfkREOqUkQGQBuRKAdQP+7YVuUYhImwwkAX92/rtfRnMCpIFyJQBrB/zby92iEJG20ZwAkflyJABLEDYB8F9egYhIK+l1gAj5EoC6ZgP3OsUhIu2l1wHSejkSgEUD/u1jwFyvQESk1QZeB3gnAYegJEAaIEcCMCXg305zi0JEREmAtFiOBGBywL+d4RaFiIjRxEBppRwJQE/Av+13i0JE5CWaEyCtk7MZkIhISfQ6QFpFCYCIyEuUBEhrKAEQEXk5JQHSCkoAREQWpiRAup4SABGRoSkJkK6mBEBEZHhKAqRrKQEQERmZkgDpSkoARERGpyRAuo4SABGRzigJkK6iBEBEpHNKAqRrKAEQEalGSYB0BSUAIiLVKQmQxlMCICJSj5IAaTQlACIi9SkJkMZSAiAiEkZJgDSSEgARkXBKAqRxlACIiPhQEiCNogRARMSPkgBpDCUAIiK+lARIIygBEBHxpyRAiqcEQEQkDiUBUjQlACIi8SgJkGIpARCRUs0N+Ldj3aIIN5AEXOr8dw8Bvub8N6VFlACISKleCPi3U9yi8DEDeBP+TwK+jJ4ESE1KAESkVNMC/u3iblH40ZMAKYoSABEpVcgTgP9yi8KXngRIMZQAiEipHgv4t+u4ReFPTwKktXYG+muOazPEKyJ5bEX9c8VcYMn0IVcyCbiY+ts43NCTACmWEgAR6cRShF0I90wfcmVKAqRVlACISKeeoP754vgM8dYxCbgE/yRArwOkOEoARKRTf6T++eI57OLaBHoSIMlpEqCIlOySgH+7GLC3VyCRaWKgtIKeAIhIpzYl7A74Npp1o6MnAdLVlACISKd6CZsH0A+8N3nUYTQnQLqWEgARqeJHhF34HgWWSB51GD0JkK6kBEBEqtiC8AvfCcmjDqcnAdJ1lACISFW3En7ha9qrANCTAOkySgBEpKqDCb/oTQe2TB24Az0JkK6hBEBEqpqE9QYIveg9CWyQOHYPSgKkKygBEJE6vojPRe9pYOvEsXvQ6wBpPCUAIlLHYsDj+Fz0pgPvSRu+Cz0JkEZTAiAidb0f3wvfiTRziWCMJOBzKTdC2kkJgIjU1QNche+F71FgP2BMwu0IFSMJ6MO+B5FolACISIhXArPwvwO+HTiAZjUQ8k4C5gDbpNwIaRclACIS6pP4JwAD43ngf4C9gKmJtqeuGEnAA8DSKTdC8ujJ8Jk7AxfW/Ld/BzZ3jCW2pbHZxisDUzLHImm8CDwMXDP/f0ocPcA5wJ6RP6cPuAv4D3AnMA2bQFiSSdj7+0Uc/+bvse6EIq7a8ARgLeAsYC7x7lI0yh59WKK7KRLLktjFOfdv3a3j7Z3/FCKd6fYEYDfsEWLug1ejjDELm7kucawBPEL+37kbx/3oyWVXa1Kf7CbYHLvzXzR3IFKM8cDxwJtyB9Kl7gJ2xx7Ni69VsLkW0qWUAPjpBX4OTMwdiBSnFzgOmJw7kC51Pfa+WkmAv4PRftu1lAD42QV4Ve4gpFgrAPvmDqKLXQZsh/ULED9LAx/KHYTEoQTAz265A5Di7Z47gC53PfA67LWA+Plo7gAkDiUAftbIHYAUT/tIfHdiKy/OzB1IF1kH2Cx3EOJPCYCfJpURlTzG5g6gJZ4H3olNYJudOZZuoddXXUgJgJ8Hcgcgxbs/dwAt0g/8ALtzvTJzLN1gl9wBiD8lAH7qVjeU9rggdwAtdBOwLdbkRhME61sXWD53EOJLCYCf/0V3eDK8acCpuYNoqX7gFGBNrGSuEoHqeoDX5w5CfCkB8DMT+AR2shFZ0BfQhSe3F4DvAKtjx+otecNpnA1zByC+lAD4Ohf4FFYHXmTAd4Cf5A5C/s+LwA+BDbA5Asei5KwTa+cOQJqv23sBgG3jv8lfy1sj77gX2Btpgh5gI6zy3bmov8BQ47ra364USe2A4xkDvBarTrYCWgLWFn3Y3eTVWHW6OVmjkRCLY3e962AT4KZgfT6a3CBnOeq3UL4Xe30iUlsbngCIiJRoQ+qff5/MEK9EpDkAIiLt8VTAv23ykw8ZghIAEZH2CKmMqNeYXUYJgIiISAspARAREWkhJQAiIiItpARARESkhZQAiIiItJASABERkRZSAiAiItJCSgBERERaSAmAiIhICykBEBERaSElACIiIi2kBEBERKSFlACIiIi0kBIAERGRFlICICIi0kJKAERERFpICYCIiEgLKQEQERFpISUAIiIiLaQEQEREpIWUAIiIiLSQEgAREZEWUgIgIiLSQkoAREREWkgJgIiISAspARAREWkhJQAiIiItpARARESkhZQAiIiItJASABERkRZSAiAiItJCSgBERERaSAmAiIhIC43NHUALLAmsCCySOxARcfU88CDwYu5AROpQAhDHeOCjwAeAjTPHIiLxzAYuA74LXJg3FJFq9ArA3+rAdcAP0MVfpNuNB94AXACcjJ70SYPoCYCv5bC7gVUzxyEi6b0PWBTYC+jLHIvIqPQEwNdx6OIv0mZvBT6UOwiRTigB8LMJsEfuIEQku8OAMbmDEBmNEgA/b88dgIgUYUVgy9xBiIxGCYCfDXMHICLF0PlAiqcEwM+U3AGISDEWyx2AyGiUAPh5LHcAIlKMR3MHIDIaJQB+rs4dgIgU46rcAYiMRgmAn7OA6bmDEJHsrgDuyR2EyGiUAPh5HPhG7iBEJKs5wGdzByHSCSUAvo4CzswdhIhk0QccBPw9dyAinVAC4KsP2Ac4EpiVORYRSechYE/g+NyBiHRKvQD89QGHAycC+wLbAysBE3IGJSLupgF3AucBpwEz8oYjUr6dgf6a49oM8YqIdIup1D//zs0Qr0SkVwAiIiItpARARESkhZQAiIiItJASABERkRZSAiAiItJCSgBERERaSAmAiIhICykBEBERaSElACIiIi2kBEBERKSFlACIiIi0kBIAERGRFlICICIi0kJKAERERFpICYCIiEgLKQEQERFpISUAIiIiLaQEQEREpIWUAIiIiLSQEgAREZEWUgIgIiLSQkoAREREWkgJgIiISAspARAREWkhJQAiIiItpARARESkhZQAiIiItJASABERkRZSAiAiItJCSgBERERaaGzuALrY2sD+wOuBlYHFskYjIt4eA+4D/gScDDyXNxyR8u0M9Ncc12aIt6qxwDHAHOpvp4aGRrPGE8A7Kd9U6m/j3AzxSkR6AuBrDHAO8KbcgYhIUksDpwHLAj/MHItIRzQHwNfh6OIv0lY9wPeArXMHItIJJQB+VgQ+mzsIEclqDPCd3EGIdEIJgJ93ABNzByEi2b0WmwQsUjQlAH62zB2AiBRD5wMpnhIAP8vmDkBEirFc7gBERqMEwI/WAIvIgGdzByAyGiUAfm7KHYCIFEPnAymeEgA/Z2HFMkSk3e6nGUXLpOWUAPi5CTgzdxAikt1hQF/uIERGowTA10HAXbmDEJFsfg2ckjsIkU4oAfD1FLAtevwn0kY/wRqA6VWgNIISAH8PAVsBBwB/QY8CRbrZDKz/x9bAx7AmYCKNoGZAccwDTpw/FsHWBI/JGpGIeJuJtQSelzsQkTqUAMQ3E+sZLiIiUgy9AhAREWkhJQAiIiItpARARESkhZQAiIiItJASABERkRZSAiAiItJCSgBERERaSAmAiIhICykBEBERaSElACIiIi2kBEBERKSFlACIiIi0kBIAERGRFlICICIi0kJKAERERFpICYCIiEgLKQEQERFpISUAIiIiLaQEQEREpIWUAIiIiLSQEgAREZEWUgIgIiLSQkoAREREWkgJgIiISAspARAREWkhJQAiIiItpARARESkhZQAiIiItJASABERkRZSAiAiItJCSgBERNpjOtBf89++4BmI5KcEQESkPWYCj9f8t/c6xiEFUAIgItIuF9b8dxe4RiHZKQEQEWmXY6n+GmA2cFyEWCQjJQAiIu1yHfCTiv/mK8BdEWKRltkZyz7rjGszxCsi0m3GAWfQ2Xn3J0BPnjCl2ygBEBHJrwc4CJsUONT59j7g3dmik+jG5g5ARESyGLi7PwHYHtgUWBJ4ErvZuhKYmy066Up6AiAiIpKZJgGKiIi0kBIAERGRFlICICIi0kJKAERERFpICYCIiEgLKQEQERFpISUAIiIiLaQEQEREpIWUAIiIiLSQEgAREZEWUgIgIiLSQkoAREREWkjdAKVUk4HxQB/wXOZYRGR447HjFWAa6iDYGEoApARjgNcDuwOvBTYAFh/0n88Gbgf+AZwP/BE70YhIehsAewDbAa8Elh/0n/UBDwHXA5cCvwPuSxyfFEztgGXAJOCzwL1U2w+eB34MrJw8YpH22hO4hmrH6jzgPCzBF1ECIAC8FbtTqLsv9AMvAt/gpcePIuJvU+Bqwo7VfuxpwAqJY5fCKAFot/HAzwk/mQweDwB7p9wIkRaYCvwMu4v3OlafBHZKuRFSFiUA7TUJuBjfi//gcQn2flJE6hsDHAg8RZzjdA6wb7KtkaIoAWinsdgEvlgX/8Enl+/x8kmEItKZrbEJfLGP07nYa0BpGSUA7fRd4p9UBo9Hgf2BngTbJtJ0KwCnYLP4Ux2j04D1U2yclEMJQPtsS9oTy+Dxd2DL+Jso0khjgYOxWhs5js/rgXHRt1KKoQSgXcYDt5Ln5DIw5mF3N8tG3laRJtkeuIm8x2Y/8InYGyrlUALQLp8j/wlmYDyN3e2MibrFImVbCUuIcx+PA+M5tDywNZQAtMfy5Hu0ONK4AXhdxO0WKdF4LAGeRv5jcMFxQsTtloIoAWiPU8l/Yhlu9AEnA0tH23qRcuwC3En+4264MQ/YItrWSzGUALTDNuSb+FdlPIaKCEn3WgI4ifzHWSfj76hDbddTAtD9xgA3kv+EUmWcAkyM8WWIZLIxZd/1DzU+GOWbkGIoAeh+HyP/iaTOuBorfyrSdHsB08l/TFUdjwNLRvg+pBBKALrbMths+9ATwY+wSUs7Av9y+HudjltQl0FptgOwSnspjpe5wA+x435N4EGHv/kj/69ESqEEoLsdR/gJ4G5e/jh+LLZW+BmHv93JuA1Yzu8rEUnm/aSbe3M59pphsL0d/u7cIf6udAklAN1rM3w6h+05zN9fFlsu5NmdbLhxA2ozLM2yG9YLI/ax8RDwboYvs/1nh8+4YoS/Lw2mBKA79QJ/JfzAP6+Dz9oc2xdin+jOQichaYa1geeJezzMAr4FLDpKLBsAsx0+Tx0Du5ASgO70AXxOMGt3+Hm92Izhxx0+d6ShMqVSuonEnydzPrBOhZi+5/CZDzF6siENowSg+yyBracPPeCPqvHZS2KTkGI9+pwBrFcjLpFUjibehf8e4C01Yloc68gZ+vnfrvHZUjAlAN3nB4Qf6I8AiwXEsC5woUMcQ40r0asAKdMr8XncPlTiexQwJSC2/R3imIUd29IllAB0l43wuft+l0MsPdjkJI+lSAsOVQuUEl2O/75+DrC6Q2w9wDUO8VzgEIsUQglAd7mE8APc+w57EnAEMNMhtoFxO+oiKGXZBd8L/+3YSgJPm+JTk+CtznFJJkoAusc+hB/Yc7CnCDGsg+8d0j6R4hSp4yp89us5wGFY4a0YfuYQ4z2oVHdXUALQHaYADxB+YB8bOc5e4FB8agdcFTlWkU5tjM/F/z7it8aeCjzlEOsRkeOUBJQAdIdvEn5AP4atIEjhg/hUSNsgUbwiI/kJ4fvyHVhxrRQOdIh3Bj5zEyQjJQDNtyY+79c/kDjuQx1i/krimEUWNIbwZbePA2sljLkXa/cbevydkzBmiUAJQPP9ifAD+W/k6f3925rxDoyb0ocs8jLbEbYP9wGvTx00sDU+T+F2SR24+FEC0Gx7En4AzwO2SB34fKsAL3QQ40gnTzUKkpy+Stjxd3L6kP/PKSPE1em4A5iQOnDxoQSguRYB7iL8AP5F6sAXcARh8e+VPGKRl1xK/X13OrB8+pD/zwrAc0PEVXV8PnXg4kMJQHMdRviB+zTWOzynlQlbFfD19CGLAFYvYxr1993T0oe8kM8Qfh6ZBqyUOnAJpwSgmVbD7h5CD9z/Th34MEIKGJ2bIV4RsOQ15Ph7U/qQFzIOuIXwc8mvUwcu4ZQANFPo5Ll+4J/A2NSBD+PThG2HSA7bU3+/nU28Yj9V7UT4+STXZMaukWMWtjTPjsDbHP7OwVhZ0BL8J+Df5nyHKu0W8vrsLiwJKMHF2E1FiB6sHkIpNxWNowRARjMOa7cb6tfAZQ5/x0tIArC4WxQi1YQUzgrZ52P4NFbcJ8QGWJEhqUGZk4zmYGC9wL8xDTjEIRZP0wP+bSmPUUMtD7wCe6+8FNZEaQK2THIm1s/9PuBuwk/UpVkcaz89EXsqNQ+boDotZ1AdCFn+FrLPx3A/1nL4yMC/cyTwG6y4kVSgBEBGsgI28z/U14CHHf6Op0kB/7Yfe/zY7xRLCosC2wDbApsBr8Iu+p2Yh909/gObPHkx1nK5CaYAr8HqTrwGq363OsP3uZ+OJT3/xuZ6XD1/zIkeaWdCXqGF7POxfAfYH/ivgL+xBPANrNy3FE6TAJvjl4RP1LmNMu+YQ5qpPJch3jqmAh8CLsIuYKG/5eDJV1cDB83/jJJMBt6AXRD+gs92P4+VoP0osGq6TRnSB6i/HRdliLcTbyb8N5oHbJ46cKlOCUAzvA6fsp1vSB14h/an/jbdmzzazi2FXSTOx/eiP9yYhS2LfBtWoz61Sdgk1a9h3RpnjxJv6OjDCvHsz/BPEWLavUKsC44nsCdXJfoj4b9NrvLiUoESgPKNAW4g/IA8O3XgFZxA/e26PEO8I+kFdgXOxC7IsS/6w407gA8Tt0zrIthSuK8AV2Te3hewsrpbRtzeBW0SGPP6CWOtYi18GowdkDpwqUYJQPkOIvxAnIFNMCvRGOwuvu62XY5diHJbHZsAdT/5LoJDjYeBz2GT7EJNwNZ6H47deb9YwPYNNa4D3k/8/WIKYVUsPxk5vhDfIPx3eBxYMnXg0jklAGVbGniK8APx8NSBV7AX4dt3F9YYKbVFgHdhE/FCLgQpxtPY6o8qF8Vx2OunQ+dv44wCtqPKeBL4NmGT2kZze0B8d1Pu5O/JwAOE/wbHpg5cOqcEoGw/J/wAvBtbXlWqv+F3wj8fWDdBzK/C6jE87Rh7qnEfsB9Dv5/txWbnfwm4kLBOjSWNeVjb7DcNs90hfh0Y27ud4/H0TsK/+znAK1MHLp1RAlCuzfC5q3xL6sAr2AP/k/0crMOh9wzxJbDXMf+IEHOO8U/gjVj9gf2wC9kTBcQVezyAPRXwuii9PzCeUlfmDLiU8O/8csqd8NhqSgDK1IMtmwo98M5PHXgFXu2MhxszgVOxWel17/rGYxP6TqXc990a9cdNwBew+Rt1begQx+cCPj+2DfFZwVLyk47WUgJQptC7in5sRvY6qQOv4P+R7kT/EHAKtlzsVQy/ZGwStn75IOyi/0zCGDXyjr8D38SW9r2C4ZPG5bCk8svAn/G5OJbeTvf7hG/jg+RZqikjUAJQnsWxsq+hB9y3UgdewWr4tDMOGQ9jTyAGRkhfd43uGzOxxPFWrPLiQAnmWJ9XcjvdNpyTWkkJQHk8su1H8Fn2FYtHO2MNjW4b21GuNjyVbB0lAGVZH5/qae9KHXgFO5L/RKuhUeK4mXKXBXrNS7owdeBNobKJ8iNs7XWIq4DTHWKJYSz2hENEFlZyO91+4GPYyqQQO1P2yqRW0ROAcrRhze1nyX+XVfKYiy0Luwg4CzgDW8lxA80rwlN1zKJ76g6EjGeAZSnXcYRvY+m1SVpDCUAZvKpu/TB14BWsgHVyy32CLWnMxZ7YHIrVsB+pRew44NXAZ7BHsR7NoXKNGdgM+sOBt2PvhQc/+u4B1sCaGh2JzdBv8vZWHcdTrjZUJ20NJQBlaEPdbY92xt0yrgU+Qdid3mrAV4HHCtie0cZM4DLgCGBb6jUoWhU4GPhXAdsTe5TeTrfb+5O0hhKA/NrQecurnXGTx2PA0cB6gd/lghYBjilg+waPWcCV2N37Dvg/7n0dVqfB47gpdVxLufPC2tChtBWUAOTX7b23vU4W/6R5rxDmAn/AHmWHTu4czgr4vD4KGXOAa7AnWTtjr7RSWAarondnhG0qYXzQ76ty55XUvyF14PISJQB5vZnwA6gtjwtXB1bEXiWU/jThTqxSXOzqbhPwWZpVdczFks5vYf0Ecld468VKNp+DxZb79/cabXitV3ovhK6mBCAfr1r4bZgwdMQCf3cTfJ6ceI4Z2Alxe9I1Pjkq8jYNjLlYE6SjsY56JReZWhnbXx4k/z7hMdowsfeQ1IGLUQKQj0ct/NKXDHm0M76H4d8hbw1c4vAZIeM67CnHEnW/pJq2JO7d7r+wmg17UPZd6HDGYI+Xf0mzlxfOBTZ2/m48eSztfR57uieJKQHIY1V8auF/PHXgFbwan3bGb+3gs9YHvku6GfEPA8dijYVyGAfcMkqMdcZ/sOVZ3VaudQrW8vhCfJr3jDb6sEmQH8JWP4T+vfPcvxE/47B+CaHb+KvUgYsSgFzOIvyA+SfdXzb0goqfOx5LGE7Anhx4ntTvxh6Bb03+CZce8yoGjweAD2B3zd1uKja57nx8iyvNAq7AajqsMejzPNrp9mFJbqlCriODt3Gb1IG3nRKA9HbC52B5ferAK9gfnxNq6J3oGsCHgZ9g1fXuZfSnEnOwO/wLsfawexHWL97bYvg96egDvkN7q7KNA7YAPgmchp3THmf0720mloCfDhyGTYQcaeWDR4Ovg122OB6PBl830o4ktBhKANLyenTbhtah344U3yLAfwFrYq8pXg1shSUbS0X6TE+fx+fi/xy2PFEWNgXbRzbkpf1jE6xwzeI1/p7HMXFs3Y1JZDV8Xmv+d+rA20wJQFqfIfwAmUb85WUhPO52HgIWTR14A4wF7if8+30K2Chx7G23P2G/2Y+SR1zdYYTvm09j9R0kASUA6ayA3XWFHiCfTx14BR7vO/uBd6cOvCH2xieB3DJ14BI8L+ZT6UOuzGtp8y9SB95WSgDSOYXwA6P0ohkeS/KuIN06+qb5A2HfbR+2jl/yCFkZU/IkwMH2JPwcMA94TerA20gJQBpb41O9bpfUgVfg0c649DXPOS2JTYwM+X51Z5VfndoYF2WJtL7zCD8X/JX8q226nhKA+MYA1xN+QJyTOvAK2tDOOLf9Cftu76PsCn5tsRjVehc8j38DqdjWJjxZ7ceWpkpESgDiO5DwA2GgFn6p2tDOOLfQV0gfSh+yDGNtOqtT8RzWTbGJvkn4OeEx0lfYbBUlAHHFqoVfEq92xiV3PivB3YSdSNu61r9US2OvZIa6U+4Dfs/LCwo1zRR8+jH8IHXgbaIEIK6fEX4A3EPZJ2+Ppjwl9z4vwYqEfb9fSR+ydGgqturlK8CR2GPv/8oakZ99CD83zEFLVqNRAhDPpvg0a+mkFn4uexC+ffOwamwyvNBSq5ukD1kEgEsJP0dciVYGRaEEII4ebDlb6I5f8uzfCcDthG9jye2MSxEyj+RJ9HRF8tkAmE34eWKf1IG3gRKAOPYnfIefBaybOO4qDiV8G0tvZ1yK71D/O/5thnhFBvsB4eeKB7F5BeJICYC/xbBmMqE7/LdSB17BKvj0WC+5nXFJTqI79yNph8WARwg/X3wzdeDdTgmAv+8RvqM/Qtlrtj3aGd+MNUeS0Z1B/e/5sxniFVnQAYSfMzw6hMogSgB8rY/P+66Sa+HvSPj29QPbJY67yUJWWrwvQ7wiXIUtqQAAIABJREFUC+olrBfCwLgwdeDdTAmArz8TvoNfRbkzXscC/yJ8G0tuZ1yiC6n/Xb8jQ7wiQwnphTB47JE68G6lBMBPG2rhe7Qzng6smjrwhlMCIN3iF4SfQ+7COg9KICUAPiYB9xK+Y5dcC3854FnCt7HkdsalUgIg3WIqtjQ19DxyWOrAu5ESAB9fJ3yHfhI7OErl0c74Dqx+gFSjBEC6yX8Tfi6ZAbwicdxdRwlAuDWAFwnfoUuuhb8VPu2Md0sdeJdQAiDdZAxwI+Hnk7NSB95tlACE+wPhO/J1lFutrRf7rUO38XepA+8iSgCk22yNz03FrqkD7yZKAMK8mfAdeB6wZerAKziI8G18ke5pcJKDEgDpRr8i/NxyO3qtWJsSgPoWAe4kfAc+IXXgFUzFp52xutGFKTkB2B44FjgPuAQ4EatjMT7y50rzrQg8T/j5RcWualICUF8bauF7tDO+l7LbGTdBiQnA+sD1I3zuo8DHsPe9ksYkrFLeRvP/9yY4hPBzzPNYMiEVKQGoZ1VsPXvojvuJ1IFX4FW0422pA+9CpSUAO9B5L4gbgW0ixCAv2RW4mJdXIe0DLgf2zhhXJ8YDtxJ+nvll6sC7gRKAes4kfIf9F1ZZr0Q9wDWEb6PKdvooKQFYDXiiYgx9wKnoLs3bRDpbnvtHYNFMMXbiDYSfa/qA16UOvOmUAFTnUQu/D9g2deAV7Ef4NpbezrhJSkoAjg+I5Xnska/mB4Qbg62s6fS7v5Kym2+dTfg55wb0yqkSJQDVjAP+TfiOelrqwCtYHHt/G7qN30kdeBcrJQFYAp+aF7did31S30ep/r1/LUuknXkFVtwndN86KHHcjaYEoJpPE76DTgNWTh14BccQvo0PUfYjx6YpJQHYOiCOocbZqJpbHWOwY6zq9z0LWDtDvJ06nPB96ilg6dSBN5USgM4tDzxH+A76hdSBV7ABPu2M35M68C5XSgLwnoA4hhszsBO/Vop0bhvqf9/nZYi3UxOBuwnfp45LHXhTKQHo3MmE75j/oez3nx7tjK+k3HbGTVVKAvCRgDhGG3cDb3GMtZt9jLDves/0IXfsLYTvS/OAzVIHHqrUUrBitfDf6/B3DsbusEu0N7a8K8Q84OPYQSjdJ2byujpwDnA+tpZdhhf6tOR7Dn8jlt8BFwT+jV6ss2qjbkSUAJRpDD4707nYya1Ek4GjHf7Oz7B139KdlkzwGbtgS2S/BUxJ8HlN9ETgv18d+JxHIJF43ChtCewfHkp30yuA0dWZbbvgKL0Wvkc74yeApVIH3hKlvAI4ISCOOuNBrKxwo+7kEliD8O+29Ha63yJ8Gx/FVjXJMJQAjGwq8CThO2LJtfDXBGYSvo0fSh14i5SSAFwVEEfIuBx4peN2dAOP+TpnJ4+6c1OwBDB0G7+fOvAmUQIwsp8SvgPeS9l1uT3aGf8dvcKKqYQEYCI+NQDqjjnYq7gUryGa4HX4tNMtuR7Du/HZbzZMHXhTKAEY3qbAXMJ3wJJr4b+J8O0rvZ1xNyghAdgpIAbP8TjwQZRwgpVXDv0+b6XclUk92NOf0G28NHXgTaEEYGg9wBWE73gXpQ68gvHYssTQbSy5nXG3KCEB+EVADDHGP7DVOW22PPAs4d/lIakDr2AD7C4+dBvfmTrwJlACMLT9CN/hZlN2LXyPdsbPASukDryFcicAi9N597+Uow9rhrOcwzY2VRva6f6Q8G18AK0qWYgSgIUtBjxC+A5Xci18r3bGB6cOvKVyJwCfD/j8FOMZrLV2qd01Y/Jqp3tq6sArWBJ79RO6jd9IHXjplAAszKMW/iOUvfzEo53xzZTdXayb5EwAvEpgpxhtbTLkMT+j9A6lHyR8G2ehIlMvowTg5dpQC9+jnXE/sF3iuNssZwJwWsBn92OTRD0v8p2M04CVAre7aTza6d5Iue10e4G/Eb6Nf0wdeMmUALzc+YTvYFdRbuGSsViVNY8TrKSTKwE4OOBzB8bpWInpmx3+VpUxHTgCmBCw/U2yKj7zND6WOvAKXo1PQvnm1IGXSgnAS/YmfMeaC7wqdeAVeLQzng6sljrwlsuRAOyCz+zr7eb/vXFYQpH6dcIdwO41v4OmOZzw7+tpYJnUgVdwPOHbeBewSOrAS6QEwEwG7id8x/px6sAr8HqX+8XUgUvyBGBXYFrAZw6MW1n4adiK2IQzjyI2Vca5lF2O20Mb2ukug036DN3G/5c68BIpATBfI3yHKr0Wvkc749tpzyPVkqRMAD6OzzyYfuCgET5nG+yds+dFfrTxInAkZVfmDLUn4d9T6e10BzqOhgw9yUQJALSjFv5W+NxxvTF14AKkSQBWA/434HMWHHcweoW5Mdg756cdP7eTcS/w9g6/lyY6j/Dv6K+UW21xLPBPwrfxrNSBl0YJAPye8B2p5Fr4Y7CqaaHbeG7qwOX/xEwAlsM6r3nUhRg89q6wfUtjj51Trxi4CFivQpxNsTa25C30+3l/6sAreD0+NzU7pQ68JG1PAHYnfAfqo+xa+G1oZ9ztQlanfGCIv7cC1mjlHHyefi04/kK9lTCbYXee3vGMNGZjRbsWrRFvyY4i/Lt5DFgideAV/JrwbbyFFtczaXMCMAF7TBm6A52YOvAKvNoZH5k6cHmZswg7iZ8AnAFcgpVEjXlBnU7YXXUPduf5aOQ4FxwPY/U7Sl3CW1Ub2umuhM9k1c+kDrwUbU4Avkz4jlN6LXyPdsb3Y6skJB+PWuipxoFO27wEdhfr8Si76nltc6dtyM2rne4rUwdegUeZ6tJ7IUTT1gRgFXyKZpRcC9+rnXE3T5ZqigNJexGsO36P/x30hlg715TbMRdb0lvyqp5O9ACXEf59XJo47irGA7cRvo2npA68BG1NAM4gfIcpuRa+Vx/ti1MHLkPaiLQXwLrHw5KxvgCsetu9ibfpaSzJL7U8bifa0E435Do2MPqwiYWt0sYEYHt8Tg7bJY67ivcRvn2z6c4Z0k3UA9xD2otflXE/aWrvT8Y6usWYuDjSuA54bYLti+VYwr+D0tvpnkP4Nl5Puau5omhbAtCDLdkL3VFOTx14BV7tjI9OHbiM6Cukveh1Op7E7jJTWgtr6pJyO/uAk7Blk02zBDYZNPQ7+GbqwCtYHZhB+Da+N3XgObUtAfBY9vcCsHLqwCv4LuHb+DCWSEg5lsV/rX7ouI+8T4neDNw5RFwxx7PAJ7FiNE1yAOHbPhNLvkp1BOHbeBvdsxJkVG1LAM4lfAcpuRb++viUcW1VFtwgJT0FuIkyWu4uAhxK+uToZux1YlN4tdP9U+rAK5iIz6uyJv2uQdqUAEwh/N1h6bXwLyZ85y+5nXHbTQT+TdoL3VDjVMornLMqcCbpv4vfYKuKmuA1+FRb3CN14BW8lfDt+2HyqDNpUwKwG+E7Rsm18PcifPtKb2cs9r49dUvdgTGdoSsLlmRH0idJLwBfouybgwFtaKd7AWHbd1v6kPNoUwIQWvin5Fr4k7D3saEHdsntjOUlO+Iz4anKOJvmdE8bB3ya9InSHdg8o5Itg0/zpZLb6a5LWAGpeZS94sFNmxKAkMy39Fr4bWhnLC+3GT6lXkcbNwC7Jtomb8tjbbA9msZUGb/HuoyW6r8J38bS2+l+m7DtS72yJYs2JQAh60S/myHeTq2BJSihB/SHUwcuwVYEriDORewK7JVXN8wH2QqfjphVxkwsMS+xjHYb2ukuiq3YqLttrSgKpASgs3FIhng75dHO+DpaVgCji/Rg5Zr/Q/h+cDd20Vo/6RakMQbrjOnRHKvKuJ/RWzLn0O3tdHsJa3ylBGCU0bQE4ETqb+uzWGON0u6GvNoZN7nKmZhxWLnW/6WzDml9WGnds7BHwhtQ3v4dw1SsSZZHn4wq48+U91j5V4RvV4ntdJchfNs2TR51Bm1KAD5H+M5+OeV0xvJqZ3xS6sAlunHAJsA+wEFYx7QPA/sCe2L7cMmzuFPYFLiatEnAbOAYYPEE29eJbmunOwZLZj0mOS6TOPYs2pQA7IHPQTwP6xy1dNrwF9KGdsYiMfVgj+fvJ20i8CTWZKiE127d0k53G+BGfH6fRxLHnk2bEoCV8J0N/DhWXjPHQezVzviTqQMXKdBi2ERfjyqaVcY15H/U3PR2uitij/s9z+1nJN2CjNqUAIBPI6AFx9+wClsp/dYh7ptpXj1zkZjWx6eaZpUxD/gZNjchl12GiKvq6MPuwlMZj03Oft4h9gXHvgm3I6u2JQAHEu8gPp40740+5BRza+pdi1S0Fz6FtaqMp7Dz05gE2zcUj3a6/8GKksX2BnyeWgz3O0xMsA1FaFsCMAWftpjDjaexSSix7qw3wqcC3G8ixSfSLSYBX8WnxkaVcT2wdYLtW5BXO90ziLea5BVYRcqY3//XIsVepLYlAOBTBWu08U/815FuCjzqENsLNKd5iUhua2BLK1MmAX3YO/XUE3SPCIx7YJyK79LAicDhxC9//TjlrNBIoo0JwBjSLP/pwyaneMyOfQN+dc2/VOPzxwJLAitjJZFzvq8UyWE3rBtoykTgOWyJXap19l7tdPuB8/G5mL4FK1CV4vt+p0O8jdLGBACshvXjpNmppgFfpF77VO9a5ncweseySdhB93Ws9/fDw/ytF7GTxUXAYdgEoCZ0QxOpawJ2LHuswKkybiFdxT2PdroD41HgfdR7JbAhlkSk+o5/WiPGxmtrAgCwJWm7hT0DfAN7jzWaLbCe1N7xfY+hD8Zx2EX/NMJObjOwR5dbdLCNIk21MnA66c4dA+Ms0jTgCW2nu+C4DvgYo9dOGY9dk87EJlan+l7PpYBqhjnKcO4MXFjz3/4d2Nwxlhy2wH785RJ/7v3Aldgd9AtYWdLlgHWAjYl7kF8NfBzr8jYGW/JyOP7dDv8BHI1NOOx3/tsiJdgeOBa7W01lBnAU8B2s4VAM6wD/wi7InuZg553bsNcpc7EL75LAq7HrSeoZ+KcD+2E1IFqnzU8ABqxKvI5qpY652KuFWxJ81iXAeh3/GiLNMhar6hfSea7OuAurbhrL1xNvT+rxIja/og39L4alBMD0YjXTPWpIayw8ZmHLa1R4SLrVcljDMc+KdJ2MPwFrRdieCcC/E29LqnEpuikBlAAsaGngONK+f2rT+DM+PRRWwRrdHI0VMLkeuyN6Epu0eBf2quNU4FBgR+pNwpQyjAPWxR4Tr5E5ltFsSZyKoyONmcA3gcmO2zEe+Hni7Yg9HqCFM/1HogRgaJsBfyX/DtuN426s6EhVa2KFWW6q+bkzgfOAD+B7opR41gF+ycITUx/GniiV2rGtF6vY+QRpj60HsMQ41G5YVb/c5wqvESNB6gpKAIbXA7yfuJUD2zrupfMkYBvswu35VOYZ7OnBsh3GIOl9BHt1NNrv+HHKfbW0FPAjbM5NyuPrUqxqaFVrA39MHGvsEesVSVdQAjC6JYDvYzNYc+/M3TTuZuTXAevivxxpwTENWwGh+gVlOYBqv2OMypueXoWt+kl5fM0BfoCdv0azKPAtRk+4mjRiT5LsCkoAOrchllnn3rG7afyZhe/exgBfxh7bpYrjFuzdreS3OjCd6r9hH/BrrO13iXqwJbcPkfYYewx77TVc2/I9Gb7YVxPHdOD/AYsMs70yiBKA6t6JvWvLvaN3yxjcfGMZrLJgjjhmY4+TJa8fE/Y7TgM+h/8adi+LAt/G9reU+/dfeXnb8iWwpcC5j3/PkapQUtdQAlDPZGxSScq71G4dc7BHpGuQrub3SON48rVkFb875NuwPvelWhcrwpZy354H/AJrd9xNNzEpSyV3FSUAYdbCJpnk3PnnkX7tsfe4CXikgDgGxq8pd2JZN1sW/9/yHOqtOknlbfg14GnbeB74LAWU8W0qJQA+9iBP0YxrsDbBW2Gld3MfkN00TkRSW504v+UMrNVt6jKznZqIxRe73W23jLnASaRvl9x1lAD46QXeBdxK/APgRqxr1+Aylr3Y0qmYJ5HnaFe1xC8gKS1C3CVz92DHTalWx55Y5N7vSx3zsKdz69T9guXllAD4G4NNFPw9vstqXsS6ZO3A8PWrd8P3dcDj2CS91/HySVVTgG2xZUbdnBDMo+zlZd3oWuL/rhdQ9kVkF2wOQ+79v+p4FJvgeJ3z330IW6ZY8m/WSEoA4loKW9N8LvUmNz2Itdd9D7DYKJ+1HHYAehxwc7ClNJ1UzpqKzdxu+jyE4cY9jP7di5+PkuZ3nYVdVEotET0e+Dy2qiH3MTDamA0cAyw+KP61sOW8F1K9rflcLIk4BtiVlkzKVTvg7rcCL9UzX3LQ6MEe3T+JTYa7A2vH+UiHf7cHm4y4q0OMTwFvAa6q+O/2xd6bl7r8KsTRwCG5g2iJsdjJf+NEn/cw9tuehl18SrMS1vp3H8rsXHch8Ens1edweoH1sZUPK80fg5OFPuwG6R6sSuhN2AQ/iUxPALrDJ/HJ5F/EHvfXtbdTHKWNmZQ9k7zbrIY9/Ur5G19BuqSjjtdjFQ9zHwsD406siJA0mBKA5tsYv3oEBzjEE1rIpdTxC4fvRjq3POnXyc8Ffog9lSvRWKxYVc55Ny8AX0KV9rqCEoBmm4Tf8sMznGJaCnt8l+JkNAebbPkJYGtsktCG2CSqr+C7ImMGPq2MpZp9SF+05nHggwxfPje3ZbCENGXb8j7gV5RballqUALQbD/F5+C+D9+7nu87xTXSOAX4r1Hi6AF2B253+szP1vw+JMxA5c3UzWqupex5Tq8B/kaa7+LsRNskCSkBaK498Tmw5+K/1C1kvxptvAC8u2I8k/BZX/3Xip8rvtYmfeXNecAJlNs6uhd7dZeibfk7E22TJKIEoJlWwlYMeBzUX40Q3ySn2BYcc7E7+jrGYEVEQj6/D1i55ueLnz2wdq8pE4FnsFdNpZaIXgI4lrhty58DXpFoeyQBJQDN04Pf5Ki/EO+EFmP98qcCY5qMLTEKiWGfwBjExyJYrYo6rYNDxr+wIlil2gi4jHjbr1cBXUQJQPN8AJ8D+TlGf4cewusJxcD4Iz7roHcIjOMH2MVnLaymw2uAbYD1sMlZktZqWBvYlElAH/Y0qdQJcT1YWfJYSyl3TrcpEpMSgGZZGr8lQO+JGOckfCsDPorvO9hrAmIZ7RHrM8DlwHeBN6DlUqnshLWFTZkITMOq9ZVa/GoKcBT+kyevSbkREo8SgGb5Nj4H8KmR49zcKc5+LJHwqHA42Gcd4+vkInEC1rFR4hqH/baplqEOjP/gv496Whs4D99tfm3SLZAolAA0x7L4vO+8i/i17Y9yiHNgfC9CfJs6xldlXAVsH2F75OVWAH5J+v4Uv6PsipF7YuV2Pbb1tMSxSwRKAJrjC4QftHOIn7lPol7jo6HGjcCECDEu6xRf3fF7tJoghdcBN5D2t52BFaGamGD76lgc+A3h2/kC5W6jdEgJQDP04FPM5tAEsR7uEGc/9rRj/UgxTnSKMWQ8B+wfafvkJWOAg7AmVyl/33uAtyXYvrp+Tvg27pE8anGlBKAZNiP8YL2c+G01N8TugDxOoB+NGOdqTjF6jOModxJZN1kau+ilLJ/bjy3ZXTfB9lU1BriAsG37WfKoxZUSgGb4MmEH6tPAqpFjXARbI+1x0jwncqwxKxXWGRdgNQokvldj9S9S/r6zsQm8iybYvirWwDqA1t2uf6QPWTwpAWiGSwg7AXl0+RvNsYExDowHgamRY/2BU6ye4wr0TjWVHuz1y6Ok/Y0fAvbFp56Fl5B+IrOIM0dHElEC0Awha/+vI35Xs93xmXE9D9gxcqwTgUccYo0xfkf81zTyksWxVSYxy+cONa7A2niX4LWEbUvMYmISmRKA8q1C2AG6f+T4lsevEcm3IscKNhEy94V+pBGjN4OMbEPCn7JVHXOBH+HbhbOOHmxGf93t2CZ9yOJFCUD5tqL+bzSbuCeYHuD8gPgGj78TfzLcWoSd7FKMeVhVu6bbGDgSqx1/HlYM6QNYdbpSvRN4gLS/9xPAh4j/lG4k1w8RV6djzwzxihMlAOXbg/q/0X8ix/apgNgGj2nYxTmmcdg+m/sC38m4h+ZOClwZ+F+G37anKbt87mTgG8BM0v7mfwe2SLB9Q7msg/iGG29NH654UQJQvn2p/xtdGDGuV+F3knx/xDgHeFYnTDG+HudriGodOr+DLr187lpYA6qUv/k87EmJZ9+LTvw9IGYlAA2mBKB8+1D/N7okUkyT8Gu88ptIMQ62A+nXf4eO6VhJ26aYBNxM9e0svXzum4E7SfvbPwN8gnitugfrJWyS8bYJYpRIlACU723U/43+FSkmjypi/cB9wBKRYhwwlThtUefO/7v/wh7Zx5hJnmJSpJeQBksvUnb53EWwyaMevTiqHr/bRd62TQJjLLHIkXRICUD5tqb+bzQH/8Y/bw2IZ8ELaIoZxGc7xduPLXU8F5v4tGDiMhZ70nAcfq9GnsLurJvgbsK39x7KLp+7KnAmfvtTp+M04vWO+H5AXHNpzv4pQ1ACUL7QZYCe7+hWAp4MjGdgHOkY13A+4hRrP/Z4e5MOP3cN/N4f71Nv05MK3UcXHKWWzx2wI/BvfLd5tDENawjmOXlyGcJWxdzsGItkoASgfGOwg7/u73SlUxy9+K2Vvob47zfXw++R7TlUn5XfCxzj8NlnV/zcHDbH/4JXavncAeOAT2NNnby3faTxH+CNDvH3YF0pQ2I5ySEOyUgJQDNcRtiB+maHGDzaEfdjJ8zYk74m4NcG9grsHXBdPwv8/OdJMxksROh75JFGieVzB1sBOAWfSphVxrmEVeH7qkMM7wz4fCmAEoBm+CZhB+qT2GPaunbDb5LbvgFxdMrjzrsfKxm8TGAsHk2SNg+MIbbJxC+neyW29LRUWxNWUKfOGJg8WeU9/ATgxw6fPZv4E3glMiUAzRBSDXBg3IG9m65qe/yq5/2yxudXtQs+d2N9wBucYtozMJaYrZG9/In4F7xSyucOZwxwIDZ5M/Z3MXjci813GelJ1RhsP7zd6TPPqvMFSVmUADRDL/Aw4Qft49hju04ep47H2hB73dndhf+KhAUti1+jn+86xtWDJWB1YznWMZZYtiHdY/ASyueOZCr26id17YnHgVOxJOQd2AX/IKzjn8f5Y/DY2e3bkmyUADTH1/E7eK/B6rIvNcTnrA18Bt+a6HOALX2+hmH1AH9wivd6/Nuc/jAgnnOcY4nlu6S94OUsn9uJTbFjLeV3kmLcSLlzMqSCHai/E/wjQ7xttjL+71n7sElW12LvqWO1yT00wvexoI87xTqdOEvQQko6XxUhnhh6sfa6KSfE9QEnAssl2L46eoD9SP9aIOZ4k+s3JNmELN+J3WhGFnYC+Q/+quNy4ve43wibEOUR74cjxbhLQExNS7bfSJ7yuQdT7oqJVbBELvfxGDpilReXDNaj/o7wSIZ4225lYAb5TwKdjqcJW33QiYnATU7x/jZinDsGxHVjxLhiWQSbQ5K6fO5NxC+fW9ckmv1KYDr1JhJLoVam/s4wD5WBzOFQ8p8IOh3viPQdDPYjp1gfYOg5EV7eHxBbU14BDGVV4AzS73unE698boip+E/ISzWasBpFKphI2EzVjdOH3HpjaUZf+xNifQGDvBmf983zsOWOMf0gIL5zI8eWQo7yuS8AX8R/Qmeo95D/+Kw6ToryTUh291F/pzggQ7xiM/VDWnjGHk8S924arALb407xfjNyrD2Erar4QeT4UslVPvd2rJhVKXqwZbG5j9NOx8WEVcOUgl1I/R3j1AzxitmJ+NXX6o5PRtxusNnmIfvt4HEtdmGKKbSD4kGR40tteeBk0pfP/V/Cyud6OpL8x2kn40qq98GQBjmW+jvH48Q/ecrw3otVR8t9khg85hBePnc0n3GK9XlgzcixjiesCFA/5ZcCrmsrbIVDyv3zRezim3v+UsiqkFTjd+T/niSy/QjbSTwazUh976KsJwFXxN1cNgVmOcW6X+RYAY4KjHEa5S5t8zAGm1zm1Wa603Ev8Pb4mzesV5B2e6uMeVjhsdjLd6UAqxK2s/wufciygB2x8qi5Txz9wPERt3MycJtTnKdFjHPADoSXg425NLEkU7GStamfaF2ELYdObYWa8cYed2H7rbRISNGOPmDD9CHLAl4B/IX8J5CvRtzGXzjFeC/xO5lNBR50iPXAyHGWZlPgatLus7OBo4nfq2KwNSNsR8iYBhyBrQyTlgntWX5G+pBlCGOAT+HXva/OiDVj/e1O8c0FXhcpxsHOcYq3H7gH+BVWTnhKgthzGyifG6s09XDjYWxeTYo696ETQ73GY8DXgKXjbq6ULKRK2cDYMXnUMpzlscmdM0l/QonRJnRl/GqpHxEhvgV9xCnWocZ04NfAqxNsR26LAcdgd+gp9+GrgE0ib9v3A+K7HmtVfQL1kqQnsYTy7dgkVWm5XsLqAfRjvQHacHfSJMthhVBSrjl+HN87qF7gUqfYrib+hLr1SFf+9jzgNZG3pwTrA38m3T7cjz0p+glx6llMJmzS4ykL/L11sOJCX8Mu7OdhrwMvw+Y4/BKbjLof9rpWk/tkId8g/KBJMbFK6tkY+BLwR+KXIn29Y9xfcorpWWyeREwTgBuc4q1yofo+7Ui+3wHcT9rv90nsiU6v43aELmP9gmMsIoA1efCYgfvp1IFLLUtid1bbYkWFdgK2xi6SIT0i+oHznWLcHL/Hv+9yimkk33OKtc64F9gs+hbmNxm70039eus64LUO8W9EeEOvrRziEFnIqYQfKH3Y4yhpttDXBnsFfv7i+LWUPTkwlk7sSvrKdguOF0lT26AEawK/J+332wf8D/ZqrY7VCC8K9RzdXRdCMlqP8HXL/diTBHWOaraTCD9RrV/zsydgfcc9Ttp3AovWjKNTywKPOsXrcZH6VNzNLcruhF9Uq45nse+4yoX4tcBDDp99eoXPFKnsTPwOlKNQtto+7d+BAAALz0lEQVRUexD++z+FvVaoYio2iclj/5sNbFHx86vqweZV5L7wLzja9CpuAvBl0i9/vRVr8zzSTPr1gRPxubHqx2b/i0SzGr6zmK8g/uQr8TcRn65ts7AiK6MV3unFJnmFrkYZPL4U8gV06BOO8XqOecDbArZrDLa09+vYssPjgc9S/6lOCqtgNUlSf9dPY42GDgM+hyVfP8eW63l+zj34TkYUGdIX8d1xp2MnY7WUbJaQHvYLjuew5Uh7Y2usVwLWxSYffh2/Er8D41Linyxfib13T33BqXLcbVBju3bClvUO9Tf7gD+Qp3xup3YAbib/9+89PuL5JYkMZzxwC/478MNYdpyy5KbUtxZ+jy5Tjqewu8GYJtKMi8z1VCv28hE6Ww2Uo3xuFeOw9/TPkv838Bh3oc6rktCriHd3MwMrWPFWbDmalOtk8p/8qo4UXd5+lHH7qo7DOtym7ai+FDhl+dw6lsdm7udeoRE6QlfVSOFKPIAOxKphxTQPuAmbUHM7VkluGrbOV6rrx77DW7AiJqFWxR7PN6VJyPHAhyJ/xpuBcynzmB3KdKxa3EMj/Hd6sScadR/tXw18HCuEVKLXYcucV8sdSA3nEDafQ6S208mf/WpUH3OBi/EpGvK5Arank3EbVigmphWwBCv3tlYdx42yXTs7fEbM8rkelsSOidy/RZXxALBMjC9DpBMTgcvJfyBo1Bt9dP4IeDhjsAYpubdlpDGX+JXweoELI8T+EHA28FOsrO+5WGU/z894EatXMByPUuADI0b5XC9TgGvJv792MmbiU31QJMhi+C9p0Ug7DlnoV61mFeL3EAgZPw/cvk581jHeOVhTl41H+LzNsIJMXhMxDx3hs05x3LaB4VU+19vqhJfjjT3mosf+UpAVsff0uQ8MjXpjDrbsLsTmlHninIvtnzFtitU08Ij3Lqq18301PtXubhnhM05y2rYFR9/8v123fG4sXyX/fjvcmIPKqUuBlgb+Rv4DRKPeOHHhn7SynUjX7rbTcZnDdo1kMn51Cq5n9KJIQ1kGn2Nvw2H+/uedtm+48SzwScqpDLoyZS5xnYZNMhUp0hSs21vuA0Wj+ngSn5nr21HW+urQOQ6j+YVTnPdhkwjrWo7w1zCfHOZvr+e0jaONm7FCPSW4kvz77uBxK2VXWhQBbFLYEZSZQWuMPJZe+OesZW3g3wVsTz+2Dj2WtzvFOAefFRm7BsZx1gh/O2V3vd8Qv1jTaEqp5TAPayU9Ke7mivjahWYuiWrz8DzpLopNvstdZOWtjts02CpYVUGPGD2fUvwlII67R/i7q5G2q+ELWInwCSFfRoBDOogx9rgIK7om0kgrAKeR/0DSGH3MIU450e2xYk65tuuACNs0Bptb4BHflfP/npf3BcQyl5H3gU3wbcjUybgDa+ub2pdqxhs6ZmPLPj2eCIkUYVuaURu9zeOSYX+9cL3AvuTZB74dYXu8Lg7P4F99bkXCnrqsPsrfXwqbuZ/6yc7vgTXrfSW1HB0Q6+yK//0XsCZKB6LCPtKlxgMfBO4k/UVAY/TxruF/OlfbYCsOUr0eut45/i2ofoIfbuzjHNuAkO92pNoDg70WW8ufch+dCXyNNO/Drw6I8zCsz8BuWEvo72Gvw34DnAD8GKu78B6sa2Qpqx9EohuL7fgqHlTOuJT0tet7sYvpJ7A7yquxNfBPDxoPYcvbbhgh9tFGH7ZO38Oi+CWw/+MU01CGa9fbydi6wuf0YlX9ngz4vDrjfuAdFeKsamnC6jrEnHgq0jU2Ar6DnehzXwTbOm6m/MeOWxK2jb9zisOrIt4dWDIRyz0BsW1e4/OWwur8V+0WGDr+DGxQI97RHBEYl97fi1TQi92lfQb4I/A8+S+M3T7mYmvYY16IvEzAHv+GbO9+gTEcEPj5A2M28JrAWEYyFpvQWTe+uh3/wCYJpu4LMRs4Blg8IO7BVsaePtWNZybN6Y4pDdGU1qKeVsHWk6+DtZ1dEis0NAWtia2rD3gMm5V/NvbIvSkuwioN1jUDq6JWZ7LjblgTHo93tV8Cvunwd4bzOmxlQV3LENYqugd7xfctwgobVfUo8AVeekpTx1hs/9gmII6rAv+9iIgs4KOE3y3OAt5P5wl1D/Ap/Cb9XUH8LnjHBsT3rGMci2Ez6b2+u07HNdSb8zEJn2JHR9T4bBERGcGyhL8GGBhXYktTh7sY9wBvxPdx9lxsxndMKxD2+uxvEWJaH7g4IKY6Yx7wMzqf2/Ia4B8On9sHrFXhuxERkQ55t6V9aP7fPAK70/8K8CviVLz7pf/XsZCTAmM8JmJse5G+iNB0rKTvlixc4GgR7JXQmfiVLQ959SIiIiPYhPylheuO3SJ8H4Pt6RDjWyLHuCiWYOX4/qdjXRuvw+a+xOhVkqqWhohIKzWxtPRc4ta0XxF4IjDGF7DWxin8v8BYSxw3E39+h4hIq62OzejPfcKvMu6L8k2YXnzesZ8eMcah/Mwh5pLGXr5fj4iIDOVT5D/hVxn/jPM1APA5pxhDlljWMRmr6Jf7t/EY59POpdoiIsn1YlXgcp/4Ox2xngBsRljJ2oFxQ6T4RrN/h/GVPJ7Ft422iIiMYmlsMlfuC0AnYxb+79enEFbzf/DI9fh6MjCtwxhLHH3A292/FRERGdX6pG9EU3fs6rztJzjFdblzXFV5FN/JNY7w/zpERKRTryRda+GQcarjNu/tGNdXyfv++tvDxFX6+Cl67y8ikt16WIe93BeFkcZcfKrErUpYs5qhRt3yuR68JjGmHD9CF38RkWIsCfyJ/BeH0S60C1akq2IC8brtDZTPnRoQXx2HO8SeaszFVqCIiEhheoAPUPa8gOOoVzCmF/hNgvieAg4ExtSIsQ6vuQyxx33AjpG+AxERcbIMdmGZQ/4Lx1Djt9gs/k5NBf6QOMbrga0rxFjX7QExer8KGWrMxd73LxbrCxAREX+rAt8FnsPnYvAUVvLV4289hK2DHz9C/IsAHwMedPrMqqMPa5a0wojfcn2bBMa3N9a18foI2z4POBtbaSIiIg21KLbW/WSq18y/D+vk92bsYr0Ovo1knsEusodgzWTeh71nPos0d7idjOeAzxA2f2Eovw6Ma735f6cH2A7rExHaMvpR4GhgTedtFalNM05FfPRi/QTWw+7ulsMex4/DjrOHsWWF9wHXzv+/F/Rb4G0pgi3MrcDHsSqMoXbBJm3WbaDzPPZqZO4C///J2Lv6XbBKiRsBE0f4O09jHQKvBc4D/oo9+RAREVnI5jS3LbHHOBN7vVLX6sBjgTGc3eFnjQFWAjbG+h3sBOwAbAAsHrANIiLSUieS/0Kcc0wHDsXmKVSxMfZUJfTzP1zxc0VERFwsgU3ky30hzj3uBPZh9GWDk7Gqgy86fOaLwFKjfJ5I19AcAJHy7AGcmzuIQtwNnI4VKvoP9m5+CWzS5K5Y0xyvR+6/xCZLioiIZHME+e/ChxsPFBCD9+jDJveJiIhk92PyXxgXHCdjj+XfR/iEu5LGbzv8TURERKIbC5xD/ovjwDiNl7+TXxL4IeVWRux0zMZm74uIiBRjDHAU+S+SxzL82vp1gQsLiLHu+MrwX7+IiEheH8TuVFNfHGcAH+ogvh7g3TRvBcONjFw2WUREJLtXAzeQ7uJ4LdUfjS8KfAuYlTDOuuNJYI2K2yciIpLFOODTVO89UGU8BnyU+uV0wZbpXRAxxtAxC7XhFRGRBloU+CJwL34XxTuBTzByjfuq3grc4xij18V/D8dtFBERSa4XK4hzHPXev98J/ATYhniFwSZidQ1m1IjPe0wDdo+0nSKNokqAIt2jB3unvQn27n4lYAVgwvz//AXsvfd9wL+xfvf3JYxvdeAY4C0JP3Owe+d/9j8zfb6IiEir7QLcRto7/1+iOv8iIiLZjQcOAZ4i7oX/VvTIX0REpDiLA0fiv6rhVuAArJqiiIiIFGoCsC9wHvVb+z4JnATsgOY3iYxKB4mIlGYSsD1W+OhV2MTGpeeP6fP/O9OwroT3AP/Aihb9DZiXOliRpvr/Jm4h3paDlB0AAAAASUVORK5CYII="/>
                                    </defs>
                                </svg>

                                <div class="is_agreement_active">
                                    Yes
                                </div>
                            </div>
                            <h4 class="item_price agreement_fee">$99</h4>
                        </div>
                    </div>
                    <div class="service-item">
                        <h3>Expedited Processing</h3>
                        <div class="service-description">
                            <div class="item-content">
                                <svg class="service-item_icon" width="26" height="26" viewBox="0 0 26 26" fill="none"
                                     xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <rect width="26" height="26" fill="url(#pattern0_78_253)"/>
                                    <defs>
                                        <pattern id="pattern0_78_253" patternContentUnits="objectBoundingBox" width="1"
                                                 height="1">
                                            <use xlink:href="#image0_78_253" transform="scale(0.00195312)"/>
                                        </pattern>
                                        <image id="image0_78_253" width="512" height="512"
                                               xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAACAASURBVHic7J13nF1Vtce/M5PeaUloAQKErnQU6aJ0QQRBFLAioE+lKwgEHk0BFVERARWsSAcLigjSe28h9BICBNJ7MvP+WDMvl5s7M/fce/ZZ+5zz+34+v0+Qx8vZa62999l3n73XakEIkTcGAqOBFYGRwAhgGDC0888RwPCK/z2o89910b/z33UxFOjT+c8zgUWd/zwXmNf5zwuBWRX/flqFplb97y69B7xd8XcIISKixbsBQogPMBIYC6wBrI696Ctf9ithL+w88S7wFvB6559vAm9U/LtJwBS31glRUrQAECJbWrEX+3rAmix52Xf9OditZb5MByYCz1dpIjDDsV1CFBYtAIQIQwuwGrA+sGHnnxtgL/6yvuQbZTIwAVsQPA08CjyGFgZCNIUWAEI0TyuwDrBFpzbHXvpDPBtVcDqAl7DFQJcewz4rCCHqQAsAIZKzOkte9lsAm2KH7YQ/k7GFwH3AXcD9LDm8KISoQAsAIXpnLLAzsA2wPTDGtzkiAYuxzwd3AXcDtwOveTZIiFjQAkCID9IKbIS96LcHtgVWcG2RSJuJ2GLgTuDfaEEgSooWAELY1bpdgd2AjwPL+DZHZMxzwM3AP4H/YnkOhCg8WgCIMtIGbAzsBeyJfcPXWBBgSYvuwnYG/g08gh04FKJwaNITZWF54FPA7tj3/OG+zRE54Q3gH8B1wK3AAt/mCJEeWgCIIrM89sLfH9gF6OvbHJFzpgG3AH8FrkW3C0TO0QJAFI0xwKexrf0dWJLjXog0mYvtCFwFXI+SEokcogWAKAIrAp8DDgI2c26LKB/zsAOEV2KLAR0iFLlACwCRVwZgh/gOQdv7Ih5mADcAV2A7BDpAKKJFCwCRJ1qBrYGDsV/8eauKJ8rF68AfgUuBF5zbIsRSaAEg8sAY4GvAocCqzm0RIikd2NXCy7EzAzovIIQQPdCKXdf7C7AQm0QlKe+ai30e2BghnNEOgIiN0dgv/a8Dazi3RYiQPAz8ClsQzHNuiyghWgCIWNgROBLYGx3oE+ViMnZO4GIs8ZAQQhSevsAXWJJuVZLKrIXANcBOCCFEQRkGfBt4Ff9JV5Ji1GPYFVclshLB0CcAkSWrA4dj3/dH+DZFiFzwMnABdlZACYaEELljQ+BPwCL8f1lJUh41GfgeWjgLIXLCRtgJZ734JSkdzcR2BFZBCCEi5EPY/f12/CdMSSqi5mO3BlZCCCEiYGP04pekLDUb2xEYhRAJ0SFAkQYfBs4GdvNuiBAlZSbwY+BHwHTntoicoAWAaIZVge8DXwHanNsihID3gQuxhYBqDoge0QJANMJywElY5r7+zm0RQizNO8BZwEXAAue2iEjRAkAkYRDwHeB4YLhzW8rOImySfweY1Pnn+9ivvhnYlvB0YFrnP89gSb75uXww9/wMYHHnPw9lSfKZQSxZ4PWv+N/LYNfRutMoYEVg+ZRsFY0zETgWuNG7ISI+tAAQ9dCKFeg5A506zoq3gJewRDBdeqPz37+LvfA73FpXHwOw/rIydm1tReyz0YpYoadx6F57VtwKHA084d0QEQ9aAIje2Ar4KbCld0MKyAzgWeCpzj+fw170L1Ge6nArAOtgi4G1O//s+md9XkqXxcBlwMnYAlKUHC0ARHeMxk72H4r6SbMsAp4BHur8s+uF/5pnoyKnFVgL2KRCGwMjPRtVEGYAZ2LXB+c7t0U4ooldVNMX+BZwCla0RySjA3geeBB74T8EPArM8WxUgVgZWwh0LQo+in1SEMl5CTgKnQ8QQgC7YNvQ3slN8qS5wH+B04FPoMORHqyF7VRdgu2sePeJvOk6lFpYiNIyCvgj/hNRHjQT+BeW/2Bb9J06RlYA9gbOAx7Avn1795vYNQMr0a18HkKUhBbgS8B7+E9AsaodeAS7U70dqs+eR5YHDgR+g12Z9O5TMeshYLPG3CyEyAtjsV+y3hNOjJoJ3AQchrZGi8hY7NfuLdhtC+/+FpsWY4WGdAZIiILRF6srPgf/iSYmvYylT90GbYOWiSHAfsCfsG1w734Yk17HPqUIIQrAZsDj+E8ssegZ7DqUtjwFWOKivYDfYlkVvftnLPo9lv1RCJFD+gCnYjnBvScTbz2NHeBbrymPiqLTF/gkthXelXWxzHoD2LUpjwohMmc97CS09wTiqfewiXybJn0pykkbsDNwBTAb//7sqSuwehFCiIhpwQ6xzcJ/0vDQXOwg3/7Yrzkh0mAENq7uwm6IePdzD70M7NisI4UQYVgduB3/icJDDwFfQ79SRHjWxc6QvI5/v89ai4HzsXMTQohI+CLlO808E8sCt3nz7hMiMW3APti12rLtCjwNfKh5FwohmmEI8Dv8J4Qs9QxwArBsCv4TIg3WAs6hXMm15mJ5FYQQDmwMTMB/IshCi4Fr0YE+ETeDsbMCj+E/ZrLSlSh5kBCZ8g1sBe49+ENrFnAh9gtLiDyxLXAD5fg88AL6FCdEcIYBf8Z/wIfWZGA8sFwqXhPCj7WACyj+gn0h9mlO5eaFCMCW2FUc74EeUhOxQkX9UvKZELGwKpZ2eib+4yykrkfnc4RIla9R7AImzwBfQPn4RfFZFjiZYmcafBWl2haiafpj24feAzqUngQOQS9+UT4GY6fo38Z/HIbQXOx6shCiAVYC7sF/IIfQY9gdan0vFGVnOHbeZTr+4zKEzkMLfCES8TFgEv6DN229il2T0oQgxAdZFlsIFDGh13+Bkal5SogCcxgwH/9Bm6bexU4I90/RT0IUkRWwpEJFuzXwGjoXIES39MGq13kP1DQ1AytJPCRFPwlRBtYArsJ/DKepmcB+aTpJiCIwHMsp7j1A09Ii4Jdo20+IZtkWK3blPabTUjtwOjr/IwQAKwOP4j8w09J9wFapekiIctOClbh+Ff/xnZb+gqoKipKzJfAW/oMxDb2BXenTyl6IMAzCztIUJZnQf4ARqXpIiJywLzAb/0HYrOZgp5cHpeodIUR3jAGuw3/sp6EnO+0RojQci1W48x58zeof2GElIUT27I2drveeB5rVm1h1UyEKTQtwLv4DrllNxrb7hRC+DMKuDS7Ef15oRjOBPVL2jRDR0AZchv9Aa0btwBXA8in7RgjRHB/GDuB6zxHNaBFweNqOEcKbQcBf8R9gzeg5YPu0HSOESI024H/If1rh76btGCG8GAHcif+galSLgLNRFj8h8sJqwK34zx3N6MzUvSJExowm33f8XwS2S90rQojQtGBpxWfhP480ql8ArWk7RogsWBN7gXoPokbUjpUh1tU+IfLNOOBe/OeURnUZKh4mcsbaWGIc78HTiF4BdkrdI0IIL1qBbwPz8J9fGtGVQN/UvSJEANbB7rV6D5pG9GtgaPouEUJEwIeAx/GfZxrRjSh1sIicdYFJ+A+WpJoOHBTAH0KIuBgA/Bz/OacR3QoMTt8lQjTPuuTzl/9DwFoB/CGEiJd9gPfxn3+S6i60CBCRkcdf/l0H/foF8IcQIn7GAPfgPxcl1S3oc4CIhPXIX0W/d1HaTSEE9MGKeeWtNsnNKDeJcGZd4B38B0MS3QesEsIZQojcshcwBf/5KYmuxRYwQmTOqtiVOe9BkERXAAMD+EIIkX9WAR7Af55KoqvQIkBkzEgsN753569X84CvBfGEEKJIDAAux3/OSqLLUcZAkREjyFd639eBjwTxhBCiqBxGvkoM/xotAkRghgL349/Z69VtwApBPCGEKDq7kK+rgueGcYMQdl3uZvw7eb26DKXPFEI0x5rAk/jPZ/XqqDBuEGWmD5aK0rtz16PFwPFh3CCEKCFDydf8d0AYN4iy8jP8O3Y9mgscGMgHQojy0kZ+5sH5wCfCuEGUje/i36Hr0SRgi0A+EEIIsKqCeUgaNB3YOJAPREk4EEuZ692Ze9PjWF4CIYQIzQHko7Twm8BqgXwgCs622Ja6dyfuTf8FhgfygRBC1OKjWEpx7/mvN01EN6FEQtYF3sO/8/am61BRDCGED+sBL+M/D/amu1DdAFEno4CX8O+0vekS7GCOEEJ4MRp4Av/5sDf9NpD9okD0B+7Fv7P2pjOBlkA+EEKIJCxLPmoIHBPKAaIY/Ab/TtqTFmOncIUQIiaGYeeRvOfInrQI2C2UA0S+OQr/DtqT2oEjglkvhBDNMQj4B/5zZU+aAWwQygF5QFvHS/NxLM1vrGUlFwNfwapeCVEPrdgVqLHYFu0QbIIe0vl/nwXM6fzzPezcy2vYQlOIRukH/AHYz7shPfAysCUwxbshwp/Vifs6yyLgkFDGi0LQB9gKOA64BniKxu5pz8Pyvl8DHItNkrEuikW8tBH/59RbUN8uPUOJu9DFQpTXWtRmeeBIbMt1JuH64Azg78DhwHKZWCaKQCtWotd7Du1JFwSzXkRPC3aP3rsTdqcFwGeCWS/ySH/gIOCvWP/w6JM3AZ9D96pF77RhnwO859KepN3VknIi/p2vOy0E9g1nusgZQ7HbH2/g3ze79DYwHlgmnNmiAPQBrsK/v3anWZT8UGAZ2Q57yXp3vlpqB74cznSRI5YFfogVNvHul91pOvADtBAQ3dMXuAH/vtqdJmCLbFECRhLXL6nql//h4UwXOaEV25p8G/8+Wa/ew3YplJ1S1KIf9unKu592pz+FM13EQivwT/w7W3c6PpzpIid8DHgM/77YqB4Ftk7dK6IIDARuxb+PdqfDwpkuYuAU/DtZdxofzmyRA/pgfWAR/n2xWS0CzsG2foWoZDBwN/59tJbmApuEM114shPxTq7nB7RbxM/qWMUy736Ytu4H1krPTaIgLAc8g3//rKWJqLx64RgFTMK/c9XSn1B2xjKzC3Ef8mtW04BPpOYtURRWwTJPevfPWroBzcmFoQXL+uTdqWrp39jhGFFOvozPff6stRDVsRBL8yFsgejdP2tJh7ELwnfw70y19BQwIqDdIl5agLPw74NZS2WsRTXb01ja6tCaDYwLaLfIgPWxgifenalabwJjAtot4uaH+PdBLyn9qqjms1jBM+++Wa2H0EHW3NIPu5Lk3YmqNR34cEC7RdyU8Zd/tc5r2ouiaByJf7+spVNCGi3CcQ7+nadaC7DSw6KcxHwNNWud1KQvRfH4Gf79stacvUVIo0X6bEOcV/50sKS8HIR//4tJ7cCBTXlUFI0+2MFo775ZrYnAkIB2ixQZDryMf6ep1oUhjRZR82HsUJF3H4xNc4BNm/CrKB7LYi9c776p+Tun/Ab/zlKtW7HVrSgfywIv4t8HY9XLwPINe1cUkfWJLzdGO5azQ0TMJ/HvKNV6AXsJiHJyPf59MHZd27B3RVHZg/huBryBsgRGyyDi+6U1A9gwpNEiavTdv34d0KCPRXE5Hv9+Wa2LglosGubH+HeOSi0G9gxqsYiZ5clXOV9vvYuV6haikt/h3zer5/VtglosErMV8Z36/9+gFovY+TP+fTBv+n1DnhZFZgDx5XN5rrNdIgL6YWl1vTtFpW4D2kIaLaJmS+zQkHc/zJvascW8EJWsTXyHAk8NarGom/H4d4ZKTQZWDGmwiJ5b8e+HedVtDfhbFJ8D8O+blZqP3VYQjqxPXIUkFmLFLUR52QX/fph37ZzY66IM/BL/vlmpO4HWoBaLHrkN/05QqRPCmitywL3498O8667EXhdloD/wMP79s1JfD2qx6JbYrljdhEqdlp1N8O+HRdFmCX0vysFawDT8+2eXpqFPvpkzFCup6x38Lk1C2cxEnFko86pLEvpelIfP4N8/K/W7sOaKas7FP+hdagd2D2uuyAHLoHz/aWoOyqApuudS/Pto5TsgN7kB8r5NvR7wONDXuyGdXAB8x7sRwp1vYOVMY2Qq8ACWlnpW578bgm2nboktXmLkCOzglxDVDMbyA6zt3ZBOHsHKBrd7N6To3Iz/iq9LTwMDw5orcsK/8O+PlZoB/BT4OD0XourT+d9cCMyMoN2V+kcP7RZia+JKAPfFoNYK9sc/yF2ah5V5FWI4di/Yu092AAuAi4HRDdixHHAO8VytnQ8Ma8AOUR7Oxr+fdmkyKhYUjEHAa/gHuUtHhTVX5IgD8e+PHdj42CQFezYDXo/Ang7gsynYI4pLP+JKFXxOWHPLy0n4B7dLt5H/sxQiPX6Lf5+8l8Z+9XfHisB9Edj16xRtEsVkA2Au/n21A9s9WyusueVjBeLJBT0bWDOsuaVnGWAVzM9jgVHEvRX8DL598mnC+Gd4BLY9FcCutBiG9c2xWF9dhXgPVBado/B/N3TphsC2NkUjv1z7Yh195c7//SZW6nRhWo3qhZ8C/5PRs3rjGOBH3o3IOW3Axth29drAuE6tjn3q6Ym3gReBlzr/fBz79Ts5UFt7YyiWDMQrJeh7WAGdFwP9/WtjOwFeV/IWAyNYcnsha0Zjh80+hL3kKxelPTEHeBl4HpjYqUeBxzCbRLq0Yql5t/ZuSCefAP7t3Yhm2Bg4H3iS2pXN2rGrRadggyMUaxHPAav7UJW/RvkwcCyWMTFEJq+JwOVYhsgsdwu2T9mOpDoovIl8wdG+DmDb8Cb+P8OAzwNXYNcm07ZlGjYGjiXsvFlGNiCed8WD5PQz8cdoLMf+TdiiIW2ubKAtITQP62CiflYDTiT7cs1zsW24g+l9R6FZPLceHyKbSaYVu+fsZWfoPBuDsL5yA9nfgHgK+B42VkTznI5fP63WfoFtTZV+wC9oro55O7Zdn1aSnpjqqp+ckk1FpwXYDfgPccTuPeAHwJhA9v7E0bZdAtlUi90C2tGbfhzIptWAHwLvO9rWpXasjPSugWwtC/2B5/CPZwd2fiYXO8bLAbeTnuF30Ps3snr4b4ptakYxZR6MlTasZndMV3IqtRDbTVonZbuvcrLnLbI9d9CGnb/wsPUvKduybuffGVMSmUo9gl1/zMXLI0K2I44fHx3AlwLb2jTLEGbF9DTNJUXYM0CbGlE79llEdM/H8T8tXq8WYDtdaSxQAe5xsuNXKbU/CV751+9Oqf2jgIuwxaB3P6xHTwE7pmR72fgV/vHrwA6C9g9sa8O0An8jnPH/pOc0pD3xQMB2JZHuIXfPKsRzRiOpZgBH09yv6Bb8klPt00S7G2XfJtrbjF6jubMObdjtndhSHderP7HkBpaoj+HAG/jHroN4brAtxXjCG396A+3aK4N21aP3gZENtL8MHEF+J9RK3UXygiKjgROACY7t9iiCsk4T7W1WEzCfJ012NA7bQfDuZ81qBvD1hLaXnVgydE7GihdFxUrYXdXQxs8nWWakFux0s3fQOrCXnPggI4Cr8Y9NmpoNHNmL3W3YwvR64thCHtJLe0MwrIn2pqWFWAz2ovdv5N8kmzkuS/0F5ZuvlxbiOUd2UmBbE/NzsjP+NwnaFcuv/4fQIZxqtsQS8HjHJmQ/rf5eNxy7s/1KBO2rlEfiodYm2htCr2CxqX4h9ieO9Myh9CJWelb0zibEcdhzKvbjKQqGkG3u5PnUt3XXgiVQ8A7WYiy7mljCPsSTbzuk7sXy4I/FCntMjaBNteSFt921NBOrgLgeFrt7I2hTaM1DhZLqJZYDgSeGNrRePk32xp9SR7tiOfl/aR1tLRNHEMcqOitNxRaB3u3oSV54292TFhPvgi2EFgGH9xwugZ3jiqFfvE34xGR1cRnZG/8mPd+lj+XX/yzsV4QwTsA/JtLS8sLbbmlpqQRt78RSLCiKGwFeZT572rLaw6lN1RpfrxNLwHj84yHVlhfedku1dWpPQRP0BZ7FP06vEEFSudfxMf6/PbTpDqc2VWoyVt1N2JUj73hI3csLb7ul7hXFr8uI2Rn/GHUAh4Q2tDeyLnhRqVoVsLZwbE+lvpbUkQVlb8r1zT+P8sLbbql7LSZnBWgc+Bf+cXoGv/LhgBVI8TL+4hrtiSGb3DM0nrWwSGyJ7wJRqk9eeNst9ay5wObdRk9sThx1Aj4d2tCeyLo8a6VmA8tWtGV14kisoipcdk+1yPf8iyQvvO2WetcLKFlQT1yLf4weCG5lN7RiOZK9GAR8seJ/H4X/L+/bgJud2xADvwDW8G6E6JUZjs+e5fhsUR9rApd4NyJivo99LvFkC6yImgun4b9CbcUqEcaQT3675txZCI7EPw5SfXqhmxhmgXaI8iPVDuiey/GPz43BreyGGA7d7Q58L4J2/KtJXxaBlYljISbVp9tqhzETYsmtLvWu6SinSXesgWWo9YzPYizjaKa0AZOAA4AVsn54BaOwzH/e1+4OxveTSAxciuXMFvngd/gtAtYGtnV6tkhGfywF+7XeDYmQadg7aEvHNrRg599u8Xj4/+C/QvXWP5r2Yv6J5W6sVL92rBnJbPh4D+2S4lM7sEOtQApGY4fSPePzHk7pgYdiW0TeHdRTZS/404Zdf/SOg1S/XsC3SmUbOgeQNz2B873ziPkx/vH5anArK+jqCDOxrcSy8lfgfu9GOLMfVkFN5Ief4nuCeTHwM8fni+RshFXzFEtzPrDAuQ3f9nrw+sSRFMFDqqcND+MfB6l+vQQMrhnJbBmE7UR4+0OqX49g35zF0lyKf3zcztXcWmcDi6T/JPBPG3ZKfktgL+yb+QZY0pw8E0vxJak+tWN9LxZ2pLw/HvKqXWpGUozDP/X5lcGt7IZP19nAImm3XnzSH7slcT12WrTW39GOrapPw7bY8kYZF3551im1w+jKqfj7RapfuvLcPX/BNzYLgJWCW1mDNuDVhI3Ns56g+62wMcBZwDsJ/8524Grsk0oeWA37lusdC6k+XVg7jFFwEf7+kerTYmw3UyzNJvjvaJ0c3MpuiCEhT1Y6uMr2FmAn4Bqa3wZahAUx9m9tJ+Efh940C/vO/CZx1Irw0CLgeOLuTy3Ad/HfQvXSQqyPvoT1We/29Kbja4dRYNfCPWPzAk5jfQWsipR35wyt14C+nTYPAY4Ang7wnOvwT3DUE8/hH4tqPQr8L3bWovqgWwt2Z3d/4ApgSgTtDa1nsIVpXvg45bhSOgXrg5/FsuxVT9iDgY9gffnRCNpbrScR3bEd/vFxOwz42zoal3cdBawFnEP4ksi3A/0S+D8rNsY/DpW6E9gmoQ0DgWMp5kLgSeBw/AtkNUIfbFHtWW00lKZgfW5gQp9sA9wVQfsrlZdPlR48gG9sLg1vYm1iqA8QWveQ7XeeXyaKQDYcg38cOrAkVJ9p0pbhFGPh+hRwNrY4KwobYzYVYTHwG5ovr7s/8SRe+1aTthSZQ/GNzQycMgMC3FdHA6Vk+nyiCITH+ztXB/ata4MUbTqMfJ0TWIT9KjwBWDdFP8TK6liMbsK/AEvSOJ2Qoh/GAc9GYNcNKdpUNAaQ/BB42qo+p5YZB9fZQKl+TcbOG8RAP/wPKj0NLB/Atn2I++WyCLgZOIjmf03mmRGYD24m7oOD8wmTPW85wpw7SqLp5PMTU1achW98/h3exNr0B96uo4FSMh2TJAgB2QpfP7wLrBrQvk8R3yLgOeyWja5fLc0qwInABPzjVKn5wN4B7R6DjQVPGzcLaF/eGYPvjuLizja4cEYdDZSSaSJxXOX6Cr5+CDmpdhHDImAOcAmwdWBbi8THsANQc/CNXeiXfxfeCdgODW9irrkG3/h8P7yJtVmVfH1PzYs2SRKEQJyPn/13ZmBfF7sB8wLZ0ZPewW6YrBjexMKyPPbd/U2yj98Csi2ac3sAG+rVOeHNyzU74RebDpx/NF5dRwOlZDo6UQTCcDN+9m+fgX2VZLkIeAGr6OV2ereA9AcOIbvcAlm//MGuCHqNx5sysC/PtOB/g8XtM82OdTZQql8/TxSBMLyIj+1eZZdDfw54AntpqNZ6OFqx7fInCRfHrLb9a/FQnW1MW89nYVzO+SY+senS2eFN7J4nummU1JiuS+b+IMzAx3a3HNdYBbTuCjo1qlewX6d68WdHK/bd+hXSjeU0fKvkja/Rpiw0NQPb8s6y+HxK7NKL4U3snsO7aZTUmO5O5v7U6Yef7ZtmYF9PbIB9U2vWjnexbJL9s22+qKA/FoM0TtE/j39WPK8EbO3oKmA9eH8O/3B4E2szCHi/jgZK9envydyfOqPxsbudJfUXPBmAldRt5JT5+1jZ52GZt1p0xzAsJo3MUbOxXakBmbd6afrjV4VuhQzsyzt74fveOD28id3zk24aJSXXZQl9nzbr4mP3u1kYl4CRWE733g74LMbygh9D3IWdys5QLJ4P0nuJ66eweI50aWn3hK5L0p3GZWFczukDvIXfe+O5tA1KcrVgXGcDYrjDnndOw773ebEuloY0a54GNnR4bj2MxJIjrYlVcRsATMKqRj5AfIsX0TMrYPEcg13FnIvt+LyIHUR9x69pPfI0Pp8ixmGfxkTPnIdvMrcNsNswLnheHSuSPpbU8SmzJj52ux5kESIHvILP2FwtA9uKwAb4vjtOSdOYpCeXY7i+lnfexwotebLQ6blKiiNE97QAo5ye7TUn5I2ngYcdn99s1dQPkHQB8DfgpTQbUEKuxL5PerLA6bkDses0QoilWQ6/w4haANTPbx2f/SFg7bT+sqQLgHbirGufF+bhnNChk/fwW4Ts4PRcIWJnJ6fnLsR2JkV9XIXvj7jd0/qLGklechl2oEYk5+fA696NwAb8207P3sPpuULEjtfYmIT/rmSeeBvfXC67Oj4bsEpd3gfp8qbHsdPlsXAfPn54B/sUIIRYwiD8ygJ7JybLI9/C710yh5Tm0EbTl/4sjYeXiPeBfbGkI7HwhtNzVwC+4fRsIWLlm1j1Qw+85oI801Ui2IOBwHZp/EWNLgAeQ6vGenkL27KJ7Qrc047P/i7KpCdEF8OB4x2f/5Tjs/PKm/je5krlM0AzBUy0C9A7TwIfxTKTxYZnm5YDznV8vhAxcR42Jrx4yPHZeeYax2d7Fq0CLKf7JPy/rceoucCZxP2t26seQKW+HNxKIeLmK/iPQ69PD3lndfxqN3R0Pt+V8fh33pg0FVvNr9SEX45WaAAAIABJREFUT7PkNXz9tRCr7y5EGdkHGwOeY1B5XZrjQfxi9/UM7OuRlbCkMt4vXm89DhyGneTNE5fj77sFaBEgysfu+NaX79IloQ0tOCfiF7vrMrCvV/6Mfyf2enFdSUqnMZ34DP5+7PKlFgGiLMTy8u8APhXY1qKzKX6xm4FVKHRlG/w7cZaaDJyDVRnLO0Ow8wrePu3AFgH7hDVXCHdievnPIX+7lrHRgu9ZuA+HN7F3HsW/M4fWPcBBQL+UfBYLf8Pft13SIkAUmZhe/h3AjWHNLQ2en1IPysC+Xvkq/p05hOYCv8a2eYrKQfj7uVJaBIgiEtvLvwM4IKjF5eFz+MXw6Azs65WBwBT8O3RaehO74VCG6zH9sdzW3j6v1HwiuOcqRErsivVp73FVqbco3m6mF8tjtRQ84vitDOyri3Px79TN6i5gfyI4WJExZ+Hv+2rNADYKabQQGbA+dj3YezxV6/SQRpeQ+/GJYzS5VMbitwpqRtOBnwLrpO+S3LA6sAj/WFRrInEnUxKiJwZiKcC9x1G1FlGMQ8wxMR6fWO6bgW11cxP+nbteTQBOAJYJ4on8cQX+MamlU0MaLURAxuM/fmrp1wFtLisfxSeWK2dhXL3sin/n7kmLgGuBj2PXN8QSxhLfd8oO7KrSyIB2CxGCUVjf9R4/1ZpHBClkC0gbdq4iy1g+n4llCWjBqsx5d/JqvQOcjba9euNn+Meqlo4NabQQATgB/3FTSz8JaXTJuYBsY3lBNmYlY2/8O3mXHgQOBQYEtbg4jAZm4h+3anmWLhaiEZ7Ff9xUawa2MyHCsDnZxXIRsGY2ZiXnTvw6+XzgL8DOwa0sJt/Af6KqJU1cIi+siP94qaXDQxotAPvEnEUs/5yVQY2wDtlffXkdOAl9L26WFuAW/Cerau0V0mghUmQf/MdLtW5D556yYBzhEz5NA9bIyqBG+QTZlLp8CDgE6JuNWaVgDeL7FPDtoBYLkR5H4z9eKjUbWCuoxaKSQwkbzyjS/9bDQYQpNjMTuAjYMDtTSsfh+E9clfp+WHOFSI1T8B8vlTosrLmiBr8gTCx/mKURabAJ8ArpGD8RO127bJYGlJhL8J+8uqTMZSIvnIH/eOnSxYFtFbVpIf08EOdkaUCaLI9dP2nk28hiLMHQrugbVtb0Bf6L/yTWgQ4wifwQy0Hae7BaH8KPr2HZZpuJ4/vYZ4XcMwb4MfWlx3wFu7s/1qOh4v8ZTRy5zPcMbagQKfEp/MfLVGzsCn9WxW6mJU2VvxjL0BrsYLvnL+r1gS2wVIajsF+bU7DFwQPYPVrhz1pY2uRWxza0Y1er3nFsgxD1sgIwGf8xsz42dkUcjAWOwEpDr9/Df/cidp3wEuyzdzC0pS5640Lgm85teBDY0rkNQiThYWBT5zb8FN2eiZXRwHqdfw7F0ka/AzyGfuiISBhBHNcBjwltqBApcxz+42YGMDy0oUKIYhLDJPY+tkIWIk8Mxfqu9/jR4lkIkZg+pHd9sxmdFthOIUJxGv7j52WsUp0QQtTNXvhPXu8Cw0IbKkQghgJv4z+O9ghtqBCiWFyP/8SlA0wi7xyF/zi6NriVQojCMApYgO+k9QpKYiLyTz/qy3sSUguxa7RCfADPe6oiXr6Ef3Glk7HSzkLkmQX4p7HuAxzs3AYhRE54Ft9fLE+gxakoDq3Y/W7PMTUB5X0RVahDlJdhWKKSTYHVsIyMK2LpmldxbBfAp7EzCKJx+gLrAutgNcrXwbI6DgUGA8t0/glWLnYqMKtTL2AvjAnA88Bz2DayaJx9gWuc2/AG8BrwFvAm8CrwCJa0aKZju4QQgRkBHAhcjv3CT5qXOis9h379N0IbsAFW+vUvwDTSi8ls4BasEuc2+H8eyiOt2GLKe3zV0mLgGWxuOAAlDxKiECyHpfG9Bf9DffXq60E8UVw2wMqETia7GL2HlZndJgP7isQR+I+vejQf+BdW1VCl14XIGZthE/Rs/CeTJHobGBjAH0VjKHA08BT+MXsSu+o2JKjFxWAA2S7U0tA8bEdp6wD+EEKkyC7AvfhPGo3q1PRdUiiGYdvw7+Efq2pNx3Yi9IuxZ8bjH6tGdQ/widQ9IoRoii2BW/GfIJrRbGD5tB1TEAYBZ2DFXbzj1JumY9feBgXxRP5ZAav85h2nZnQXsG3ajhFCJGMUcCX+E0IauiRl3xSFvbB87t7xSao3gEMC+KMIXIp/fJpVO/BHbEEjhMiY/bFc+d4TQVr6aLruyT2rAjfhH5dmdWOnLWIJH8M/LmnpfezmiRAiA5YDbsB/4Kep51L1UP7ZE5iCf1zS0hRUkKaSFizHgndc0tR16PyHEEH5MPAS/oM9bX03TSflmD7YIbFYczQ0o3bgAiw3voCT8I9J2noN2DxNJwkhjAPJ37W+erQYbRGD/Xq6C/94hNYdWBbCsrMysAj/eKStuejshxCpcgr+AzuU/pGin/LKisDj+MciKz2NFn0A/8Q/FiHUju1wCCGa5Gz8B3RIHZSeq3LJulhOdu84ZK03gY1S8F+e+Tz+cQipM9NzlRDlogX4Ef6DOKQWYDUKysp6FOsmR1K9iy2Ayspw8pOiu1H9HBWdEyIxZ+E/eEPr36l5K3+sDLyCfwy89TpWgbKs5D2BVz3SToAQCfgK/oM2C30rLYfljBGU65t/b3qa8l4h+w7+/s9Ch6flMCGKzC5Y7XXvAZuF1kjJZ3miL+U47Z9Ud1DOMsNj8fd9FlqA6ggI0SNrYrnUvQdrFnoqJZ/ljfPw932s+kETfs0zT+Pv+yw0lXIu+oXolT7ku5JfUp2djttyxe7YFSlv38eqdmDvhr2bX4p+06dSd2FznRCigv/Ff3BmqY3TcVtuWJVipfcNpXeBVRr0cV7ZFH+/Z6lT03GbEMXgYxQzK1h3ejIdt+WKG/H3e150fYM+zjNl+QzQgZ1x2iodtwmRb9qAx/AflFmqbCeC98Hf53nTXg15Or98A3+fZ6mHgNZUPCdEjjkS/8GYpZ6lXN8AB1HMAk6h9SowuAF/55U+2MFYb79nqa+l4jkhcsqylCsT3CJgp1Q8lx/OwN/vedVpDfg7z3yccn0KfJtyZwIVJeeH+A/CLHV8Om7LDcsCM/D3e141nfJVDvwe/n7PUmel4zYh8sUIynPnvwO4kPLlBB+Pv9/zrpOTOj3ntAAX4e/3rDQNGJaK54TIEd/Ff/BloXasnHHZGEy5Pu+E0nvA0IS+LwKnUp6cEcel5DMhckF/YBL+Ay+0XgR2TslneeNo/P1fFB2V0PdFYVtgAv7+D623gAEp+UyI6Pkc/oMupF7ACv0MTMthOeQJ/ONQFJU1bTTYLZLvYItp7ziE1AFpOUzUT9m+ycbCX4E9vBuRErOAycAbWEGX2zr/bPdslDObYfecRXpsguXLKCutwA7AjtjOwCrAKGCIY5vS5EbKmQZalIzlscpY3ivuar0FXIwNwrUozsTiwU/wj2e1FmELs2OAjwAjsep7fTv/+SPAscCdxHkV7UeJIiAqGQasDXwauARbsHvHs1rzKW9JaFEijsB/sFXqIeCTKCtXWrRh95u949qlOViVvZEJbBiJXVGdG0H7u/QW6qNp0QrsCjyCf1wrdVhIo4WIgZvxH2gdWGGaz6HPQGmzOf6x7dJVWBGiRhkDXBuBHV3apAlbxNK0Al8A3sc/th3Yp1EhCksf4kgMMwFYJ7CtZeUE/OPbjuUgSGNx19Jp0+II7DomBXvE0qxJHMWIpmE7aEIUkq3wH2T3osQbIfkHvvFdDBwYwK6D8L+X/rcAdgljOHA//vPT5qENFcKL4/EdXG8CKwe3srz0xW5FeMb4xID2nexs2wzMxyIMo4HX8Y2xdnlEYbkGv4G1ANg0vImlZiN8J8+rCHumowX/MwEbBLRP2C/whfj2YSEKiWe5zwszsK/s7IdffOfS3IG/elkZu1ngZeenw5tYejxrETyegX1CZE4rfteqZmJJQ0RYTsJv4jwnA/u6ODegHb3puxnYV3ZG4ndYeQ667pkZcnR2rIZfvuvfYnfTRVjGOT13MdkmyjkPv0yPur0SnneA3zk9eyDZ7GQJtADIkjUdn32947PLxFin596DTdpZ8TZ2m8QDLx+XDc85w3OuLBVaAGTHMk7PnYalgBXhGeH0XI/J+gaHZ4JdVxPhuR2Y6vRsr3FUOrQAyA6v3Pr3Y6d6RXi86tbfU5JngnJYZMVCLFWwB17jqHRoAZAdg52e+5LTc8uI1yLvRYdnvuDwTNDLIUsU44KjBUB2eHXqaU7PLSNeMZ7u8EyvfqWXQ3Z4fQJQJdKM0AJACCGEKCFaAGTHTKfn6kBNdpQpxl79ysvHZcTr4PIsp+eWDi0AsmO203N1pSY7vCYuj6txazk8E7QAyBLFuOBoAZAdXi+HrYB+Ts8uG14T1zYleSZYhjoRnr7AZk7P1gIgI7QAyA6vAzXDge2cnl02vA7G7e3wzE85PBN8DjyWkR3x+8yjg8sZoQVAdnhdqQHYx/HZZcLryuVHsfztWTEa+EiGz6tE11qzwXPO8JwrS4UWANnxGjDP6dmHYpO2CMvzTs9tA47N8HnH4Td3THB6bplYETjE6dlzgTecni1EUDzLAf8iA/vKjnc54DHhTWR1bCHrZafKAYfnV/jFV+WARWG5Br+BtQDYPLyJpWZD/OLbAVwLtAS0rwWrO+Bp4/oB7ROwJZYG2Cu+V4U3UQgfjsN38pwErBzcyvLSFzvB7BnjkwPad6qzbTMwH4swrAi8jm+Mjw5upRBObInv4OrAigMpOVA4/oFvfNuBzwWw6/Odf7enbX8LYJcwRmBzg/f85HX1UIjg9MGuMXkPsonAeoFtLSvH4x/fduAc0jmo1wKcACyOwK5jUrBHLM1awDP4x3cadqBViMLyd/wHWgfwPnbSVzdB0mUz/GPbpWtp7mDgavh/86/UJk3YIpamFZsDpuIf2w7gprDmCuHP4fgPtEo9BuyOVt5p0QZMxj+uXZoLnAuMSmDDaOA8fE/7V2sSWqymRRs25h/DP66V+mpIo4WIgeWwE/neg61a7wCXYVfZ1kHnBJrhx/jHs1qLgbuwg6hbYwuCfkD/zn/+GPb54m7i2O6v1vmJIiAqGY6N6f2wMf4O/vGs1jz8ig+VlpBXhkT33Ajs5d2IlJgNTAFexV4wt3VqsWejnNkUeNi7EQVjY8p9R7wN2AHYCavDsCqW/XGwY5vS5AaUsVSUhM/hv+IOqZexA1tFmZwa4Qn841AUPZXQ90ViMDaWXsY/DiF1QFoOEyJ2+gNv4j/oQutl4JMp+SxvHIW//4ui7yT0fVHYDksv7e3/0HoDVSwVJeME/AdeFmoHTkvJZ3liMPAu/v7Pu6YAQxP6vgichn/ehayUZR0LIaJgOHHkBMhKv6R8Z05Oxd/vedf3E3s937Tgm4s/a02lnAs8IfgB/gMwS52Yjttyw3AsuYm33/Oq6ZTvNspJ+Ps9S52ZjtuEyB/LUK5t4sXAzql4Lj+cjr/f86pTG/B3nvkEcV7BDKW3sUWyEKXl6/gPxCz1HOUq6DIQeAl/v+dNrwCDkrs7t/QBnsbf71nqy6l4Togc0wY8gv9gzFJHpuK5/LA3/j7Pm/ZsyNP55Zv4+zxLPYgyOwoBWGa2RfgPyqz0dDpuyxU34u/3vOi6Bn2cZ8r0638hVhlVCNFJ2b4Vl62wy6rYlTZvv8eud4FVGvRxXtkUf79nqZPTcZsQxaEPcA/+gzMrnZ2O23LF7pTnbncjagc+1bB388vZ+Ps+K92JCo8JUZOxlOfaWFnTu/4Qf9/HqjIuCqE82//vYyWmhRDdsAMwH//BmoXWSsdluaIvcAf+vo9Nt2O7YGVjTfx9n4UWUL4rwEI0xJfxH7BZqKw53ocTXy12Tz0FLNuUR/PL0fj7Pwt9PS2HCVEGzsR/0IbWral5K3+sRPErvNWj14ExTfoyz/wH/xiE1hmpeUuIktACnI//4A2pBZQv1Wsl61KuTJDVerfTB2VlGexKnHccQupnlK8GiBCpUfSdgIPSc1UuWRd4Ff84ZK03gY1S8F+eORj/OITU6em5SojyciLFvT52c4p+yisrAo/jH4us9DSWF6Hs3IJ/LEKoHSt3LoRIic8Cs/Af3GlrMXoZgB2CK8PtgNuxre+yswrFzP45E9g/RT8JITr5EPAi/oM8bX0vTSflmD7AeIpZEa4duIByFYLqie/jH5O09QL6rCNEUJYFrsV/sKepCeigUCU7A5Pxj0taehfLgiiMFuB5/OOSpq5GOztCZMb+wDv4D/y0tHW67sk9qwA34B+XZnU95cvt3xvb4h+XtPQ2cEi67hFC1MMKwO8pxgHBS1P2TVHYE3gJ//gk1YvAHgH8UQQuwz8+zaoduAJYLmXfCCESshHwF/wnhWY0FxiVtmMKwkDsbMB0/OPUm6YBp3a2WSzNSGAO/nFqRrcAm6XtGCFEc3wcuAv/CaJRjU/dI8ViKPBt4C38Y1WtKVj89B24Z07DP1aN6k5gp/RdIoRIk/WwE9d5uzY4BRgcwB9FYwhwFPAE/jF7AqvpMCSoxcVgEPnL/DgX2+rfOIA/hBABGQEcjiXbmYf/ZFKPDg/iieKyAXAO2e4KTAEuBrbJwL4icST+46sezQP+gRXwGR7EE0KITBmKJRP6NVZ9LdYkJBOA1kA+KDpjgcOw8yBTSS8ms7Dvvidg334Vn+S0ARPxH1+1tAh4EjucuD82V4gSoLvX5WUIsAmwKbA6sHKnxuB/bWtf4DrnNuSdPsA6nRrX+efaWNyHYrtDXdv2s7DDezM7NRG7p/48tiCbgL0kROPsB1zl3IbXgdeASVgthpeBR4FHgNmO7RJCRMSz+P4ieRL7xSREEWjDdt28d9b0g098AG3liVpc7vz8DYEvOLdBiLQ4FDur4UlX7gEhhOiRUcACfH+xvAL0D2ynEKEZgH+554VYxUkhhKiL6/GdtDqwq25C5Jlj8B9H1wa3UghRKPbCf+J6F11DEvllOHZl0nscKSWzECIRfbBteO/J67TAdgoRitPxHz8vowO1oht0KlT0xLHAuc5tmA6s1vmnEHlhGPbtf4RzO44BfuTcBgEfAj4CrMSSa9aTsIqu9wEPYws2IaJhBHYv3PtXzLGhDRUiZY7Hf9zMQJ/QPFkfOB+rjNlbrCZh2TXHubQ0I1YCdgW+1Kn9sQI2KikZLz/FfyJ7MLiVQqTLI/iPm58Et1JU04YlMruVxsq0LwQuwd6VhWA9el8FtWNFRc7FtntFPKyBf9rgxVgZVSHywGgam/zTHjNrhjZU/D8rAN/DMi2mEb+3gW0ztSBlRgN/JPlAWIBVn1o98xaLWqxIunnlG9WeoQ0VIiU+hf94mYrNwSIsW2CJ00IUW1sAfDk7U9LjqzT/0pgGHJB1w8UH6Avcgf9k1gEcEdhWIdLif/AfLx3APSiZVgj6AwcD9xM+hovI2Y+fM0jXAfqO5cel+E9iXTo9sK1CpMWZ+I+XLl0S2NYysSoW27fJNoYzsPTo0XMBYRxwVpZGCCC+2uXfD2uuEKlxCv7jpVKHhzW38OwIXIMd0POK4X1Efm3/C4R1gLaAs2MsViLWe+Kq1LeDWixEehyF/3ip1GysFLSonyHYO8e7imOl9gtqcROsiW1ThDR+JrYFI8LSCvwX/85erVx9BxOlJoZDgNW6G1V/rYdx2E72NPxjVq0JRBrDq8nGAddkZVCJieUAU7V0DVDkhZH4j5daOjKk0TmmFdgZuAn/65u9KbofQutgd06zcsAW2ZhVSlYkjsx/1XoypNFCBOAZ/MdNtWZgpb6FMRz7tPgS/rGpV/8I4okm+AXZOuBX2ZhVSrKOZb06JqTRQgQghlTAtXRhSKNzwibYDac5+McjqdqJLF3wy2TrgHdQdasQjMUST3h38GrNRtv/In+MIs4XzHwsu2fZ6AccCNyFfwyaVTRX41fFxwEfycK4kvEH/Dt2Len6n8gr4/EfP7V0eUCbY2M0cALppeiNQTOwapPu7I+PA8ZnYFuZWINsz3HUqwnAgIB2CxGSgcBE/MdRtRZR/Jor2wB/Js5dzTQURW6Hr+Fj/L1ZGFcizsG/Q1crN9mvhOiB9Yijlka1zgxptBP9gUOAR/H3b2g9TQSJgY7Gx/hFqIRwWvQn+9SWvWk+8MmQRguRIbtgfdp7XFVqMvZdvAiMxX7ETMHfr1lqxzSc1wzH4Wf8gRnYVwY+j39HrtR8YJ+gFguRPbsTpmJcM/pcUIvD0gLsit3dj/HzZRa6umkvNsnB+Bn/mwzsKwN/x78jd0kvf1FkYlsE3BTW3CAMB74DPI+//7y1EOfsuBvXaFRWmkQE30ByzhBgLv4duQM7rKOXvyg6MS0C5gCDw5qbGmtieUpiTFTmqTOacWqz9CF8DYCetHF4EwvNZ/DvwB3o5S/KxW7EswiIfdwNx5IXeVbii1lvY+e43LiuRqOy0nczsK/IXIF/B9bLX5SRWBYBl4U2tAnGYVeBvX0Uu77QqIPT4PBuGpWF7s/AviLjnRxjIXr5i/KyN/6/bF8KbmVj7AC8h//LNQ+6rzEXp8PqNRqUldopfkKLUIzCv+MeGtxKIeLmS/iPw+WDW5mMdYizHG/Mci2S91w3jcpCR2VgXxHZE98Oe1F4E4XIBRfjOxZ3C29i3QwlzkqKseu3Dfg6NX5So0FZ6a4M7Csip+EXs3eJJJe1EBEwFN9kXKeEN7FuLsL/ZZpHzQVWSOrs1qT/D93wz5T+nkbYGue7kDllfcdnn43dHhFC2NW2cx2fv4HjsytZHfiydyNyygDgq14PH4jvffJvhjexcNyHT6zeRgV+hKhmIFbq3GNM3p2BffXwa/x/SedZrwJtSRye1g7AXOCOlP6uRviM47Pzyhin596IXX8SQixhLvBXp2fHsIPaF/i0dyNyzhjgU0n+H9JaAIDvZ4DtgBUdn583+gIjnZ79N6fnChE7XmNjJRL+cgzA9sAI5zYUgW8k+Y/TXAB4TuytaPWYhOXwG/C3Oz1XiNi53em5bcCyTs/uYifn5xeFnUhwvivNBcAE4KkU/76kHOr47LzR1+m5s7H7vUKIpXkP+xTggdec0IXXJ8mi0QIcWe9/nOYCAOCalP++JGwJbOT4/DzhNdgnOz1XiLzwttNzvRcA+oSbHodiNRR6pU/KD74aODXlvzMJXwBOcHx+XvAa7DEf/lsJ2Lzzz9HYtug0YCLwMPCmX9NEA4wCtsIyhY7GSk3PAl4AHiDexegcp+f2c3puF3mpSpgHhgCHYEWUMudZ/K5BvEX6i5oisg4+8Xk3C+MSsBxwMvAQlla6p7Y/hhWf8v5WKrpnGHA8tmDrLZ7Pdv63o1xa2j1e+e/HZWFcD1yPj91F1fPY54DMOaOBxqapmNJaxopXHYB2/H9pgK2QTwamk9yG6cD/UucWm8iE4cDpwFSSx3MOtms5MPNWL80Ael+4hFLiLHIpowyA6esTiSKQEps02Ni0dGV4E3NPX/wmms0ysK8nNgdepHk7pgBHo6RGngzAYjCF5uP5ArBhts1fii3xGZPt+O+cHo3ve6OIuiFRBFLkhTobGEJzgWXCm5h7Gvn1m4ZOzcK4btgDu4mQpj2vAl/E/x51mWjDfP4q6cZyOrBrdmYshVd9jvezMK4XNsbvnVFULcLSK2fODxI2NG0dEd7E3OO1SHswC+NqsDd2ECyUXU8B+5L+zRqxhFYs6+dThIvjAmCfrAyq4uE625i2JmRhXB14VpUtqn6QKAIpsUWDjU1LT4Q3Mff8Hb/47BDevA+wO3YDIQvbXgS+DQzKxLJy0B871ZzVAeMFZJ9YbNuU2t6IbszAvnr4Nn4+KKqm4HC+pQXfzwAdWGpJ0T3n4RebLEs4Z/nyr9S7wDnYtULRGCsA4zFfZh2/rBcBdweyox6dk4F99TAIu27r5Yei6ktJgpAWpzTY2LR0VXgTc82X8I3PvuFNDL7tX4/mAJcB2+B0LSdntGC++jW+FUY7yO5zwH5O9nXpkPAm1s3++Pkh7fNBsejhRBFIidWAxQ00Ni0tBFYJbmV+8Tpx3KUpWB8JRQwv/2o9D5xEHNXXYmMM8H0s8ZJ3nCoVehGwGn53/7vkfTOnmh+Tne2LgVuAvbCCdt79LZS2ThSBlPhPg41NS2eENzG39AVm4BufZ4DlA9i2D/G9/CvVNekcTLlvrCyD+eAWfH8s9KZQnwOWx8aAp23T8L8CWE0rdoUtpN1TgQtYckp+HfyuRmehP9Tt/RQ5tMHGpqV30D3tnvgb/h3zRdK9f30YtvvjbVe9WoSdiTgBWC9FP8TKGliMbiLuRVqtOKWZZnwd4jj1fn2KNqXJAOA3pG/vQ1j/qz6ke3GAZ8WkBTicRxoCzGyy4c3q4OBW5pej8O+YHdhOxAFN2rIM8LsIbGlWz2CHsjZt0h8xsSlmk/ev3TR0Bc3XrT8A/923Lv1Pk7aE5miaXyjOw+K2ZTfPWI7ifv+v1Mm9OTsEv2mwsWnJ5QBETtgI/05ZqXtIfntjIPbL7P0I2p+2ngG+iX+ltkboi71civDSr9Z7wHEkv161HdbHvdtfqXUT2uDBGOwXetKdvUnYwnPlXv7+kxL+vXnVJBzmku1TaHiz2ja4lfklxgn6ceAs7OBKdc79NmxAH4h91/I+QJWFngN2Jj98Eksu4+230HoP+D32i34llk4CNRTrw2dixaS821utvOVLWQtbeP0X+yRTy6Y3gcux67/1nG3oC7zRzd9VRO1fh09SpQV4KYWGN6O/Bbcyv3wX/07Zm+YAL2Mr2JgPi4XUYuBE4r5K2IKd5C9rjBZhffQl8rGlfFztMOaCvtgtr49gOyvrYp+ck/J5/OOQpf7bgI+a5tQGG5uW2rFc02JpVqW8E3YedVHtMLrTAvwKf/9I9WkRSlLVAjyCfyyy1ofScF4SVsJOIXoa/afgVuaXW/DvlFL9Gl8zir7v+T8IAAAZCUlEQVScjr9fpPp1c+0wloo98Y+Dhy5Ow3lJuarBxqalRcDawa3MJ7vi3yml+tWOfWePhZ0o9h3qIsqlVnxk3IV/HDw0G1g2Bf8lYvsUGt6sfhXcyvzyEP7xkerXi8RRcGgw/md8pGR6oGYky8Un8I+Dp45u3oXJeaLBxqalefR+JaSsfAb/Tikl01E1I5ktx+HvBymZvModx8Tt+MfBU8/jcKD4sBQa3qzOC25lPmkFnsQ/PlL9egm7FulFG3Y7w9sPUv16jLhvkmTBNvjHwaPCZbU+0qwjkzIYy8HsafQsYFRoQ3PKDuhbbt60U61AZsTOPbRLik/t2JW5snMz/rH4HP6poE+vTlwRmtlYmU9PBmOZn8TS3I5uS+SNHR2f7bn4EMn5PXCHdyOc2QrYxbkNr2GH4n/h3I7uUiMHZU38753Px4qSiKVZCZiO/wpZqk+314xiNtzRTZuk+DQNGF07jKXiVvxj0XUAbyi+c+2TWe8AgJ1e9r6D2g+nwgg5YBJwvHcjRN2s6vjsVRyfLZJxHDDZuxHO7IL/rtVM4LKKf/69Y1tW9HpwDFcwFlGO8quN8gf8YyT1rhndBTADZvXQLikeXdldAEtEC1YYzjsWP6pq1/r4nbua04gj0+LBbhqVpa4KbmV+GQ68gH+MpN7lhbfdUu+aCAzrLoAl4kD8Y7EIGFujbV6fJV5M7MUU2a+bRmWpdpwOQuSEzYG5+MdJ6lleeNst9aw5wKbdRq889AGexT8ef+6mffs6tefORF5MmVb8r0F04H8eIXY+RfI63FK28sLbbql7LcKSewn4Ov7x6KD7e/d9sJsBWbfH+xYCX8I/KB34XwuJnRgSOEndywtvu6Xu9c0e4lYmhgBv4h+P//TSzhMd2rRHfS4MRz98Vj7VegarLy2651T84yTVlhfedku1dUpPQSsZZ+Afjw56z9exApaqPqv2zAYG1ufCsHwb/+B0dLZD9MwJ+MdJWlpeeNstLa1zeoxYuViDOM4w1fut/aIM23R+nW0KziDgHfyDNBVbhYme+Tr2fdE7Xln2C+/EVb3JC2+7e9Ji/NOOZ6lF2Kc6sYRr8Y9LB/WXXl4JO7gZuj0zgZF1tikTvo9/kDqAX4Y2tCDsTTYd1Vv3YMkyxmK/rGJ9oXjhbXctzQQuxnJ8rEA5qr7NA/bvOVSlYyf849IB3Juw3VmcBTg2YZuCswyWqtI7WIuADwe2tShsjt0j9Y5ZKF0G9K+yeThwDPFVwPPI6NnaRHtD6GUsNsOr2tkfqz/i3b5QmghsVjtEpaUP/qXnu7R7wra3YgcGQ7XnaiKtBnky/sHqwDe3et4YDvwF/5ilqVnYZ46eaAP2BK4DFkTQ5qG9tDcEw5pob1pagMVgT3ovi3wEdvDJu81p6k8oyU8tjsQ/Nh3AQw22fxngkQDteRS7FRElQ4C38Q9aB/DZwLYWja9jKWm949as7sCKVSVhNHY4coJju8clbHMarNtEe5vVBMznSYvbrIUdyPLuZ81qOvC1hLaXhRWAKfjHqAP7VNooywF3pdiWv+LzQyER38E/aB1YQZwRgW0tGisBf8Q/do1oOtb3mtlKb8HvSuunm2h3o3ymifY2o9dobguzFTiKfC5Y27HiMW5FXHLAFfjHqQN4gOa32vsC59HcoeuFwNn0vkMWBf2BV/EPXgd2kEgkZwfgSfzjV48WABeS3u2Pe5zsuCSl9ifhsiba24zuTqn9I4GfEccnnHr0BLB9SrYXlRiKzHUpzaqDGwF/I1nRoHbgJnJ4pu0r+Aevy4HbBba1qLRip5JjqL5VSwuwaodrpWz3VU72TCbbg4Bt+F3d/UvKtqyN7VzFmu76IWy3xeOgZ54YSDzFy0Kllx+LJWS7g9q3sOZitw5OA9YJ1Ibg9CGOGgEdWAGJ6pPgIhm7YNWuYrhLPwU4i3B17H/iaNuugWyqxe4B7ehN1eVU02JVbKs0hu/Hi4F/A58MZGsROQf/uHXFbuPAtoJ9HlgZ+BCwAbBsBs/MjM/iH8gunRbY1rIwBju4lfX1nDlYQpCDCJ/68qiMbavUI2TzK7EVeMzBvi6Fztg5EPg8drsg61wXT2BjZExgG4vGRsTzKed3gW0tBS3Es308H1thifTYEHtZ3kiY5DrPYXe/PwsMzsgmsG+0nn31C+FN5FBH+zqAbcOb+P8MAQ7A+lKIXcmpwA3YWNgwI5uKRit+Z2+qNZ/kt4hciTIhQCe7EE+p3nuwiafduyEFpA07qLIJ9j12XOefa9D7y/stLBnRi8BLwONYrN4N1dheGIoltPL6XjsVKzn6fKC/fx3gPvxuyCzufPYsp+ePBLbGtl3X7NRYej+VPxtLVPQ8lrhnInYn+3HMJtE4xwLnejeikwuw20QiJW7Cf1XXpaMC2ypqMwL71tU12Y4k4mQWwNP49tNnCfOCHoH/2ZwnA9iVFkOwvjkW66sro6vEodmAOIr9dGBXiVVLJmXGYdsq3sHtwDqaPgWI3vgN/n31fiwvQ1qshN1r9rbrshRtEvmmL/F8Ju7Azm6IAPwQ/+B26VGgX1hzRc45AP9+2gG8gdVraJYtgTcjsKcDFbwRSzgd//7YpRfQbbFgDMUy83kHuUtnhzVX5JxhxLNrtRBLaNVI5rjlsW+asdyPn0cOUpmKTNiUeE79dwB7hDVXxJIcqAM7tLN9WHNFzvkn/v20UjOBX2CZ0vr20O5+nf/NL7CDdt7trtTfe2i3KA8DgKfw749d+mdYc8MS8y2ASlqxb5CxlL18GTu5PtO7ISJKjgR+7t2IbpiGZZd7Cbs1AFZ9bCywBUuX042Fw1F6bmHJtkLngqiXBdj1zYneDSkDHyVZLuTQ0oEk0R1dV9W8+2hRNBtbpIhysztxvQPOCWuuqOYP+Ae9UvuFNVfkmEvx759F0S8T+l4Uj1WII01zl95EZ1IyZ2XsvqV38Ls0jfQLyohisDH+/bMo2jSh70Wx6IMVwPHuh5U6OKjFoluOxD/4lXqc8DnmRT65G//+mXfdmdjromicgX8/rNRt5Of8XOFoxSYF705QKW1Rilpsj3/fzLvSrKsu8scOwCL8+2GX5qBdX3fWJ5671l36fFCLRV65Bf++mVfFUgtE+DAKq/fh3Q8rpYx/kXAa/p2hUrOwhYkQlWxOXCeX86J29O2/zPTBttq9+2GlHqfnPBoiQ/rjX3ilWk+RbflZkQ/+iH/fzJuuaMjToihcgH8frNQi0kmtLVKkq0Svd+eo1B/QARHxQZYHJuPfN/Oid1BltTJzMP59sFrnB7VYNMzF+HeOauk7kagmliJBedBnGvSxyD8bY4mfvPtgpV4h7hLkpWYE8VQr69JiYK+QRotcci3+fTN2XdWwd0XeWR572Xr3wUq1Y/UxRMR8gvg+BcwANgpptMgdy2B5w737Zqx6GViuYe+KPNOG3frw7oPVujCk0SI9foZ/Z6k1oelbpqhkI1QnoJZmYoVVRDm5EP8+WK0X0NZ/bhgEPId/p6nWHViZVSG62Jf4dqw81Q58timPijxzFP59sFoLga1CGi3SZ1OsRKN356mWKgeKak7Cv1/GIh2aLS97EFemvy6ND2izCMip+HeeWjompNEil5yJf7/01mlNe1HklU2J83PYwyjhT27pA9yLfyeqVjtwSEC7RT75Af5900s/ScF/Ip+sDLyOfx+s1lx0FiX3jCPOleV84OMB7Rb5o4Vy7gScgRJmlZVhwJP498Fa+nZAu0WGHIF/Z6ql6ViyCyEq+SJxnl9JWwuBw9NxmcghA4D/4N8Pa+kmtCgtFFfj36lq6R1UUlIszc7AVPz7ZyhNRTtgZaYNS/Tk3Q9r6XUsEZEoEEOJ82pgB5YQZmQ400VOGYNdHfXun2nrXmDNFP0k8kULcCn+/bCWFgLbhDNdeLIpdrDDu5N1Nykq0YSopg27GleETwILsStVbWk6SOSO8/Hvi91J11ALTqznATqAu1AJYVGbrYCH8O+jjepBYMvUvSLyRsw5L/4OtIYzXcRCzDXZ/4UdjhGimhbs+mieyglPwU5T61e/OBz//tid3kCp2kvDEOBZ/Dtdd/orShksumcEcBYwDf++2p2mYlcahwfygcgXX8Eqo3r3y1paCGwXznQRIxsSX63pSl2HMlCJnhmK/bqOKYnKZOw7/4hwZouc8SXiffl3AEeHM13EzBfx73w96c9o61T0Tn/gAOAGLMFU1v10HnA9VsRHO1eikthf/n8IZ7rIAzGWnqzU5WgRIOpnWeBr2Gek6YTrl9OwZClfBZbJxDKRN75I3C//R4CBoYwX+aANO/3p3Rl70p/R5wCRnDZgc6z41NXA4zR2DXZO5//vVdh26WZoUSp65kDirOzXpSnAGsGszyFlTnu4LHA/cWfkuxHbYp3v3RCRa1qwBENrYKeeB3eqKwfFLOxszGwsS+UrwGvYpClEPXwF+BXxXqlbBHwSuM27ISIe1iX+1Ku3YQe/hBAiRr5J3Nv+HcC3glkvcs3uxL1t1QHcia5WCSHi43/xnx970+XBrBeF4Dj8O2lvehglrRBCxEEL8CP858V6fjwpyZrolcvx76y96SlgxVAOEEKIOugDXIH/fNibJgDLBfKBKBgDgLvx77S96RVg/TAuEEKIHhmI5X/wngd70zuo+qRIyHLAM/h33t40FdghjAuEEKImy2Fb6t7zX2+aC2wdyAei4KzCkitQMWs+8PlAPhBCiErWxLbUvee93tQOHBTIB6IkbEj81wO7Ovv4MC4QQggAPoptqXvPd/Xo2EA+ECVjJyzfuXeHrkcXoSxtQoj0+Rz5mQd/FsgHoqQcQPwJLrr0V2BYGDcIIUpGC3AitsvoPbfVoz8RbxZCkWOOxL9z16sJwHph3CCEKAkDyMe16C79C6uOKUQQzsW/k9erqcBuYdwghCg4q2EV87znsXp1JzAoiCeE6KQF+87u3dnrVTtwDuUu9iSESMY2wGT856969TgqSy0yogW4BP9On0RXYlXfhBCiJw4DFuA/Z9WricDoIJ4QohvagD/j3/mT6DFg9QC+EELknwHApfjPU0n0GvapQojM6Qtci/8gSKL3gE+FcIYQIresDTyK//yURG8C40I4Q4h66QfciP9gSKJ24ILOtgshys2+5CPZWaUmozooIhL6AX/Df1Ak1UPAWgH8IYSIn/7YDwHveSip3kIvfxEZA4H/4D84kmo6luFLCFEe8rjl3/XyV34TESVDgFvxHySN6CLsEJAQotgcCszAf85JqjewhYsQ0TIAuAn/wdKIngA2Tt8lQogIWB64Gv95Ri9/UWj6YvfuvQdNI5oPfB/ok7pXhBBe7AZMwn9+aUSvoLNKIme0kb87tZW6H1g3da8IIbJkIHbQLy+FfKr1LLBq6l4RIgNagJ/iP4ga1RzgKFRZS4g8shVWFMx7HmlUD2KfLYTINSfgP5ia0d1oC06IvDAIq/+xCP+5o1HdjkqaiwLxPfwHVTOaCXwH+7QhhIiTXYCX8Z8vmtEN6EaSKCBfJF9FNmrpMWxrUQgRD8sAF5Pfb/1d+j12iFqIQrIL+byDW6lF2MGioSn7RgiRnM/zf+3deYxVVx3A8e+ATGDK0sGyCLSNWLFasBbautamltoaJbjVGhtrYiNaY000xrrbamLcqqGJiTEuadFEAeOCkdRalzYRtSLBWhCwttRCWygMDGtlZvCP33uZx5Rt5t33zl2+n+SXx0AIh5N37v3de875HdhB+utCs3E7HluuCphHnGKVesA1G9uBGzLuG0mnZw6wmvTXgWajD7g5476Rcu0c4EHSD74s4hd4zLDULhOJp+WiTyceJdYWvTHb7pGKYQLlyOCPEgWEluLKXalVOoBrKcfbw6PEG8QFmfaQVDCdwDLSD8YsB/V7sXaAlKX5xHbc1OM7q1gPzMq0h6SC6gBuo/greBtjLXB5lp0kVdA5wJ1AP+nHdFaxGhcQS8/yNmJOLPUAzTJWArOz7CSpArqBrwKHSD+Gs4yleM6IdEIvAv5F+oGaZfyP2KM8I8N+ksqoE1hCObb1NcZhYmpQ0ilMBn5D+kGbdRwAvob1vaWhRhNbah8l/TjNOh4DLs6sp6QKGE3U8049eFsR+2v/t+7MeksqplHEyv6yvfWrx/3A9Mx6S6qYdxJPzqkHciuil0gEJmXWW1IxlP3Gf5SY9uvMqsOkqloAbCX9gG5VPA3cilMDKr/RwLsp9jG9p4pDON8vZWoy8HPSD+5Wxn5ilfC5GfWZlBddwE3AFtKPs1bGJuDCjPpM0hBLiKp7qQd6K6MfWIVVwlR8U4BbiAJZqcdVq2MlTudJLXcx8DDpB3yrY4BIBC7PptuktpkDfJvy7eM/XhwEbsym2ySdjknActIP/nbFP4APAOOz6DypBTqAq4jDscpUue9ksQGYm0XnSRq+GyjvLoHjRS+xunheFp0nZWASMTX3EOnHRzvjLkzIpeReSvUuPgPAvcBbsbSo0ngFUae/Cq/5G2M3sT1ZUk6MBb5OdV49NsY24CvAS5ruRenkzgI+BPyd9N/7FHE3MLPpXpTUEq8ENpP+QpEqHiJWXU9ttiOlmk5gEbHmpuw7cE4UB4lx5THfUs51Efvpy3S88HCjD7iHqLZmNTKNxAVEpcqnSP99Thl/Bc5vsi8ltdnVwOOkv4Ckjp3Ad4BrMBnQyc0HvkS136LV4wjweVxjIxVWN7CM9BeTvEQPsXp5MTCuiX5VOXQAlxJrSKpQW+N0Yy1wURP9KilHFhPHcqa+sOQp9gE/Aa4DJoy8a1UwY4ArgNsp5/G7zcQB4GP41C+VThcxp3mE9BeavEUf8Lda/7wGFzuVzTSiZsZyYA/pv295jD8QFQwlldh84AHSX3DyHE8SUyfX446CIhpHPOV/GVhP+u9TnuNpIjmSVBGjgQ8TlfVSX4DyHv3EnOg3icJD00bQ32qtLuBK4DbgPuAw6b83RYgfEgcWSaqgmcBPSX8hKlpsBn5AnHvuFqn2Owt4A/BF4H6quz9/pLEeD9lSg47UDVBSi4gn3BekbkhB7QTWAOsa4rGkLSqP8cS01SW1uBR4ftIWFVcP8DnipMK+xG1RjpgAqJOYFvgMnuudhV0cmxCsA7YQUwp6tg7ixj6XKMIzlzjn4sXElJVGbgD4LvBpYs5fOoYJgOqmAF8A3ocX3qw9Q+w331yLLbXPTUTFuSoYD8wmbvbnEWc4zKt9npGwXWW1BriZWMciHZcJgIaaB3wDWJi6IRXRSyQDjxIHHG0DtgP/BZ4gqjoeStW40/QcYtfENGAGMJ3Bm339010V7bGVeJv3I2LeXzohEwCdyCLipEH3CKe3m0gKdhD72Y8XPbXPQ0TNh/21v9tHFD+CmIborf16DMee6z6RwTc/XbWf63EmMT1U/3kScbOfSdzYp+K1JLVdRDnjbxFvnKRTctDqZMYANwGfwm1wUh4dBO4gyhrvSdwWFYwJgE5HF7E24JOYCEh5MEBs5f04MX0kDZsJgIZjIvBR4CO1X0tqr6PAz4DPAhsSt0VSBU0GbgX2kr64iWFUIQaAVURtBElKbjqwFEuwGkarop84vXIuUsacAlAWpgIfJAoKdSdui1QGA8CviQp+6xK3RZJOaRLwCWL/euonJ8MoYjwD3ElUQpSkwukkjhrdSPoLqmEUIfYS02lnI0klMIooKPRn0l9gDSOP8QhwC1FsSZJK6QpgJVGlLvVF1zBSx1+Ad+C5G0rIRYBqt5nA+4nCQtMTt0Vqp8PACuJY3j8lbotkAqBkOoHFwBLgSvwuqrz+TRzL+31gZ+K2SFKunE8sgNpH+lezhpFF9AP3ANfia37llE9dypOJwNuB9wCX4fdTxfMwcBfwPeJoZym3vMAqr84G3gXcCLwwcVukk9kL/JK48d9LvAGQcs8EQEWwgKgrcD3w3MRtkSBe8f8eWEbsbjmYtjnS8JkAqEjGAW8GrgNeX/tZapcBYA1Rm//HuKBPBWcCoKIaBywkFlktxuOJ1Rr1m/4K4knfeX2VhgmAymAscBXwJuINwdS0zVHB9RPVK1cAy4mzLaTSMQFQ2YwBXge8BbgGODdtc1QQu4lte6uBXwG70jZHaj0TAJXdbGKqYCGREExI2xzlyAZgFfBb4I9EmWqpMkwAVCVjgdcCV9figrTNUZvtAH5HPOXfDTyVtjlSWiYAqrJZRBniy4BXExUJVR5PEE/299U+N6RtjpQvJgDSoCnAqxhMCBYQawpUDI8TN/r6TX9T2uZI+WYCIJ1YF3AJkRC8HLiIOM1Q6fUADwyJ7UlbJBWMCYA0PFOBlxHJwPzar88DRqVsVMn1AP8E1jJ4s9+StEVSCZgASM2bAFxIJAVzibML5uDbguHaB2wEHiTm6+ufFt+RWsAEQGqd8UQyUE8IGqM7YbtS6gX+Azwy5HMjsBUP0pHaxgRASqMbmEGcevi82ucM4q3BrNrvTUvWupHpAZ4kttttq31uJ27s9Ru9BXaknDABkPKrE5gOTAbOPE50D/n5jNrfG8vgQUmdDb8/msEzE44A+xv+rX1A35A/O0A8sffW/nwPcfRtb0M03uwPN/0/ltQ2/wfVSJg0ONifEAAAAABJRU5ErkJggg=="/>
                                    </defs>
                                </svg>

                                <div class="is_processing_active"></div>
                            </div>
                            <h4 class="item_price processing_fee">$99</h4>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-12 col-md-4">
                @include('web.part.sticky-sidebar')
            </div>
        </div>
        <div class="text-right pb-4" style="text-align: center">
            <button onclick="prevStep(event,8,'step_8')" class="btn btn-next "><i class="fa-solid fa-chevron-left"></i>
                Back
            </button>
            <button onclick="nextStep(event,8,'step_8')" class="btn btn-next ">Next <i
                    class="fa-solid fa-chevron-right"></i></button>
        </div>
    </div>
    <div id="step9" class="step" style="display: none">
        <div class="row mb-5">
            <div class="col-12 col-md-8">
                <div class="processing_card-container">
                    <div class="processing_card_item active">
                        <input type="radio" id="stripe_payment"
                               onchange="onChangePaymentGetway(event)" name="payment" checked>
                        <label for="stripe_payment" class="card-content">
                            <div class="radio-circle"></div>
                            <span class="d-flex justify-content-between">
                                    <h3>Stripe</h3>
                                </span>
                        </label>
                    </div>
                    <div class="processing_card_item">
                        <input type="radio" id="paypal_payment"
                               onchange="onChangePaymentGetway(event)" name="payment">
                        <label for="paypal_payment" class="card-content ">
                            <div class="radio-circle"></div>
                            <span class="d-flex justify-content-between">
                                    <h3>Paypal</h3>
                                </span>
                        </label>
                    </div>

                </div>
                <div id="stripe" style="display: block" class="pay_item card card-body shadow">
                    <form action="{{ route('pay.stripe') }}" id="stripe-form">
                        <h4>Check Out</h4>
                        <label for="card-element">Credit or debit card</label>
                        <div id="card-element" class="mt-2"></div>
                        <div class="btn text-right mt-5 mb-2" style="width: 100%;">
                            <button type="submit" onclick="finalStep(event)" class="btn btn-next">Pay <span
                                    class="final_amount">$0.00</span></button>
                        </div>
                        {{--                       <div class="text-right pb-4" id="stripe_payment_submit_btn" style="text-align: center; display: block">--}}
                        {{--                           <button onclick="finalStep(event)" class="btn btn-next ">--}}
                        {{--                               Pay $ 100--}}
                        {{--                           </button>--}}
                        {{--                       </div>--}}
                    </form>
                </div>
                <div id="paypal_getway" style="display: none" class="pay_item">
                    <a href="{{route('paypal.pay')}}" id="paypalPayment" class="card card-body shadow"
                       style="display: flex; align-items: center">
                        <img src="{{asset('assets/images/paypal.png')}}" title="Paypal with 10 USD"
                             style="width: 100px;align-items: center;" alt="">
                        <span class="amount final_amount">$0.00</span>
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-4">
                @include('web.part.sticky-sidebar')
            </div>
        </div>

        {{--        <div class="text-right pb-4" style="text-align: center">--}}
        {{--            <button onclick="prevStep(event,9,'step_9')" class="btn btn-next "><i class="fa-solid fa-chevron-left"></i>--}}
        {{--                Back--}}
        {{--            </button>--}}
        {{--            <button onclick="nextStep(event,9,'step_9')" class="btn btn-next ">Next <i--}}
        {{--                    class="fa-solid fa-chevron-right"></i></button>--}}
        {{--        </div>--}}
        {{--        --}}

    </div>
</div>
</div>
<input type="hidden" id="store_route" value="{{route('test')}}">
<input type="hidden" id="csrf_token" value="{{csrf_token()}}">
<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
<script src="https://www.gstatic.com/firebasejs/8.6.2/firebase-app.js"></script>

<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4="
        crossorigin="anonymous"></script>
<script src="{{ asset('assets/js/toastr.min.js') }}"></script>
<script src="https://js.stripe.com/v3/"></script>
<script src="{{asset('assets/js/script.js')}}"></script>


{{--Toaster Alart Section--}}
<script>
    @if (Session::has('success'))
        toastr.options = {
        "closeButton": true,
        "progressBar": true
    }
    toastr.success("{{ session('success') }}");
    @endif
        @if (Session::has('error'))
        toastr.options = {
        "closeButton": true,
        "progressBar": true
    }
    toastr.error("{{ session('error') }}");
    @endif
        @if (Session::has('info'))
        toastr.options = {
        "closeButton": true,
        "progressBar": true
    }
    toastr.info("{{ session('info') }}");
    @endif
        @if (Session::has('warning'))
        toastr.options = {
        "closeButton": true,
        "progressBar": true
    }
    toastr.warning("{{ session('warning') }}");

    @endif
        alertMessage("success","YES")
    function alertMessage(type, message) {
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        if (type === 'success') {
            toastr.success(message);
        } else if (type === 'error') {
            toastr.error(message);
        } else if (type === 'info') {
            toastr.info(message);
        } else if (type === 'warning') {
            toastr.warning(message);
        }

    }
</script>
<script>
    var stripe = Stripe('{{ env('STRIPE_KEY') }}');
    var elements = stripe.elements();
    var card = elements.create('card');
    card.mount('#card-element');


    function onChangePaymentGetway(event) {
        console.log(localStorage.getItem("final_amount"))
        let rush_processing_value = event.target.value;
        let parent = event.target.parentElement;
        let field_name = event.target.getAttribute("id")
        console.log(field_name)
        if (field_name == 'stripe_payment') {
            $('.processing_card_item').removeClass('active');
            $('#stripe').css('display', 'block');
            $('#stripe_payment_submit_btn').css('display', 'block');
            $('#paypal_getway').css('display', 'none')
            parent.classList.add("active")
        } else if (field_name == 'paypal_payment') {
            $('.processing_card_item').removeClass('active');
            $('#stripe').css('display', 'none')
            $('#stripe_payment_submit_btn').css('display', 'none');
            $('#paypal_getway').css('display', 'block');
            parent.classList.add("active")
        }
    }

    function finalStep(event) {
        var form = document.getElementById('stripe-form');
        event.preventDefault();
        stripe.createToken(card).then(function (result) {
            if (result.error) {
                // Inform the user if there was an error
                console.log(result.error.message);
            } else {

                let stripeToken = result.token.id;
                let localStorageData = retrieveLocalStorageValue();
                $.ajax({
                    url: "{{route('pay.stripe')}}",
                    type: 'POST',
                    data: {
                        stripeToken: stripeToken,
                        localStorageData: localStorageData,
                        _token: '{{csrf_token()}}'
                    },
                    success: function (data) {
                        console.log(data)
                    },
                    error: function (data) {
                        console.log(data)
                    }
                })
            }
        });
    }

    $("#paypalPayment").click(function (event) {
        event.preventDefault();
        let localStorageData = retrieveLocalStorageValue();
        let route = "{{route('paypal.pay')}}?localStorageData=" + encodeURIComponent(localStorageData);
        location.href = route;

    })


</script>
</body>

</html>
